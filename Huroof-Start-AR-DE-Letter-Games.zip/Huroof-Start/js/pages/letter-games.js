(() => {
  "use strict";

  window.JisrStorage.ready(() => {
    const { $, choose, el, button, arabic, onLanguage } = window.Practice;
    const { graphemes, nonJoining } = window.ArabicLetterExamples;
    const bridgeWords = ["بَاب", "سَمَك", "وَرْد"];
    let target = bridgeWords[0];
    let placed = 0;
    let wrongTile = false;

    function renderBridge() {
      const letters = graphemes(target);
      const tiles = [...new Set([letters[1], ...letters])];
      $("bridge-words").replaceChildren(...bridgeWords.map((word) => {
        const control = button(word, () => {
          target = word;
          resetBridge();
          $("bridge-words").querySelector('[aria-pressed="true"]').focus();
        });
        control.setAttribute("aria-pressed", String(word === target));
        return control;
      }));

      const added = letters.slice(0, placed);
      $("bridge-word").textContent = added.join("") || "· · ·";

      const groups = $("bridge-connections");
      groups.replaceChildren();
      added.forEach((letter, index) => {
        const group = groups.lastElementChild;
        if (!group || nonJoining.has(added[index - 1][0])) {
          groups.append(el("span", letter, "letter-bridge-group"));
        } else {
          group.textContent += letter;
        }
      });

      $("bridge-letters").replaceChildren(...tiles.map((tile) => {
        const control = button(tile, () => {
          wrongTile = tile !== letters[placed];
          if (!wrongTile) placed += 1;
          renderBridge();
          const rendered = $("bridge-letters").children[tiles.indexOf(tile)];
          (rendered.disabled ? $("bridge-undo") : rendered).focus();
        });
        control.disabled = placed === letters.length;
        return control;
      }));
      $("bridge-undo").disabled = placed === 0;
      $("bridge-reset").disabled = placed === 0 && !wrongTile;

      let feedback = choose("ضع الحرف الأول على الجسر.", "Setze den ersten Buchstaben auf die Brücke.");
      if (wrongTile) {
        feedback = choose(`ابحث عن الحرف التالي «${letters[placed]}».`, `Suche den nächsten Buchstaben «${letters[placed]}».`);
      } else if (placed > 1) {
        const previous = added.at(-2)[0];
        const current = added.at(-1)[0];
        feedback = nonJoining.has(previous)
          ? choose(`«${previous}» لا يتصل بالحرف الذي يأتي بعده «${current}».`,
            `«${previous}» verbindet sich nicht mit dem folgenden «${current}».`)
          : choose(`اتصل «${previous}» بالحرف «${current}».`, `«${previous}» und «${current}» sind verbunden.`);
      } else if (placed === 1) {
        feedback = choose("الآن اختر الحرف التالي.", "Wähle jetzt den nächsten Buchstaben.");
      }
      $("bridge-feedback").textContent = feedback;
    }

    function resetBridge() {
      placed = 0;
      wrongTile = false;
      renderBridge();
    }

    $("bridge-undo").onclick = () => {
      placed -= 1;
      wrongTile = false;
      renderBridge();
      if (placed === 0) $("bridge-letters").firstElementChild.focus();
    };
    $("bridge-reset").onclick = () => {
      resetBridge();
      $("bridge-letters").firstElementChild.focus();
    };

    const sceneLetters = ["ك", "ت", "ب"];
    const marks = [
      { symbol: "َ", ar: "فتحة", de: "Fatḥa (a)" },
      { symbol: "ُ", ar: "ضمة", de: "Ḍamma (u)" },
      { symbol: "ِ", ar: "كسرة", de: "Kasra (i)" },
      { symbol: "", ar: "بلا حركة", de: "Ohne Vokalzeichen" },
    ];
    const scenes = [
      { marks: ["َ", "َ", "َ"], ar: "كَتَبَ الطِّفْلُ", de: "Das Kind schrieb.", audio: "audio/letter-games/wrote.mp3" },
      { marks: ["ُ", "ُ", ""], ar: "هَذِهِ كُتُبٌ", de: "Das sind Bücher.", audio: "audio/letter-games/books.mp3" },
      { marks: ["ُ", "ِ", "َ"], ar: "كُتِبَ نَصٌّ", de: "Ein Text wurde geschrieben.", audio: "audio/letter-games/written.mp3" },
    ];
    const chosen = [null, null, null];
    const audio = new Audio();
    audio.preload = "none";
    let playingRequest = 0;

    const currentScene = () => scenes.find((scene) => scene.marks.every((mark, i) => mark === chosen[i]));
    const wordWith = (vowels) => sceneLetters.map((letter, i) => letter + (vowels[i] ?? "")).join("");

    function stopSceneAudio() {
      playingRequest += 1;
      audio.pause();
      $("practice-audio-status").textContent = "";
    }

    function listen() {
      const scene = currentScene();
      if (!scene) return;
      stopSceneAudio();
      const request = playingRequest;
      audio.src = scene.audio;
      audio.play().catch(() => {
        if (request === playingRequest) {
          $("practice-audio-status").textContent = choose("تعذّر تشغيل التسجيل. جرّب مرة أخرى.", "Die Aufnahme konnte nicht abgespielt werden. Versuche es erneut.");
        }
      });
    }

    function renderScene() {
      const match = currentScene();
      $("scene-word").textContent = wordWith(chosen);
      $("scene-vowels").replaceChildren(...sceneLetters.map((letter, index) => {
        const group = el("fieldset", undefined, "scene-vowel-group");
        group.append(arabic(el("legend", letter)));
        marks.forEach(({ symbol, ar, de }, markIndex) => {
          const control = button(symbol ? "◌" + symbol : "–", () => {
            stopSceneAudio();
            chosen[index] = symbol;
            renderScene();
            $("scene-vowels").children[index].querySelectorAll("button")[markIndex].focus();
            if (currentScene()) listen();
          });
          control.setAttribute("aria-label", choose(ar, de));
          control.setAttribute("aria-pressed", String(chosen[index] === symbol));
          group.append(control);
        });
        return group;
      }));

      $("scene-pictures").replaceChildren(...scenes.map((scene, index) => {
        const figure = el("figure", undefined, "scene-picture");
        const image = el("div", undefined, `scene-art scene-art-${index}`);
        image.setAttribute("role", "img");
        image.setAttribute("aria-label", choose(scene.ar, scene.de));
        figure.append(image);
        if (scene === match) {
          figure.dataset.match = "true";
          figure.append(el("figcaption", choose(scene.ar, scene.de)));
        }
        return figure;
      }));

      $("scene-listen").disabled = !match;
      $("scene-reset").disabled = chosen.every((mark) => mark === null);
      $("scene-feedback").textContent = match
        ? choose(`وجدت الصورة المطابقة لكلمة «${wordWith(chosen)}».`, `Du hast das Bild zu «${wordWith(chosen)}» gefunden.`)
        : chosen.every((mark) => mark !== null)
          ? choose("هذا الضبط لا يطابق الصور الثلاث. جرّب تبديل إحدى الحركات.",
            "Diese Kombination passt zu keinem der drei Bilder. Ändere ein Vokalzeichen.")
          : choose("اختر لكل حرف فتحة أو ضمة أو كسرة أو «بلا حركة».",
            "Wähle für jeden Buchstaben ein Vokalzeichen oder «ohne Vokalzeichen».");
    }

    $("scene-listen").onclick = listen;
    $("scene-reset").onclick = () => {
      stopSceneAudio();
      chosen.fill(null);
      renderScene();
      $("scene-vowels").querySelector("button").focus();
    };
    window.addEventListener("pagehide", stopSceneAudio);
    onLanguage(() => {
      stopSceneAudio();
      renderBridge();
      renderScene();
    });
  });
})();
