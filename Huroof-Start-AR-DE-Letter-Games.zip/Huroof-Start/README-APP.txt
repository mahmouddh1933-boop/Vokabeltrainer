HUROOF Start — DEMO / نسخة تجريبية

Vollständige interaktive Vorschau der aktuellen Lernbereiche. Keine Anmeldung, keine Firebase-Verbindung, keine Cloud-Synchronisierung. Lernstände dieser Demo werden getrennt von der Vollversion auf diesem Gerät gespeichert. Die Sprache ist Deutsch/Arabisch umschaltbar.

Zuerst entpacken, dann index.html öffnen oder den Ordner auf einem statischen Hosting bereitstellen.

Auf dem bestehenden Firebase-Hosting: Lege den Inhalt dieser Demo in den Unterordner public/demo/ DEINES passenden vollständigen Firebase-Ready-Pakets. Führe anschließend im vollständigen Paket node deploy-firebase.cjs aus. Die Demo erscheint danach unter /demo/. Die bestehenden Dateien der Vollversion bleiben im public-Hauptordner. Diese Demo selbst enthält keine Firebase-Deploy-Konfiguration.

نسخة للمعاينة بكل أقسام التعلّم الحالية، دون تسجيل دخول أو مزامنة سحابية. التقدّم محلي ومنفصل عن النسخة الكاملة. للاستضافة مع التطبيق الكامل، ضع ملفات هذه النسخة داخل public/demo في حزمته ثم انشر الحزمة الكاملة.
