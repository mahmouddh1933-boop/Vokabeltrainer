العربية A1 وA2 — Firebase مستقل
انظر README-AR.md بجانب firebase.json.
