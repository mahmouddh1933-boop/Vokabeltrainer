حروف – العربية للمبتدئين A1 وA2
Huroof – Arabisch A1 und A2

مفردات المستويين، القواعد الأساسية، الجمل، القصص والمهارات ضمن وحدات مترابطة.

فك الضغط أولًا، ثم افتح index.html على الحاسوب أو ارفع ملفات المجلد إلى استضافة ثابتة.
Entpacke zuerst die ZIP. Öffne index.html am Computer oder lade den Ordner auf ein statisches Hosting.

عند النشر تستخدم النسخة إعدادات Firebase الحالية وقائمة الإيميلات المسموحة.
لتجميع التطبيقات الأربعة على الموقع نفسه استخدم Huroof-Suite-Setup.zip ودليل README-AR.md داخله.
Beim Online-Hosting gelten die bisherigen Firebase-Zugangsdaten und E-Mail-Freigaben.
Für alle vier Apps auf derselben Website verwende Huroof-Suite-Setup.zip.

التقدم منفصل لكل تطبيق؛ اللغة والمظهر مشتركان عند الاستضافة على النطاق نفسه.
Lernstände werden je App getrennt gespeichert; Sprache und Design sind auf derselben Domain gemeinsam.
