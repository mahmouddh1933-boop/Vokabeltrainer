(() => {
  "use strict";
  const stages = [{"id":"vocabulary","href":"vocabulary.html","ar":"المفردات A1 وA2","de":"Wortschatz A1 und A2","description":"افتح الدروس والتدريبات وتابع من حيث توقفت.","descriptionDe":"Lektionen und Übungen öffnen und weiterlernen."},{"id":"skills","href":"skills.html","ar":"المهارات والوحدات","de":"Fertigkeiten und Einheiten","description":"افتح الدروس والتدريبات وتابع من حيث توقفت.","descriptionDe":"Lektionen und Übungen öffnen und weiterlernen."},{"id":"sentences","href":"sentences.html","ar":"تكوين الجمل","de":"Sätze bilden","description":"افتح الدروس والتدريبات وتابع من حيث توقفت.","descriptionDe":"Lektionen und Übungen öffnen und weiterlernen."},{"id":"stories","href":"stories.html","ar":"قصص قصيرة","de":"Kurzgeschichten","description":"افتح الدروس والتدريبات وتابع من حيث توقفت.","descriptionDe":"Lektionen und Übungen öffnen und weiterlernen."},{"id":"grammar","href":"grammar.html","ar":"القواعد والإملاء","de":"Grammatik und Rechtschreibung","description":"افتح الدروس والتدريبات وتابع من حيث توقفت.","descriptionDe":"Lektionen und Übungen öffnen und weiterlernen."},{"id":"verbs","href":"verbs.html","ar":"تصريف الأفعال الشائعة","de":"Häufige Verben","description":"افتح الدروس والتدريبات وتابع من حيث توقفت.","descriptionDe":"Lektionen und Übungen öffnen und weiterlernen."},{"id":"review","href":"review.html","ar":"مراجعة المفردات","de":"Wörter wiederholen","description":"افتح الدروس والتدريبات وتابع من حيث توقفت.","descriptionDe":"Lektionen und Übungen öffnen und weiterlernen."},{"id":"stats","href":"stats.html","ar":"تقدّمي","de":"Mein Lernstand","description":"افتح الدروس والتدريبات وتابع من حيث توقفت.","descriptionDe":"Lektionen und Übungen öffnen und weiterlernen."}];
  const groups = {
    "reading-exercises.html": "reading",
    "reading-trainer.html": "reading",
    "huruf.html": "letters",
    "letter-tests.html": "letters",
    "sounds.html": "letters",
    "lernseite.html": "vocabulary",
    "review.html": "vocabulary",
    "stats.html": "vocabulary",
    "test.html": "vocabulary",
    "verbs.html": "grammar",
    "book-level-two.html": "books",
    "arabic-youth.html": "books",
    "youth-training-two.html": "books",
    "youth-book-two-part-one.html": "books",
  };
  const page = location.pathname.split("/").pop() || "index.html";
  const stage =
    stages.find((s) => s.href === page) ||
    stages.find(
      (s) => s.id === (page.startsWith("test") ? "vocabulary" : groups[page]),
    );
  const state = () => window.VocabApp.getStats().learningRouteV1 || {};
  const update = (patch) => {
    const stats = window.VocabApp.getStats();
    window.VocabApp.setJSON("learningStats", {
      ...stats,
      learningRouteV1: { ...state(), ...patch },
    });
  };
  window.LearningRoute = { stages, stage, state, update };
  function redirectLegacyVocabularyLink() {
    if (page === "index.html" && ["#ready-lists-panel", "#excel-panel"].includes(location.hash)) {
      location.replace("vocabulary.html" + location.hash);
      return true;
    }
    return false;
  }
  window.addEventListener("hashchange", redirectLegacyVocabularyLink);
  window.JisrStorage.ready(() => {
    if (redirectLegacyVocabularyLink()) return;
    if (stage) {
      update({ lastStage: stage.id });
      const bar = document.createElement("nav");
      bar.className = "route-stage-nav";
      bar.setAttribute("aria-label", "مسار التعلم / Lernpfad");
      const i = stages.indexOf(stage);
      for (const [href, ar, de] of [
        [
          i ? stages[i - 1].href : "index.html",
          i ? "الخطوة السابقة" : "مسار التعلم",
          i ? "Voriger Schritt" : "Lernpfad",
        ],
        ["index.html", "المسار الكامل", "Gesamter Lernpfad"],
        [
          i < stages.length - 1 ? stages[i + 1].href : "index.html",
          i < stages.length - 1 ? "الخطوة التالية" : "العودة للمسار",
          i < stages.length - 1 ? "Nächster Schritt" : "Zum Lernpfad",
        ],
      ]) {
        const a = document.createElement("a");
        a.href = href;
        a.dataset.ar = ar;
        a.dataset.de = de;
        a.textContent = ar;
        bar.append(a);
      }
      document.querySelector("main")?.append(bar);
    }
  });
})();
