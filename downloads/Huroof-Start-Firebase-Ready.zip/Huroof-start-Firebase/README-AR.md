# البداية والحروف — مشروع مستقل جاهز

هذه الحزمة مضبوطة لمشروع huroof-start-e3250. لا تحتاج إلى تعديل إعدادات Web أو تشغيل firebase init.

داخل المشروع من Firebase Console: فعّل Authentication → Email/Password، وأنشئ Cloud Firestore Standard بمعرّف (default) في وضع Production.

افتح PowerShell داخل هذا المجلد بجانب firebase.json ونفّذ:

```powershell
node deploy-firebase.cjs
```

إذا طُلب تسجيل الدخول: `npx.cmd firebase-tools login`. ينشر السكربت إلى مشروع huroof-start-e3250 فقط، والقواعد أولًا ثم الاستضافة.

بعد النشر: https://huroof-start-e3250.web.app/

لمنح نفسك الإدارة، أنشئ حسابك في التطبيق وأكّد البريد. انسخ UID من Authentication → Users. أنشئ مستند Firestore بالمسار oliveFreeAdmins/UID، بحقل enabled من نوع boolean بقيمة true. أعد تسجيل الدخول. حسابات الطلاب والتقدّم والإدارة منفصلة عن المشاريع الأخرى.
