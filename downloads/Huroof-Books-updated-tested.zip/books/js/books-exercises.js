/* Books-only interactive exercises: pointer, touch and keyboard share one saved model. */
(() => {
  const P=window.Practice, {el,button,arabic}=P;
  const normalize=v=>String(v??'').normalize('NFC').replace(/[\u064B-\u065F\u0670\u0640]/g,'').replace(/إثنين|إثْنَيْن/g,'اثنين').trim();
  const supported=q=>['week','classify','matching'].includes(q.kind);
  function correct(q,v){
    if(!v||!Array.isArray(v))return false;
    if(q.kind==='week')return v.length===7&&v.every((x,i)=>normalize(x)===normalize(q.days[i]));
    if(q.kind==='classify')return v.length===q.items.length&&v.every((x,i)=>x===q.items[i].category);
    if(q.kind==='matching')return v.length===q.pairs.length&&v.every((x,i)=>Number.isInteger(x)&&x===i);
    return false;
  }
  function create(q,{value,onChange=()=>{},onReady=()=>{}}={}){
    let vals=Array.isArray(value)?value.slice():[],locked=false,selected=null;
    const root=arabic(el('div',undefined,'books-exercise books-'+q.kind));
    const status=el('p','','books-interaction-status');status.setAttribute('aria-live','polite');
    const all=[];let redraw=()=>{};
    const ready=()=>q.kind==='week'?vals.length===7&&vals.every(x=>String(x||'').trim()):vals.length===(q.items||q.pairs).length&&vals.every(x=>x!==null&&x!==undefined);
    const changed=()=>{onChange(vals.slice());onReady(ready());};
    if(q.kind==='week'){
      const fields=el('div',undefined,'books-week-fields');
      for(let i=0;i<7;i++){
        const label=el('label',String(i+1)),input=el('input');input.type='text';input.autocomplete='off';input.maxLength=30;input.dataset.day=i;input.value=vals[i]||'';input.setAttribute('aria-label','اليوم '+(i+1));
        vals[i]=input.value;input.oninput=()=>{vals[i]=input.value;changed();};label.append(input);fields.append(label);all.push(input);
      }
      root.append(fields);
      redraw=()=>{if(locked)all.forEach((input,i)=>input.classList.add(normalize(vals[i])===normalize(q.days[i])?'is-correct':'is-wrong'));};
    }else if(q.kind==='classify'){
      vals=q.items.map((_,i)=>['اسم','فعل','حرف'].includes(vals[i])?vals[i]:null);
      const bank=el('div',undefined,'books-word-bank'),zones=el('div',undefined,'books-dropzones'),table=el('table',undefined,'books-classification-table');
      bank.setAttribute('aria-label','بنك الكلمات');
      const caption=el('caption','جدول اختياراتي · اضغط كلمة في الجدول لإعادتها إلى البنك');table.append(caption);
      const tr=el('tr'),body=el('tbody'),row=el('tr');const cells={};
      const selectWord=i=>{selected=i;status.textContent='اختر قسم الكلمة: '+q.items[i].word;redraw();};
      function assign(i,cat){if(locked||i===null)return;vals[i]=cat;selected=null;changed();redraw();status.textContent='وُضعت '+q.items[i].word+' في '+cat;}
      for(const cat of ['اسم','فعل','حرف']){
        const zone=button(cat,()=>assign(selected,cat),'practice-button books-dropzone');zone.dataset.category=cat;zones.append(zone);all.push(zone);
        const th=el('th',cat);th.scope='col';tr.append(th);const td=el('td');cells[cat]=td;row.append(td);
      }
      const head=el('thead');head.append(tr);body.append(row);table.append(head,body);
      function chip(i,inTable=false){
        const b=button(q.items[i].word,()=>{if(locked)return;if(inTable){vals[i]=null;changed();redraw();}else selectWord(i);},'practice-button books-word');b.dataset.wordIndex=i;b.setAttribute('aria-pressed',String(selected===i));b.disabled=locked;
        if(!inTable)drag(b,i,'.books-dropzone',target=>assign(i,target.dataset.category));
        if(locked)b.classList.add(vals[i]===q.items[i].category?'is-correct':'is-wrong');return b;
      }
      redraw=()=>{bank.replaceChildren();Object.values(cells).forEach(c=>c.replaceChildren());q.items.forEach((item,i)=>{if(vals[i])cells[vals[i]].append(chip(i,true));else bank.append(chip(i));});};
      root.append(el('p','اسحب كلمة إلى أحد المستطيلات، أو اختر الكلمة ثم اضغط القسم.','books-help'),bank,zones,table);
    }else{
      vals=q.pairs.map((_,i)=>Number.isInteger(vals[i])&&vals[i]>=0&&vals[i]<q.pairs.length?vals[i]:null);
      const board=el('div',undefined,'books-match-board'),left=el('div',undefined,'books-match-column'),right=el('div',undefined,'books-match-column');
      const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.classList.add('books-match-lines');svg.setAttribute('aria-hidden','true');
      const starts=[],ends=[];
      function connect(i,j){if(locked||i===null)return;vals=vals.map((v,k)=>k!==i&&v===j?null:v);vals[i]=j;selected=null;changed();redraw();status.textContent=q.pairs[i][0]+' ↔ '+q.pairs[j][1];}
      q.pairs.forEach((pair,i)=>{const b=button(pair[0],()=>{if(locked)return;selected=i;redraw();status.textContent='اختر ضد '+pair[0];},'practice-button books-match-start');b.dataset.matchStart=i;starts[i]=b;left.append(b);all.push(b);drag(b,i,'.books-match-end',target=>connect(i,Number(target.dataset.matchEnd)));});
      P.shuffle(q.pairs.map((_,i)=>i)).forEach(i=>{const b=button(q.pairs[i][1],()=>connect(selected,i),'practice-button books-match-end');b.dataset.matchEnd=i;ends[i]=b;right.append(b);all.push(b);});
      const drawLines=()=>{
        svg.replaceChildren();const base=board.getBoundingClientRect();if(!base.width)return;
        svg.setAttribute('viewBox',`0 0 ${base.width} ${base.height}`);
        vals.forEach((j,i)=>{if(j===null)return;const a=starts[i].getBoundingClientRect(),b=ends[j].getBoundingClientRect(),line=document.createElementNS(svg.namespaceURI,'line');for(const [key,v]of Object.entries({x1:a.left-base.left,y1:a.top+a.height/2-base.top,x2:b.right-base.left,y2:b.top+b.height/2-base.top,stroke:locked?(i===j?'#287348':'#aa3e32'):'#487b70','stroke-width':3}))line.setAttribute(key,v);svg.append(line);});
      };
      redraw=()=>{starts.forEach((b,i)=>{b.setAttribute('aria-pressed',String(selected===i));b.dataset.connected=vals[i]!==null;});ends.forEach((b,i)=>b.dataset.connected=vals.includes(i));requestAnimationFrame(drawLines);};
      new ResizeObserver(drawLines).observe(board);
      board.append(svg,left,right);root.append(el('p','اسحب خطًا من كلمة إلى ضدها، أو انقر الكلمتين. يتغير التوصيل إذا اخترت ضدًا آخر.','books-help'),board);
    }
    // Pointer capture keeps both mouse and finger drags reliable across the gap.
    function drag(node,index,targetSelector,drop){
      let start=null,moved=false;
      node.addEventListener('pointerdown',e=>{if(locked)return;start={x:e.clientX,y:e.clientY,id:e.pointerId};moved=false;node.setPointerCapture(e.pointerId);});
      node.addEventListener('pointermove',e=>{if(!start)return;if(Math.hypot(e.clientX-start.x,e.clientY-start.y)>8){moved=true;node.classList.add('books-dragging');status.textContent='اسحب إلى المكان المطلوب';}});
      node.addEventListener('pointerup',e=>{if(!start)return;const target=document.elementFromPoint(e.clientX,e.clientY)?.closest(targetSelector);if(node.hasPointerCapture(e.pointerId))node.releasePointerCapture(e.pointerId);node.classList.remove('books-dragging');start=null;if(moved&&target&&root.contains(target)){e.preventDefault();drop(target);}else if(!moved){e.preventDefault();node.click();} });
      node.addEventListener('pointercancel',()=>{start=null;node.classList.remove('books-dragging');});
    }
    root.append(status);redraw();queueMicrotask(()=>onReady(ready()));
    return {node:root,getValue:()=>vals.slice(),lock(){locked=true;all.forEach(n=>n.disabled=true);redraw();},ready};
  }
  window.BooksExercises={supported,correct,create};
})();
