(() => {
  "use strict";
  const data =
    typeof module !== "undefined" && module.exports
      ? require("./letter-data.js")
      : window.ArabicLetterData;
  const examples =
    typeof module !== "undefined" && module.exports
      ? require("./letter-examples.js")
      : window.ArabicLetterExamples;
  const extras = {"أ":[{"word":"أرنب","de":"Kaninchen"},{"word":"أمل","de":"Hoffnung"},{"word":"أذن","de":"Ohr"},{"word":"أم","de":"Mutter"},{"word":"رأس","de":"Kopf"},{"word":"كأس","de":"Glas"},{"word":"بدأ","de":"begann"},{"word":"نبأ","de":"Nachricht"}],"ب":[{"word":"بنت","de":"Mädchen"},{"word":"بحر","de":"Meer"},{"word":"بستان","de":"Garten"},{"word":"برج","de":"Turm"},{"word":"خبز","de":"Brot"},{"word":"سبح","de":"schwamm"},{"word":"ثوب","de":"Kleid"},{"word":"حبل","de":"Seil"}],"ت":[{"word":"تفاحة","de":"Apfel"},{"word":"تاج","de":"Krone"},{"word":"تمساح","de":"Krokodil"},{"word":"توت","de":"Maulbeeren"},{"word":"مفتاح","de":"Schlüssel"},{"word":"دفتر","de":"Heft"},{"word":"حوت","de":"Wal"},{"word":"صوت","de":"Stimme"}],"ث":[{"word":"ثور","de":"Stier"},{"word":"ثلج","de":"Schnee"},{"word":"ثوب","de":"Kleid"},{"word":"ثوم","de":"Knoblauch"},{"word":"كثير","de":"viel"},{"word":"مثال","de":"Beispiel"},{"word":"أثاث","de":"Möbel"},{"word":"حديث","de":"Gespräch"}],"ج":[{"word":"جبن","de":"Käse"},{"word":"جرس","de":"Glocke"},{"word":"جسر","de":"Brücke"},{"word":"جزر","de":"Karotten"},{"word":"عجلة","de":"Rad"},{"word":"حجر","de":"Stein"},{"word":"برج","de":"Turm"},{"word":"موج","de":"Wellen"}],"ح":[{"word":"حبل","de":"Seil"},{"word":"حوت","de":"Wal"},{"word":"حديقة","de":"Garten"},{"word":"حقيبة","de":"Tasche"},{"word":"سحابة","de":"Wolke"},{"word":"نحلة","de":"Biene"},{"word":"صباح","de":"Morgen"},{"word":"مفتاح","de":"Schlüssel"}]};
  const modes = ["forms", "missing", "circle"];
  const shuffle = (items, random) => {
    const a = [...items];
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  };
  const banks = Object.fromEntries(
    data.letters.map((letter) => [
      letter.char,
      [
        ...examples.examples[letter.char].map((e) => ({ ...e })),
        ...extras[letter.char].map((e) => ({
          ...e,
          index: examples.graphemes(e.word).indexOf(letter.char),
        })),
      ],
    ]),
  );
  function wordInfo(char, example) {
    const letter = data.letters.find((l) => l.char === char);
    const units = examples.graphemes(example.word),
      index = example.index;
    const before = index > 0 && !examples.nonJoining.has(units[index - 1]);
    const after =
      index < units.length - 1 &&
      !letter.nonjoining &&
      units[index + 1] !== "ء";
    const shape = before
      ? after
        ? "medial"
        : "final"
      : after
        ? "initial"
        : "isolated";
    const position =
      index === 0 ? "start" : index === units.length - 1 ? "end" : "middle";
    return {
      shape,
      position,
      before,
      after,
      masked: units.map((u, i) => (i === index ? "□" : u)).join(""),
    };
  }
  function createLetterQuestions(char, mode, random = Math.random) {
    const letter = data.letters.find((l) => l.char === char);
    if (!letter || !modes.includes(mode))
      throw new Error("Unknown letter or focused mode");
    const words = banks[char];
    if (mode === "circle")
      return Array.from({ length: 12 }, (_, i) => {
        const count = 4 + (i % 3);
        const targets = Array.from({ length: count }, (_, j) => ({
          glyph: letter.forms[(i + j) % 4],
          letter: char,
        }));
        const otherLetters = shuffle(
          data.letters.filter((l) => l.char !== char),
          random,
        );
        const others = otherLetters
          .slice(0, 16 - count)
          .map((l, j) => ({ glyph: l.forms[(i + j) % 4], letter: l.char }));
        const cells = shuffle([...targets, ...others], random);
        return {
          id: `circle-${i}`,
          kind: "circle",
          letter: char,
          cells,
          correct: cells.flatMap((cell, index) =>
            cell.letter === char ? [index] : [],
          ),
        };
      });
    if (mode === "missing")
      return shuffle(words, random).map((example, i) => ({
        id: `missing-${i}`,
        kind: "missing",
        letter: char,
        example,
        ...wordInfo(char, example),
        options: shuffle(
          [
            char,
            ...shuffle(
              data.letters.filter((l) => l.char !== char),
              random,
            )
              .slice(0, 3)
              .map((l) => l.char),
          ],
          random,
        ),
        correct: char,
      }));
    return shuffle(
      words.flatMap((example, i) => {
        const info = wordInfo(char, example);
        return [
          {
            id: `shape-${i}`,
            kind: "shape",
            letter: char,
            example,
            ...info,
            options: shuffle(
              letter.nonjoining
                ? ["isolated", "final"]
                : ["initial", "medial", "isolated", "final"],
              random,
            ),
            correct: info.shape,
          },
          {
            id: `position-${i}`,
            kind: "position",
            letter: char,
            example,
            ...info,
            options: shuffle(["start", "middle", "end"], random),
            correct: info.position,
          },
        ];
      }),
      random,
    );
  }
  function isCorrectAnswer(q, answer) {
    if (q.kind !== "circle") return answer === q.correct;
    return (
      Array.isArray(answer) &&
      answer.length === q.correct.length &&
      new Set(answer).size === answer.length &&
      answer.every((index) => q.correct.includes(index))
    );
  }
  const api = {
    banks,
    modes,
    wordInfo,
    createLetterQuestions,
    isCorrectAnswer,
  };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else window.ArabicLetterFocused = api;
})();
