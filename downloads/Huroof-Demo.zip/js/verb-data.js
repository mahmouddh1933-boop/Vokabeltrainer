(() => {
  "use strict";
  // Stems are explicit. Exceptional verbs use complete, separately reviewed paradigms.
  const verbs = [{"id":"write","pastStem":"كَتَب","presentStem":"كْتُب","imperativeStem":"اُكْتُب","meaning":{"ar":"الكتابة","de":"schreiben"},"kind":"sound","example":{"past":["كَتَبَ رِسَالَةً.","Er schrieb einen Brief."],"present":["يَكْتُبُ رِسَالَةً.","Er schreibt einen Brief."],"imperative":["اُكْتُبْ رِسَالَةً.","Schreib einen Brief."]},"formLength":3},{"id":"study","pastStem":"دَرَس","presentStem":"دْرُس","imperativeStem":"اُدْرُس","meaning":{"ar":"الدراسة","de":"lernen / studieren"},"kind":"sound","example":{"past":["دَرَسَ جَيِّدًا.","Er lernte gründlich."],"present":["يَدْرُسُ جَيِّدًا.","Er lernt gründlich."],"imperative":["اُدْرُسْ جَيِّدًا.","Lerne gründlich."]},"formLength":3},{"id":"open","pastStem":"فَتَح","presentStem":"فْتَح","imperativeStem":"اِفْتَح","meaning":{"ar":"الفَتْح","de":"öffnen"},"kind":"sound","example":{"past":["فَتَحَ بَابًا.","Er öffnete eine Tür."],"present":["يَفْتَحُ بَابًا.","Er öffnet eine Tür."],"imperative":["اِفْتَحْ بَابًا.","Öffne eine Tür."]},"formLength":3},{"id":"drink","pastStem":"شَرِب","presentStem":"شْرَب","imperativeStem":"اِشْرَب","meaning":{"ar":"الشُّرْب","de":"trinken"},"kind":"sound","example":{"past":["شَرِبَ مَاءً.","Er trank Wasser."],"present":["يَشْرَبُ مَاءً.","Er trinkt Wasser."],"imperative":["اِشْرَبْ مَاءً.","Trink Wasser."]},"formLength":3},{"id":"play","pastStem":"لَعِب","presentStem":"لْعَب","imperativeStem":"اِلْعَب","meaning":{"ar":"اللَّعِب","de":"spielen"},"kind":"sound","example":{"past":["لَعِبَ بِالْكُرَةِ.","Er spielte mit dem Ball."],"present":["يَلْعَبُ بِالْكُرَةِ.","Er spielt mit dem Ball."],"imperative":["اِلْعَبْ بِالْكُرَةِ.","Spiel mit dem Ball."]},"formLength":3},{"id":"hear","pastStem":"سَمِع","presentStem":"سْمَع","imperativeStem":"اِسْمَع","meaning":{"ar":"السَّماع","de":"hören"},"kind":"sound","example":{"past":["سَمِعَ جَيِّدًا.","Er hörte gut zu."],"present":["يَسْمَعُ جَيِّدًا.","Er hört gut zu."],"imperative":["اِسْمَعْ جَيِّدًا.","Hör gut zu."]},"formLength":3}];
  const pronouns = [
    {
      ar: "أَنَا",
      de: "ich",
      description: "المتكلّم المفرد",
      past: "ْتُ",
      present: ["أَ", "ُ"],
    },
    {
      ar: "نَحْنُ",
      de: "wir",
      description: "المتكلّم الجمع أو المثنّى",
      past: "ْنَا",
      present: ["نَ", "ُ"],
    },
    {
      ar: "أَنْتَ",
      de: "du · männlich",
      description: "المخاطب المفرد المذكّر",
      past: "ْتَ",
      present: ["تَ", "ُ"],
    },
    {
      ar: "أَنْتِ",
      de: "du · weiblich",
      description: "المخاطب المفرد المؤنّث",
      past: "ْتِ",
      present: ["تَ", "ِينَ"],
    },
    {
      ar: "أَنْتُمَا",
      de: "ihr zwei · männlich / gemischt",
      description: "المخاطب المثنّى المذكّر",
      past: "ْتُمَا",
      present: ["تَ", "َانِ"],
    },
    {
      ar: "أَنْتُمَا",
      de: "ihr zwei · weiblich",
      description: "المخاطب المثنّى المؤنّث",
      past: "ْتُمَا",
      present: ["تَ", "َانِ"],
    },
    {
      ar: "أَنْتُمْ",
      de: "ihr · männlich / gemischt",
      description: "المخاطب الجمع المذكّر",
      past: "ْتُمْ",
      present: ["تَ", "ُونَ"],
    },
    {
      ar: "أَنْتُنَّ",
      de: "ihr · weiblich",
      description: "المخاطب الجمع المؤنّث",
      past: "ْتُنَّ",
      present: ["تَ", "ْنَ"],
    },
    {
      ar: "هُوَ",
      de: "er",
      description: "الغائب المفرد المذكّر",
      past: "َ",
      present: ["يَ", "ُ"],
    },
    {
      ar: "هِيَ",
      de: "sie · Einzahl",
      description: "الغائب المفرد المؤنّث",
      past: "َتْ",
      present: ["تَ", "ُ"],
    },
    {
      ar: "هُمَا",
      de: "sie zwei · männlich / gemischt",
      description: "الغائب المثنّى المذكّر",
      past: "َا",
      present: ["يَ", "َانِ"],
    },
    {
      ar: "هُمَا",
      de: "sie zwei · weiblich",
      description: "الغائب المثنّى المؤنّث",
      past: "َتَا",
      present: ["تَ", "َانِ"],
    },
    {
      ar: "هُمْ",
      de: "sie · männlich / gemischt",
      description: "الغائب الجمع المذكّر",
      past: "ُوا",
      present: ["يَ", "ُونَ"],
    },
    {
      ar: "هُنَّ",
      de: "sie · weiblich",
      description: "الغائب الجمع المؤنّث",
      past: "ْنَ",
      present: ["يَ", "ْنَ"],
    },
  ];

  pronouns.forEach((person, index) => {
    person.index = index;
  });
  const commandIndices = { 2: 0, 3: 1, 4: 2, 5: 2, 6: 3, 7: 4 };
  const imperativePronouns = [
    pronouns[2],
    pronouns[3],
    {
      ...pronouns[4],
      description: "المخاطب المثنّى المذكّر والمؤنّث",
      de: "ihr zwei · beide Geschlechter",
    },
    pronouns[6],
    pronouns[7],
  ];
  const commandEndings = ["ْ", "ِي", "َا", "ُوا", "ْنَ"];
  function pronounsFor(tense) {
    return tense === "imperative" ? imperativePronouns : pronouns;
  }
  function parts(verb, tense, person) {
    if (!["past", "present", "imperative"].includes(tense)) return null;
    const commandIndex = commandIndices[person.index];
    if (tense === "imperative" && commandIndex === undefined) return null;
    if (verb.forms) {
      const form =
        verb.forms[tense][tense === "imperative" ? commandIndex : person.index];
      let prefix =
        tense === "present" && form.startsWith(person.present[0])
          ? person.present[0]
          : "";
      let suffix =
        tense === "past"
          ? person.past
          : tense === "present"
            ? person.present[1]
            : commandEndings[commandIndex];
      // Contracted hamza spellings (e.g. قَرَآ) cannot be split at a suffix boundary.
      if (!form.endsWith(suffix)) suffix = "";
      return [
        prefix,
        form.slice(prefix.length, suffix ? -suffix.length : undefined),
        suffix,
      ];
    }
    const combine = (prefix, stem, suffix) =>
      stem.endsWith("ن") && suffix === "ْنَ"
        ? [prefix, stem.slice(0, -1) + "نَّ", ""]
        : [prefix, stem, suffix];
    if (tense === "past") return combine("", verb.pastStem, person.past);
    if (tense === "present")
      return combine(
        person.present[0][0] + (verb.presentVowel || "َ"),
        verb.presentStem,
        person.present[1],
      );
    const prefix = /^[اأإ]/u.test(verb.imperativeStem)
      ? verb.imperativeStem.slice(0, 2)
      : "";
    return combine(
      prefix,
      verb.imperativeStem.slice(prefix.length),
      commandEndings[commandIndex],
    );
  }
  function conjugate(verb, tense, person) {
    const segments = parts(verb, tense, person);
    return segments ? segments.join("") : null;
  }
  const data = {
    verbs,
    pronouns,
    imperativePronouns,
    pronounsFor,
    parts,
    conjugate,
  };
  if (typeof module !== "undefined" && module.exports) module.exports = data;
  else window.VerbLessonData = data;
})();
