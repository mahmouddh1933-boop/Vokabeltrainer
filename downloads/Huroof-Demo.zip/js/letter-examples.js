(() => {
  "use strict";
  // Each row: letter, initial, medial, separated final, connected final.
  // The separated final is always preceded by ا د ذ ر ز و (including أ).
  const rows = [["أ",["أسد","Löwe"],["سأل","fragte"],["قرأ","las"],["ملأ","füllte"]],["ب",["بطة","Ente"],["جبل","Berg"],["باب","Tür"],["كلب","Hund"]],["ت",["تفاح","Äpfel"],["كتاب","Buch"],["نبات","Pflanze"],["بيت","Haus"]],["ث",["ثعلب","Fuchs"],["مثلث","Dreieck"],["إرث","Erbe"],["بحث","Suche"]],["ج",["جمل","Kamel"],["نجم","Stern"],["تاج","Krone"],["ثلج","Schnee"]],["ح",["حصان","Pferd"],["بحر","Meer"],["تفاح","Äpfel"],["ملح","Salz"]]];
  const examples = Object.fromEntries(
    rows.map(([letter, ...words]) => [
      letter,
      words.map(([word, de], position) => ({
        word,
        de,
        index:
          position === 0 ? 0 : position === 1 ? 1 : Array.from(word).length - 1,
      })),
    ]),
  );
  const nonJoining = new Set(Array.from("اأإآدذرزو"));
  function graphemes(word) {
    const result = [];
    for (const char of word) {
      if (/\p{M}/u.test(char) && result.length)
        result[result.length - 1] += char;
      else result.push(char);
    }
    return result;
  }
  function highlight(container, word, index) {
    const clusters = graphemes(word);
    const target = document.createElement("mark");
    target.className = "letter-target";
    target.textContent = clusters[index];
    container.replaceChildren(
      document.createTextNode(clusters.slice(0, index).join("")),
      target,
      document.createTextNode(clusters.slice(index + 1).join("")),
    );
  }
  const api = { examples, nonJoining, graphemes, highlight };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else window.ArabicLetterExamples = api;
})();
