(() => {
  "use strict";
  window.JisrStorage.local.setScope("huroof-demo-v1");
  window.JisrStorage.session.setScope("huroof-demo-v1");
  if (!window.JisrStorage.local.getItem("vocabInterfaceLanguage"))
    window.JisrStorage.local.setItem("vocabInterfaceLanguage", "de");
  // Direct links to cards/tests also have a useful starting list. This keeps
  // the demo interactive when a file viewer blocks persistent browser storage.
  if (!window.JisrStorage.local.getItem("vocabList")) {
    const first = {"id":"a1_01","title":"التحيات والتعارف","titleDe":"Begrüßung und Kennenlernen","goal":"أحيي الآخرين وأبدأ تعارفاً قصيراً.","count":20,"words":[{"ar":"مَرْحَباً","de":"Hallo"},{"ar":"أَهْلاً وَسَهْلاً","de":"Herzlich willkommen"},{"ar":"صَبَاحُ الْخَيْرِ","de":"Guten Morgen"},{"ar":"مَسَاءُ الْخَيْرِ","de":"Guten Abend"},{"ar":"مَعَ السَّلَامَةِ","de":"Auf Wiedersehen"},{"ar":"إِلَى اللِّقَاءِ","de":"Bis bald"},{"ar":"شُكْراً","de":"Danke"},{"ar":"عَفْواً","de":"Gern geschehen"},{"ar":"مِنْ فَضْلِكَ","de":"Bitte (zu einem Mann)"},{"ar":"مِنْ فَضْلِكِ","de":"Bitte (zu einer Frau)"},{"ar":"آسِفٌ","de":"Entschuldigung (von einem Mann)"},{"ar":"آسِفَةٌ","de":"Entschuldigung (von einer Frau)"},{"ar":"نَعَمْ","de":"Ja"},{"ar":"لَا","de":"Nein"},{"ar":"تَفَضَّلْ","de":"Bitte sehr (zu einem Mann)"},{"ar":"تَفَضَّلِي","de":"Bitte sehr (zu einer Frau)"},{"ar":"أَنَا بِخَيْرٍ","de":"Mir geht es gut"},{"ar":"كَيْفَ حَالُكَ؟","de":"Wie geht es dir? (männlich)"},{"ar":"مَا اسْمُكِ؟","de":"Wie heißt du? (weiblich)"},{"ar":"تَشَرَّفْنَا","de":"Angenehm, dich kennenzulernen"}],"level":"A1","levelOrder":1};
    window.JisrStorage.local.setItem("vocabList", JSON.stringify(first.words.map(w=>[w.ar,w.de])));
    window.JisrStorage.local.setItem("currentVocabSource", JSON.stringify({type:"ready-list",id:first.id,cefr:first.level,title:first.title,count:first.words.length}));
  }
  window.JisrStorage.ready(() => {
    const main = document.querySelector("main");
    const note = document.createElement("aside");
    note.className = "demo-notice";
    note.setAttribute("aria-label", "Demo / نسخة تجريبية");
    note.innerHTML = '<strong data-de="DEMO · حروف من الزيتون" data-ar="نسخة تجريبية · حروف من الزيتون">DEMO · حروف من الزيتون</strong><span data-de="Ohne Anmeldung. Dein Fortschritt bleibt in diesem Browser. Eine Auswahl der Lerninhalte ist enthalten." data-ar="بلا تسجيل دخول. يُحفظ التقدّم في هذا المتصفح فقط. تتضمن النسخة مختارات من المحتوى.">Ohne Anmeldung. Dein Fortschritt bleibt in diesem Browser. Eine Auswahl der Lerninhalte ist enthalten.</span>';
    main.prepend(note);
    window.AppLanguage?.translate();
  });
})();
