(function(){ "use strict"; window.JisrStorage.ready(async()=>{ const app=window.VocabApp; document.getElementById("wrong-total").textContent=app.getWrongWords().length; document.getElementById("mastered-lists-total").textContent=app.getMasterySummary().masteredLists; document.getElementById("tests-total").textContent=app.getStats().totalTests||0; renderLearningPath(await app.loadCatalog(),document.getElementById("learning-path")); });
  function listSource(list, level) {
    return {
      type: "ready-list",
      id: list.id,
      cefr: level?.cefr || level?.id || null,
      levelId: level?.id || null,
      levelTitle: level
        ? `${level.title}${level.subtitle ? ` · ${level.subtitle}` : ""}`
        : "",
      title: list.title,
      count: (list.words || []).length,
    };
  }

  function renderLearningPath(catalog, target) {
    const lists = Array.isArray(catalog.lists) ? catalog.lists : [];
    const levels =
      Array.isArray(catalog.levels) && catalog.levels.length
        ? catalog.levels
        : [
            {
              id: "A1",
              cefr: "A1",
              title: "المستوى A1",
              subtitle: "المبتدئ",
              description: "",
              listIds: lists.map((list) => list.id),
            },
          ];
    const byId = new Map(lists.map((list) => [list.id, list]));
    target.innerHTML = "";
    const levelGrid = document.createElement("div");
    levelGrid.className = "cefr-level-grid";
    target.appendChild(levelGrid);
    const detailsHost = document.createElement("div");
    detailsHost.className = "cefr-level-details-host";
    target.appendChild(detailsHost);

    const advanced = document.createElement("details");
    const summary = document.createElement("summary");
    summary.dataset.ar = "للتوسّع: B1 وB2";
    summary.dataset.de = "Vertiefung: B1 und B2";
    summary.textContent =
      summary.dataset[window.AppLanguage?.get() === "de" ? "de" : "ar"];
    advanced.append(summary);
    const advancedGrid = document.createElement("div");
    advancedGrid.className = "cefr-level-grid";
    advanced.append(advancedGrid);
    target.append(advanced);
    const query = new URLSearchParams(location.search),
      requestedLevel = query.get("level");
    const initialLevel = levels.some((l) => l.id === requestedLevel)
      ? requestedLevel
      : levels[0].id;
    levels.forEach((level, levelIndex) => {
      const levelLists = (level.listIds || [])
        .map((id) => byId.get(id))
        .filter(Boolean);
      const levelStats = getLevelStats(level, levelLists);
      const button = document.createElement("button");
      button.type = "button";
      button.className = "cefr-level-card";
      button.dataset.levelId = level.id;
      button.setAttribute("aria-pressed", String(level.id === initialLevel));
      button.innerHTML = `
                <span class="cefr-level-code">${VocabApp.escapeHTML(level.cefr || level.id)}</span>
                <span class="cefr-level-copy">
                    <span class="cefr-level-title-row"><strong>${VocabApp.escapeHTML(level.title || level.id)}</strong>${level.recommended ? '<span class="recommended-badge">ابدأ من هنا</span>' : ""}</span>
                    <small>${VocabApp.escapeHTML(level.subtitle || "")}</small>
                    <span class="cefr-level-description">${VocabApp.escapeHTML(level.description || "")}</span>
                    <span class="cefr-level-meta">${levelLists.length} مواضيع · ${levelStats.totalWords} مفردة · ${levelStats.masteredLists}/${levelLists.length} قوائم متقنة</span>
                    <span class="cefr-progress-track"><span style="width:${levelStats.percent}%"></span></span>
                    <span class="cefr-progress-label">${levelStats.percent}٪ تقدّم نحو الإتقان</span>
                </span>`;
      button.addEventListener("click", () => {
        const url = new URL(location.href);
        if (url.searchParams.has("level")) {
          if (url.searchParams.get("level") !== level.id)
            url.searchParams.delete("list");
          url.searchParams.set("level", level.id);
          history.replaceState(null, "", url.pathname + url.search + url.hash);
        }
        target.querySelectorAll(".cefr-level-card").forEach((item) => {
          item.classList.remove("active");
          item.setAttribute("aria-pressed", "false");
        });
        button.classList.add("active");
        button.setAttribute("aria-pressed", "true");
        renderLevelDetails(level, levelLists, detailsHost);
        setTimeout(
          () =>
            detailsHost.scrollIntoView({
              behavior: "smooth",
              block: "nearest",
            }),
          20,
        );
      });
      (["B1", "B2"].includes(level.id) ? advancedGrid : levelGrid).appendChild(
        button,
      );
      if (level.id === initialLevel) {
        button.classList.add("active");
        renderLevelDetails(level, levelLists, detailsHost);
      }
    });
  }

  function getLevelStats(level, levelLists) {
    let totalWords = 0,
      masteredLists = 0,
      completed = 0,
      required = 0;
    levelLists.forEach((list) => {
      totalWords += (list.words || []).length;
      const progress = VocabApp.getListProgress(
        list.words,
        listSource(list, level),
      );
      completed += progress.completedPasses;
      required += progress.requiredPasses;
      if (progress.listMastered) masteredLists += 1;
    });
    return {
      totalWords,
      masteredLists,
      percent: required ? Math.round((completed / required) * 100) : 0,
    };
  }

  function renderLevelDetails(level, levelLists, host) {
    const stats = getLevelStats(level, levelLists);
    host.innerHTML = `
            <section class="cefr-detail-panel">
                <div class="level-heading">
                    <div><span class="cefr-detail-label">${VocabApp.escapeHTML(level.cefr || level.id)}</span><h3>${VocabApp.escapeHTML(level.title || level.id)} · ${VocabApp.escapeHTML(level.subtitle || "")}</h3><p>${VocabApp.escapeHTML(level.description || "")}</p></div>
                    <span class="level-progress-badge">${stats.percent}٪ تقدّم</span>
                </div>
                <div class="ready-lists-grid"></div>
            </section>`;

    const grid = host.querySelector(".ready-lists-grid");
    levelLists.forEach((list, index) => {
      const source = listSource(list, level);
      const progress = VocabApp.getListProgress(list.words, source);
      const button = document.createElement("button");
      button.type = "button";
      button.dataset.listId = list.id;
      button.className = `ready-list-button${progress.listMastered ? " mastered-list" : ""}`;
      button.innerHTML = `
                <span class="list-number">${progress.listMastered ? "✓" : index + 1}</span>
                <span class="list-button-text">
                    <strong>${VocabApp.escapeHTML(list.title)}</strong>
                    <small>${(list.words || []).length} مفردة · ${progress.completedPasses}/${progress.requiredPasses} محاولات إتقان ناجحة</small>
                    <span class="list-progress-line"><span style="width:${progress.masteryPercentage}%"></span></span>
                    <span class="list-mastery-percent">${progress.listMastered ? "متقنة 100٪" : `${progress.masteryPercentage}٪`}</span>
                </span>`;
      button.addEventListener("click", () => {
        const vocab = (list.words || [])
          .map((item) => [item.ar, item.de])
          .filter(([ar, de]) => ar && de);
        VocabApp.saveVocabList(vocab, source);
        window.location.href = "./lernseite.html";
      });
      if (new URLSearchParams(location.search).get("list") === list.id) {
        button.classList.add("placement-target-list");
        setTimeout(() => {
          button.scrollIntoView({ block: "center", behavior: "instant" });
          button.focus({ preventScroll: true });
        }, 40);
        button.setAttribute(
          "aria-label",
          list.title + " · القائمة المقترحة / Empfohlene Liste",
        );
      }
      grid.appendChild(button);
    });
  }
})();
