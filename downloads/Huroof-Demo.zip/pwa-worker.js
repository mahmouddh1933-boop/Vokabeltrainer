/* Generated for 68f6d9cfc0b6a92c. Public application files only. */
"use strict";
const RELEASE = "68f6d9cfc0b6a92c";
const ASSETS = {"audio/book-youth-two-part-one/a44924759b9f59.mp3":{"rev":"dc9fde6e5bfd288d","bytes":9792,"media":true},"audio/letter-related/01.mp3":{"rev":"48720b9abd2b7858","bytes":9024,"media":true},"audio/letter-related/02.mp3":{"rev":"751a77374426b04e","bytes":9216,"media":true},"audio/letter-related/03.mp3":{"rev":"df66c01c0437982e","bytes":8256,"media":true},"audio/letter-related/04.mp3":{"rev":"a9649b0327de4b4f","bytes":8448,"media":true},"audio/letter-related/05.mp3":{"rev":"ccfa08ce9f2c38e9","bytes":9408,"media":true},"audio/letter-related/06.mp3":{"rev":"4ce9facaeec8d5e3","bytes":8064,"media":true},"audio/letter-related/07.mp3":{"rev":"8c00a094d2badf2b","bytes":8640,"media":true},"audio/letter-related/08-waqf.mp3":{"rev":"c5802857496239c3","bytes":6103,"media":true},"audio/letter-related/09.mp3":{"rev":"615ea121f44b06c2","bytes":8448,"media":true},"audio/letter-related/10.mp3":{"rev":"57a2b831065f6f7d","bytes":11328,"media":true},"audio/letter-related/11.mp3":{"rev":"6ea88db56592831c","bytes":8640,"media":true},"audio/letters/01-clear-vowel-1.mp3":{"rev":"5dcf130df4d77a42","bytes":5685,"media":true},"audio/letters/01-name-waqf.mp3":{"rev":"b61750da6cf389db","bytes":8256,"media":true},"audio/letters/01-vowel-0.mp3":{"rev":"75207e2198f44c00","bytes":5760,"media":true},"audio/letters/01-vowel-2.mp3":{"rev":"1d6806c3748ab4aa","bytes":5952,"media":true},"audio/letters/01-vowel-3.mp3":{"rev":"2bcc139e2617fe1c","bytes":6912,"media":true},"audio/letters/01-word.mp3":{"rev":"71b7db8a12ae02ce","bytes":9024,"media":true},"audio/letters/02-name-waqf.mp3":{"rev":"fac1099704bde3ed","bytes":7872,"media":true},"audio/letters/02-vowel-0.mp3":{"rev":"626a4f3bd15b48a1","bytes":5760,"media":true},"audio/letters/02-vowel-1.mp3":{"rev":"a8676fe3a682de64","bytes":6144,"media":true},"audio/letters/02-vowel-2.mp3":{"rev":"c66a2656ac3a6907","bytes":5760,"media":true},"audio/letters/02-vowel-3.mp3":{"rev":"a536fb9fe433b76f","bytes":6144,"media":true},"audio/letters/02-word.mp3":{"rev":"5ef5e34e5083eed4","bytes":9216,"media":true},"audio/letters/03-name-waqf.mp3":{"rev":"e9c9fa3442c55bbf","bytes":7872,"media":true},"audio/letters/03-vowel-0.mp3":{"rev":"0aaa727f656d876b","bytes":5952,"media":true},"audio/letters/03-vowel-1.mp3":{"rev":"64c06647d103724a","bytes":6336,"media":true},"audio/letters/03-vowel-2.mp3":{"rev":"f017d24df8699b9c","bytes":6144,"media":true},"audio/letters/03-vowel-3.mp3":{"rev":"3a89ed6671ec5887","bytes":5760,"media":true},"audio/letters/03-word.mp3":{"rev":"21602dd8d32318d8","bytes":11904,"media":true},"audio/letters/04-name-waqf.mp3":{"rev":"10f27601f4db3560","bytes":8064,"media":true},"audio/letters/04-vowel-0.mp3":{"rev":"7ff741ca794ede02","bytes":6912,"media":true},"audio/letters/04-vowel-1.mp3":{"rev":"efdf09a958765b06","bytes":6912,"media":true},"audio/letters/04-vowel-2.mp3":{"rev":"3571bfe638d7c72b","bytes":6336,"media":true},"audio/letters/04-vowel-3.mp3":{"rev":"237e0890cf143909","bytes":5568,"media":true},"audio/letters/04-word.mp3":{"rev":"e8c8e215397db1e4","bytes":9792,"media":true},"audio/letters/05-clear-name-waqf.mp3":{"rev":"1f169c917f172e69","bytes":7566,"media":true},"audio/letters/05-vowel-0.mp3":{"rev":"01590e57142542c5","bytes":6336,"media":true},"audio/letters/05-vowel-1.mp3":{"rev":"2aeb0f3234a6a611","bytes":6528,"media":true},"audio/letters/05-vowel-2.mp3":{"rev":"c28ad479c52a362a","bytes":6144,"media":true},"audio/letters/05-vowel-3.mp3":{"rev":"df54535f48b3dbf6","bytes":6336,"media":true},"audio/letters/05-word.mp3":{"rev":"60d56aef22e93c4e","bytes":8832,"media":true},"audio/letters/06-name-waqf.mp3":{"rev":"9035dab033adb8a3","bytes":7872,"media":true},"audio/letters/06-vowel-0.mp3":{"rev":"ada4019d6b234c4f","bytes":6528,"media":true},"audio/letters/06-vowel-1.mp3":{"rev":"2376fd34b756ca26","bytes":6912,"media":true},"audio/letters/06-vowel-2.mp3":{"rev":"bd69ad17cb6337e6","bytes":6528,"media":true},"audio/letters/06-vowel-3.mp3":{"rev":"42498a21907b4739","bytes":6528,"media":true},"audio/letters/06-word.mp3":{"rev":"d49f60636cca2e28","bytes":9792,"media":true},"audio/practice/001.mp3":{"rev":"c3b9a24fad6a693c","bytes":6912,"media":true},"audio/practice/002.mp3":{"rev":"3f8d2e3fb29e2415","bytes":8064,"media":true},"audio/practice/003.mp3":{"rev":"a71555a11f0f9025","bytes":6912,"media":true},"audio/practice/004.mp3":{"rev":"6f647eacd5a52367","bytes":7296,"media":true},"audio/practice/005.mp3":{"rev":"418f0a1b4e4f4a31","bytes":7296,"media":true},"audio/practice/006.mp3":{"rev":"9c9afd5fc0c58646","bytes":8832,"media":true},"audio/practice/007.mp3":{"rev":"15be3daf2f21703d","bytes":8832,"media":true},"audio/practice/008.mp3":{"rev":"9f31f1613cd89056","bytes":8832,"media":true},"audio/practice/009.mp3":{"rev":"e36bb5f4712d185c","bytes":7872,"media":true},"audio/practice/010.mp3":{"rev":"d7df56bc060e5aea","bytes":7680,"media":true},"audio/practice/011.mp3":{"rev":"5099f3255fe9d4b0","bytes":8832,"media":true},"audio/practice/012.mp3":{"rev":"e546fd88efd26817","bytes":6912,"media":true},"audio/practice/037.mp3":{"rev":"f315533da6eaddcb","bytes":12864,"media":true},"audio/practice/038.mp3":{"rev":"eb980c3a5c114423","bytes":14016,"media":true},"audio/practice/039.mp3":{"rev":"20247360b140da15","bytes":14784,"media":true},"audio/practice/049.mp3":{"rev":"6cb7119af59ba3b1","bytes":26688,"media":true},"audio/practice/050.mp3":{"rev":"729be7f727d209ce","bytes":24192,"media":true},"audio/practice/051.mp3":{"rev":"5423127e0938c934","bytes":23232,"media":true},"audio/practice/061.mp3":{"rev":"331c86a70259315d","bytes":10176,"media":true},"audio/practice/062.mp3":{"rev":"c195436a141381e2","bytes":25152,"media":true},"audio/practice/063.mp3":{"rev":"3beed06227143e1e","bytes":23808,"media":true},"audio/practice/064.mp3":{"rev":"23424be5e3e9d9fa","bytes":31872,"media":true},"audio/practice/065.mp3":{"rev":"7f1dfeba9ba067ad","bytes":21120,"media":true},"audio/practice/066.mp3":{"rev":"5be1ec84f66c3553","bytes":27840,"media":true},"audio/practice/067.mp3":{"rev":"f50801ce1346e693","bytes":7104,"media":true},"audio/practice/068.mp3":{"rev":"83cb5685b52e09fe","bytes":8064,"media":true},"audio/practice/069.mp3":{"rev":"872163b2db9a2041","bytes":8832,"media":true},"audio/practice/070.mp3":{"rev":"4e309c0390bd3216","bytes":8640,"media":true},"audio/vocabulary/00a40ef53a688571.mp3":{"rev":"7bfd492337b452dc","bytes":5973,"media":true},"audio/vocabulary/0677bab4129c18cb.mp3":{"rev":"70a94f134275422a","bytes":8272,"media":true},"audio/vocabulary/086a19cb213e0bce.mp3":{"rev":"339c39338cd78d3c","bytes":5137,"media":true},"audio/vocabulary/08f3fa9b48704ba0.mp3":{"rev":"ceb5be04b79b94ed","bytes":5242,"media":true},"audio/vocabulary/0e788d95721c9234.mp3":{"rev":"0dc298f0eb0af184","bytes":5242,"media":true},"audio/vocabulary/0fd3e2871825bab1.mp3":{"rev":"172af9a5ea6d9958","bytes":5346,"media":true},"audio/vocabulary/1122cd44d8be026d.mp3":{"rev":"18f8b32d7a34047a","bytes":6077,"media":true},"audio/vocabulary/11d120f0d087992a.mp3":{"rev":"92c8647b0738c60e","bytes":4824,"media":true},"audio/vocabulary/129503fc9b5acdfe.mp3":{"rev":"283167521cd49ac1","bytes":6286,"media":true},"audio/vocabulary/146d33bae261dd95.mp3":{"rev":"23ec7a223ed8d6c8","bytes":6182,"media":true},"audio/vocabulary/15dcaa7f18611f44.mp3":{"rev":"b962ee36cae35ffd","bytes":5033,"media":true},"audio/vocabulary/173ac6aa48662e74.mp3":{"rev":"d18a77edb75f371f","bytes":8376,"media":true},"audio/vocabulary/191d6716a195d6b1.mp3":{"rev":"a947ef59643271c5","bytes":5346,"media":true},"audio/vocabulary/1b5127fff74d81f9.mp3":{"rev":"8a7ebe10ff7a82da","bytes":5973,"media":true},"audio/vocabulary/1bff2b353d71a4fa.mp3":{"rev":"10a87ecc1c829145","bytes":7540,"media":true},"audio/vocabulary/21053365427a050d.mp3":{"rev":"23f5762be9de7e91","bytes":8272,"media":true},"audio/vocabulary/22a49bf9de1343ef.mp3":{"rev":"491cba7d40ede7a3","bytes":5659,"media":true},"audio/vocabulary/246ad64d7f82c15d.mp3":{"rev":"00d20259b9474d12","bytes":4406,"media":true},"audio/vocabulary/2681a62a6a592449.mp3":{"rev":"ee1ada9134d1f487","bytes":5242,"media":true},"audio/vocabulary/285ec316e98800fc.mp3":{"rev":"11ea2be9bcd3f94f","bytes":5659,"media":true},"audio/vocabulary/2964d9aed576c65b.mp3":{"rev":"78acaa74485f1073","bytes":7122,"media":true},"audio/vocabulary/2e8677e9bf67f881.mp3":{"rev":"39bd446dade2a82f","bytes":5242,"media":true},"audio/vocabulary/353785dbb08b3343.mp3":{"rev":"b047456c04e93e6e","bytes":5242,"media":true},"audio/vocabulary/35a37b63632fe86d.mp3":{"rev":"93ba3da9b9505042","bytes":7018,"media":true},"audio/vocabulary/35b7a442b636570d.mp3":{"rev":"064306c833815e38","bytes":5764,"media":true},"audio/vocabulary/36a0fa5154e06d54.mp3":{"rev":"df9e5989e2d9b099","bytes":5242,"media":true},"audio/vocabulary/395c71e6d5eb21d2.mp3":{"rev":"1431a9a11737dd2a","bytes":5242,"media":true},"audio/vocabulary/39c9cbaf1a2a3aec.mp3":{"rev":"dece5371aa3110a0","bytes":4301,"media":true},"audio/vocabulary/3bf7936d0055358e.mp3":{"rev":"d83c52aa19704a1f","bytes":5242,"media":true},"audio/vocabulary/3e573a564c51d372.mp3":{"rev":"fd60e5eb15d60762","bytes":8272,"media":true},"audio/vocabulary/3effd34bcebe746a.mp3":{"rev":"dd59bf55d83eacfa","bytes":5868,"media":true},"audio/vocabulary/3fc184bff1954fd9.mp3":{"rev":"f251e5b3633e6b9e","bytes":5659,"media":true},"audio/vocabulary/40cce9c4903d3fda.mp3":{"rev":"122a4d3d4abd3c21","bytes":8794,"media":true},"audio/vocabulary/41b775fca7f4ef87.mp3":{"rev":"0fedecf993a47e7e","bytes":6286,"media":true},"audio/vocabulary/444f681a8dcd2628.mp3":{"rev":"138147792d9a432e","bytes":5033,"media":true},"audio/vocabulary/4b83fb0d246eab09.mp3":{"rev":"47ac125100e3bd45","bytes":4510,"media":true},"audio/vocabulary/525a0ec4529cb186.mp3":{"rev":"11e482e93e93a783","bytes":7018,"media":true},"audio/vocabulary/59ef98fa91018ea7.mp3":{"rev":"ab127861e2f022c7","bytes":5659,"media":true},"audio/vocabulary/5a7c0b8e81910272.mp3":{"rev":"271a88c44862f137","bytes":6077,"media":true},"audio/vocabulary/5ae0e0bc8ee034ff.mp3":{"rev":"451dc0e3524b64b0","bytes":7540,"media":true},"audio/vocabulary/5ee3420629e42c61.mp3":{"rev":"cf0685da29cbc233","bytes":5242,"media":true},"audio/vocabulary/60d7172d1cb70909.mp3":{"rev":"5c00849416d44634","bytes":5242,"media":true},"audio/vocabulary/611cb8e183374bdd.mp3":{"rev":"001377b91e42b584","bytes":4301,"media":true},"audio/vocabulary/634be5dd7249dde2.mp3":{"rev":"af2792ca56ea3d71","bytes":6286,"media":true},"audio/vocabulary/635a55cb3785ded8.mp3":{"rev":"6a6894782ea5e8c4","bytes":5450,"media":true},"audio/vocabulary/6623d347fdf3ff82.mp3":{"rev":"163f417ff718913e","bytes":4092,"media":true},"audio/vocabulary/681d81630151d5e3.mp3":{"rev":"c22f16db8c72dc3a","bytes":8376,"media":true},"audio/vocabulary/6a7af2fa24d6baec.mp3":{"rev":"3f63cffa9f10650a","bytes":5242,"media":true},"audio/vocabulary/6b9e265a4dcbfe67.mp3":{"rev":"7726d66a1becec39","bytes":8376,"media":true},"audio/vocabulary/6d4cfed94f3d3812.mp3":{"rev":"ef4916f772af353a","bytes":4615,"media":true},"audio/vocabulary/6df078120cdd04ce.mp3":{"rev":"90877ceeb468235e","bytes":5450,"media":true},"audio/vocabulary/6f13bedff4a8cccb.mp3":{"rev":"10ecb07d64743537","bytes":5450,"media":true},"audio/vocabulary/708330f41924b613.mp3":{"rev":"fa51a5d9620ff9d2","bytes":5450,"media":true},"audio/vocabulary/7866d6255d473f36.mp3":{"rev":"556333af4b46c427","bytes":5659,"media":true},"audio/vocabulary/7aa44dfb8849e492.mp3":{"rev":"36203bca2db582d6","bytes":4719,"media":true},"audio/vocabulary/7b14bc22a15552ac.mp3":{"rev":"56ea4cedc7120c76","bytes":7540,"media":true},"audio/vocabulary/7c4c931e972fad38.mp3":{"rev":"53f98aa8fe584db8","bytes":4092,"media":true},"audio/vocabulary/7f67761848e0b268.mp3":{"rev":"1fa1d200bbec5a22","bytes":9212,"media":true},"audio/vocabulary/7fc2d4779047bafd.mp3":{"rev":"5eb3edaffe4b3c69","bytes":4824,"media":true},"audio/vocabulary/8120c07e66821a64.mp3":{"rev":"398132d8848b30f5","bytes":4824,"media":true},"audio/vocabulary/869852ef116effd7.mp3":{"rev":"f41be7d4785dc2c7","bytes":5868,"media":true},"audio/vocabulary/89fe156768ac829e.mp3":{"rev":"0046a9260f8a819d","bytes":5555,"media":true},"audio/vocabulary/8bb6c30ec6fca5f0.mp3":{"rev":"18f4f76fd6172f1d","bytes":4615,"media":true},"audio/vocabulary/8fdcd5cfbc9c4976.mp3":{"rev":"0276b0773032646f","bytes":5346,"media":true},"audio/vocabulary/91d99696e0c1b4ae.mp3":{"rev":"817c847af7a97279","bytes":6495,"media":true},"audio/vocabulary/92d12f77741cc09e.mp3":{"rev":"b1655fe56301e8fe","bytes":4719,"media":true},"audio/vocabulary/92e78dcac13c4426.mp3":{"rev":"3f5cd43c9b185992","bytes":7018,"media":true},"audio/vocabulary/93fc6f172eda9331.mp3":{"rev":"6fca9aa7fed0f999","bytes":4406,"media":true},"audio/vocabulary/944b76b338bb0168.mp3":{"rev":"9891be60ff1e706a","bytes":7958,"media":true},"audio/vocabulary/9523730f63ab82ef.mp3":{"rev":"a2ac5910eb48341b","bytes":5555,"media":true},"audio/vocabulary/9ba6bd16b22e2e0b.mp3":{"rev":"b0f83c7bde4c161e","bytes":6600,"media":true},"audio/vocabulary/9bf161cba0415c23.mp3":{"rev":"45181909c8723805","bytes":4301,"media":true},"audio/vocabulary/9c06462c59bdb5e5.mp3":{"rev":"b3599c5119d969e5","bytes":4719,"media":true},"audio/vocabulary/9e4d635c6580789d.mp3":{"rev":"955a746d2b4b20a7","bytes":5033,"media":true},"audio/vocabulary/9ea4e00501904dde.mp3":{"rev":"d55914fd8d878224","bytes":8272,"media":true},"audio/vocabulary/a0a2f765730106b4.mp3":{"rev":"89fb15d8a069621a","bytes":5764,"media":true},"audio/vocabulary/a4e8ac8696fd9d09.mp3":{"rev":"e8514d7771774118","bytes":3361,"media":true},"audio/vocabulary/ad439d43b7fa2c63.mp3":{"rev":"19e4845aedbfbfbf","bytes":10048,"media":true},"audio/vocabulary/ae28b818e32b04de.mp3":{"rev":"5d42d89680705185","bytes":6600,"media":true},"audio/vocabulary/afc8dba5da27ba2d.mp3":{"rev":"2ad91641d6e914c8","bytes":5137,"media":true},"audio/vocabulary/b004da763375b683.mp3":{"rev":"62f92bfcdf690c2c","bytes":5033,"media":true},"audio/vocabulary/b018b55d9b702c71.mp3":{"rev":"7859844f2d135980","bytes":6182,"media":true},"audio/vocabulary/b3928e059ca109eb.mp3":{"rev":"c7d5d68ab8c94e2c","bytes":5346,"media":true},"audio/vocabulary/b423874aff5c85c0.mp3":{"rev":"ac787f8a17c4912c","bytes":5659,"media":true},"audio/vocabulary/b44d09540859ef67.mp3":{"rev":"bc63183b1ff9db15","bytes":8794,"media":true},"audio/vocabulary/b6de6280578acde5.mp3":{"rev":"fbcfa3fc9eefe465","bytes":5346,"media":true},"audio/vocabulary/b9df3a0d2b7e1659.mp3":{"rev":"b2d0602d7d83b59e","bytes":4510,"media":true},"audio/vocabulary/bce7eaf5edd3cf9d.mp3":{"rev":"8e5cf267b7af7d83","bytes":5033,"media":true},"audio/vocabulary/bd3a4adb3f52c948.mp3":{"rev":"51c93c89e13ae081","bytes":5242,"media":true},"audio/vocabulary/bf5ee12d1c0831ce.mp3":{"rev":"22a810da267df912","bytes":6495,"media":true},"audio/vocabulary/c0cb13e1d916f3eb.mp3":{"rev":"38609d8b8db59d13","bytes":7122,"media":true},"audio/vocabulary/c1b1dca269fea156.mp3":{"rev":"6bb442543566fc09","bytes":5973,"media":true},"audio/vocabulary/c459a179f5a56b77.mp3":{"rev":"5d1567a8da04d485","bytes":4824,"media":true},"audio/vocabulary/c67eb923a27116b9.mp3":{"rev":"5d567be83f52bf7e","bytes":4719,"media":true},"audio/vocabulary/c6ce5b65970832b9.mp3":{"rev":"704bfa8503850a67","bytes":9317,"media":true},"audio/vocabulary/cfff019ded574d00.mp3":{"rev":"04ae257f87631e2d","bytes":6182,"media":true},"audio/vocabulary/d0e4e629272c1f73.mp3":{"rev":"13cd3ca69b3809ed","bytes":7749,"media":true},"audio/vocabulary/d19f27e0fd12cd53.mp3":{"rev":"db2296d8e5f785db","bytes":5242,"media":true},"audio/vocabulary/d272412dec3fb457.mp3":{"rev":"89bd58f00eb18548","bytes":5973,"media":true},"audio/vocabulary/d5b24bebc1c3cac2.mp3":{"rev":"3372753fe4591465","bytes":4824,"media":true},"audio/vocabulary/d70bdb0299a10354.mp3":{"rev":"bf411f2841d3dd42","bytes":4928,"media":true},"audio/vocabulary/d7fcbce9bd33aea4.mp3":{"rev":"426a6fe41a5f8fd2","bytes":5659,"media":true},"audio/vocabulary/d89ab72a955e522b.mp3":{"rev":"b222a6fea42528c4","bytes":5242,"media":true},"audio/vocabulary/e31002e6d1228846.mp3":{"rev":"ac04c6259b573355","bytes":5764,"media":true},"audio/vocabulary/e37107149dfcaee5.mp3":{"rev":"235ac3e056cfd930","bytes":4615,"media":true},"audio/vocabulary/e66e20221c661bc6.mp3":{"rev":"5cbbbcb76f8b49ce","bytes":5346,"media":true},"audio/vocabulary/e760131b8dc0219a.mp3":{"rev":"17e6885140aca248","bytes":5868,"media":true},"audio/vocabulary/e8db9f5b69827216.mp3":{"rev":"c9b9406800bbe903","bytes":9003,"media":true},"audio/vocabulary/f210aeab0ad6d150.mp3":{"rev":"4a808083edaf2914","bytes":5868,"media":true},"audio/vocabulary/f4c7249426b360fe.mp3":{"rev":"e25aee9682f7d89e","bytes":5242,"media":true},"audio/vocabulary/f6ce8f95bf60eb6c.mp3":{"rev":"334350d80e34629f","bytes":5555,"media":true},"audio/vocabulary/faa3924a31d018d5.mp3":{"rev":"d39a45849b875851","bytes":5450,"media":true},"audio/youth/098.mp3":{"rev":"ae19aecd9bbdf471","bytes":9408,"media":true},"audio/youth/103.mp3":{"rev":"b6a8d969a9e89239","bytes":9216,"media":true},"audio/youth/182.mp3":{"rev":"7d0985c7e75953d9","bytes":10176,"media":true},"audio/youth/183.mp3":{"rev":"ceccb7321e510917","bytes":10560,"media":true},"audio/youth/184.mp3":{"rev":"872163b2db9a2041","bytes":8832,"media":true},"audio/youth/185.mp3":{"rev":"5099f3255fe9d4b0","bytes":8832,"media":true},"audio/youth/188.mp3":{"rev":"55a45c3fa99371c0","bytes":10944,"media":true},"css/connected.css":{"rev":"4cab997a385fccc5","bytes":2193,"media":false},"css/demo.css":{"rev":"83bbd7a77ffda433","bytes":434,"media":false},"css/grammar.css":{"rev":"bbe72b1d11bd7b50","bytes":14124,"media":false},"css/interface-languages.css":{"rev":"a7d6756fe928d083","bytes":1008,"media":false},"css/learning-route.css":{"rev":"e9bb6804b86d040d","bytes":3684,"media":false},"css/letter-training.css":{"rev":"ad23253d4e62782b","bytes":5901,"media":false},"css/letters-focused.css":{"rev":"0b6a0012f8ea3b7a","bytes":6969,"media":false},"css/letters.css":{"rev":"46d148210671f382","bytes":8057,"media":false},"css/modern.css":{"rev":"12f689bc07a23621","bytes":44721,"media":false},"css/olive-theme.css":{"rev":"2a69ab7dd1826de3","bytes":12324,"media":false},"css/practice.css":{"rev":"73cb20114e45cad0","bytes":11412,"media":false},"css/pwa.css":{"rev":"021f9b88f80edd2f","bytes":1488,"media":false},"css/scramble.css":{"rev":"4e217101a5b0b3ac","bytes":1849,"media":false},"css/verbs.css":{"rev":"c383284ea9ab0e20","bytes":13814,"media":false},"data/vocab_catalog.json":{"rev":"f8601106be1b93d6","bytes":8345,"media":false},"data/vocab_catalog_fallback.js":{"rev":"8ac553b84de797ae","bytes":8413,"media":false},"data/vocab_catalog_labels.js":{"rev":"e61fd523fefa4a7a","bytes":1051,"media":false},"ergebnis.html":{"rev":"f8420b381e7317cf","bytes":209445,"media":false},"fonts/manrope-latin.woff2":{"rev":"a30ddcd349703aff","bytes":24836,"media":false},"fonts/noto-naskh-arabic.woff":{"rev":"ac464be8642f7bec","bytes":156752,"media":false},"grammar.html":{"rev":"8a4484cf160ea3aa","bytes":275098,"media":false},"huruf.html":{"rev":"fd6ec2ae60d3c895","bytes":291633,"media":false},"images/brand/learner-scenes.png":{"rev":"c196d1c0ba3cc2a4","bytes":2533528,"media":true},"images/brand/olive-card-branch.svg":{"rev":"086046537fddb760","bytes":1067,"media":false},"images/brand/olive-pattern.svg":{"rev":"14a4a91506685901","bytes":752,"media":false},"images/brand/olive-symbol.svg":{"rev":"fdfa8389df254dd4","bytes":615,"media":false},"images/letters/01.svg":{"rev":"3c08d42b19818317","bytes":412,"media":false},"images/letters/02.svg":{"rev":"6d25f281de9593ee","bytes":412,"media":false},"images/letters/03.svg":{"rev":"1b34154aa08261ee","bytes":416,"media":false},"images/letters/04.svg":{"rev":"13e54a85525ea47a","bytes":414,"media":false},"images/letters/05.svg":{"rev":"b1a299eac3688c2f","bytes":412,"media":false},"images/letters/06.svg":{"rev":"6b94dfa1c018eb9e","bytes":414,"media":false},"images/pwa/apple-touch-icon.png":{"rev":"1c9db2fa6a00b41f","bytes":5555,"media":false},"images/pwa/icon-192.png":{"rev":"51ef2bcec55655d3","bytes":5881,"media":false},"images/pwa/icon-512.png":{"rev":"e869a915ddd9ca37","bytes":17338,"media":false},"images/pwa/icon-maskable-512.png":{"rev":"f7177991e77eb27f","bytes":11844,"media":false},"images/stories/scenes.png":{"rev":"e47f136742cbcc9e","bytes":2488405,"media":true},"images/vocab/a1_04-01.svg":{"rev":"b9e497180ac032d7","bytes":695,"media":false},"images/vocab/a1_04-02.svg":{"rev":"2218aba419b7b363","bytes":695,"media":false},"images/vocab/a1_04-03.svg":{"rev":"9a64756d713821f5","bytes":695,"media":false},"images/vocab/a1_04-04.svg":{"rev":"8a425db92ecd431f","bytes":695,"media":false},"images/vocab/a1_04-05.svg":{"rev":"d969062ad947869c","bytes":695,"media":false},"images/vocab/a1_04-08.svg":{"rev":"2106cc212c5ce055","bytes":276,"media":false},"images/vocab/a1_04-09.svg":{"rev":"d3878d5baef961ab","bytes":276,"media":false},"images/vocab/a1_04-15.svg":{"rev":"8a425db92ecd431f","bytes":695,"media":false},"images/vocab/a1_04-19.svg":{"rev":"b2e76fa28fed33cb","bytes":695,"media":false},"images/vocab/a1_11-01.svg":{"rev":"113951522dc6868f","bytes":276,"media":false},"images/vocab/a1_11-02.svg":{"rev":"e8fd6e836e909b6c","bytes":276,"media":false},"images/vocab/a1_11-03.svg":{"rev":"ab6ec75045c4fda2","bytes":276,"media":false},"images/vocab/a1_11-04.svg":{"rev":"53a0557b01e8ce1b","bytes":276,"media":false},"images/vocab/a1_11-05.svg":{"rev":"cdc5e5d98e4f3208","bytes":276,"media":false},"images/vocab/a1_11-06.svg":{"rev":"38409eb6870e3985","bytes":276,"media":false},"images/vocab/a1_11-07.svg":{"rev":"1920f1332a2a415e","bytes":276,"media":false},"images/vocab/a1_11-08.svg":{"rev":"78400fadbb9ad839","bytes":276,"media":false},"images/vocab/a1_11-09.svg":{"rev":"43e484cc8a09b09c","bytes":276,"media":false},"images/vocab/a1_11-10.svg":{"rev":"24e5eb25f0e4fc6e","bytes":315,"media":false},"images/vocab/a1_11-11.svg":{"rev":"5ee7d171795f8bb7","bytes":276,"media":false},"images/vocab/a1_11-12.svg":{"rev":"80c04b79c56fedfa","bytes":325,"media":false},"images/vocab/a1_11-13.svg":{"rev":"ab1ea19f6d8d803a","bytes":276,"media":false},"images/vocab/a1_11-14.svg":{"rev":"61d36c139eacffa8","bytes":276,"media":false},"images/vocab/a1_11-15.svg":{"rev":"c496af913f426eba","bytes":279,"media":false},"images/vocab/a1_11-16.svg":{"rev":"24cb11c72b47d087","bytes":276,"media":false},"images/vocab/a1_11-17.svg":{"rev":"a7f9057e2a3e9bd7","bytes":267,"media":false},"images/vocab/a1_11-18.svg":{"rev":"a997889ea9c1ad6a","bytes":276,"media":false},"images/vocab/a1_11-19.svg":{"rev":"463a43bf2836eab2","bytes":358,"media":false},"images/vocab/a1_11-20.svg":{"rev":"a1b7d347094d94d9","bytes":276,"media":false},"index.html":{"rev":"00c46165d7b45b8b","bytes":267074,"media":false},"js/app.js":{"rev":"b64a5dea751a64c7","bytes":32583,"media":false},"js/demo.js":{"rev":"4210246f44df9e4b","bytes":3042,"media":false},"js/design.js":{"rev":"3d5d380f5adbba91","bytes":10860,"media":false},"js/grammar-data.js":{"rev":"274e2e0e12c6ad39","bytes":22021,"media":false},"js/interface-languages.js":{"rev":"d233aae47963c832","bytes":32811,"media":false},"js/letter-data.js":{"rev":"7c544a3d42b30580","bytes":3765,"media":false},"js/letter-examples.js":{"rev":"16c622ca14f7ef10","bytes":1883,"media":false},"js/letter-focused-data.js":{"rev":"3df18e3da921fc36","bytes":6260,"media":false},"js/letter-related-data.js":{"rev":"ae501bb5e5c128fc","bytes":4149,"media":false},"js/letter-training-data.js":{"rev":"1ae51f3c024a28c7","bytes":2083,"media":false},"js/olive-theme.js":{"rev":"fc9e3f392a4e2c6c","bytes":8292,"media":false},"js/pages/grammar.js":{"rev":"cf23a7c070da9d26","bytes":16525,"media":false},"js/pages/home.js":{"rev":"51a90cd52d9bad12","bytes":8291,"media":false},"js/pages/learn.js":{"rev":"5c5a383daf1c361d","bytes":6798,"media":false},"js/pages/letter-training.js":{"rev":"16f78605ca05c617","bytes":10771,"media":false},"js/pages/letters-audio.js":{"rev":"1e1d310b6549f999","bytes":866,"media":false},"js/pages/letters-enhanced.js":{"rev":"c87de4c170cae4fb","bytes":8371,"media":false},"js/pages/letters-focused.js":{"rev":"fdfd417622d2b38c","bytes":13893,"media":false},"js/pages/letters-learning.js":{"rev":"4d07193d27eccf5e","bytes":5756,"media":false},"js/pages/letters-related.js":{"rev":"a9e73c2f79f35320","bytes":2608,"media":false},"js/pages/result.js":{"rev":"aa2b40db143ec146","bytes":4684,"media":false},"js/pages/review.js":{"rev":"fe29ff66b8b6a244","bytes":3093,"media":false},"js/pages/sentences.js":{"rev":"6b9e2f8651a7f445","bytes":7597,"media":false},"js/pages/sounds.js":{"rev":"25d1663b11eefa8c","bytes":5775,"media":false},"js/pages/stats.js":{"rev":"0cbfc8eb2234054a","bytes":2951,"media":false},"js/pages/stories.js":{"rev":"f144098a50418339","bytes":7886,"media":false},"js/pages/test-choice.js":{"rev":"7794df1b4470aacc","bytes":2854,"media":false},"js/pages/test-connected.js":{"rev":"0f7979bf3b4123f3","bytes":6807,"media":false},"js/pages/test-letters.js":{"rev":"70be4b83c3b12c18","bytes":5210,"media":false},"js/pages/test-listening.js":{"rev":"cd820b3859d31344","bytes":3973,"media":false},"js/pages/test-menu.js":{"rev":"c60d40679dd65920","bytes":2011,"media":false},"js/pages/test-scramble.js":{"rev":"f4f03c3e4a7fa8f5","bytes":4118,"media":false},"js/pages/test-writing.js":{"rev":"04495af1c64dc187","bytes":2785,"media":false},"js/pages/verbs.js":{"rev":"1104976106e92ce8","bytes":14912,"media":false},"js/practice-core.js":{"rev":"81b88bc2a7c001a1","bytes":2652,"media":false},"js/practice-data.js":{"rev":"73f48fc0190de2fe","bytes":8046,"media":false},"js/pwa.js":{"rev":"821151cc8d603449","bytes":11465,"media":false},"js/storage.js":{"rev":"234b995827cdf05b","bytes":4612,"media":false},"js/tanwin-display.js":{"rev":"97a12d8b8572e617","bytes":1382,"media":false},"js/verb-data.js":{"rev":"a034c6406a208951","bytes":9406,"media":false},"js/vocab-audio-data.js":{"rev":"ec6ebdbcc1092f7b","bytes":7488,"media":false},"js/vocab-pictures.js":{"rev":"874b09ab25fcd88b","bytes":2149,"media":false},"lernseite.html":{"rev":"a6ffff112bc08165","bytes":236095,"media":false},"letter-tests.html":{"rev":"4b8ac713604cabec","bytes":236115,"media":false},"manifest.webmanifest":{"rev":"b7eca750efeebd45","bytes":1107,"media":false},"offline.html":{"rev":"9153a0f293a61f81","bytes":1933,"media":false},"review.html":{"rev":"fec52f9e5f79fa0e","bytes":216755,"media":false},"sentences.html":{"rev":"b4e47ce45bd67e2f","bytes":240121,"media":false},"sounds.html":{"rev":"04a7ecd25b241856","bytes":236131,"media":false},"stats.html":{"rev":"b73640be7673a181","bytes":209310,"media":false},"stories.html":{"rev":"9d936c7d0314b3d6","bytes":240126,"media":false},"styles.css":{"rev":"e40cf0c3ba98ab5a","bytes":32612,"media":false},"test.html":{"rev":"dbf374124e623b32","bytes":208558,"media":false},"test1.html":{"rev":"a7b74a7e2faf9c50","bytes":207567,"media":false},"test2.html":{"rev":"bec0d3c0731196ad","bytes":207441,"media":false},"test3.html":{"rev":"7b5d4b55e03c09f2","bytes":209966,"media":false},"test4.html":{"rev":"3b6299a3f5355145","bytes":216261,"media":false},"test5.html":{"rev":"e602208785974eb5","bytes":210895,"media":false},"test6.html":{"rev":"0e843013e4f0e083","bytes":213730,"media":false},"verbs.html":{"rev":"05ec2fd83089254d","bytes":261373,"media":false}};
const BASE = new URL(self.registration.scope);
const PREFIX = "huroof-pwa:" + BASE.pathname + ":";
const CORE = PREFIX + "core:" + RELEASE;
const MEDIA = PREFIX + "media:v1";
const MAX_MEDIA_ENTRIES = 500,
  MAX_MEDIA_BYTES = 40 * 1024 * 1024;
let mediaQueue = Promise.resolve();
function key(path, revision = ASSETS[path]?.rev) {
  const u = new URL(path, BASE);
  u.search = "v=" + revision;
  return u.href;
}
function pathOf(url) {
  return url.origin === BASE.origin && url.pathname.startsWith(BASE.pathname)
    ? url.pathname.slice(BASE.pathname.length)
    : null;
}
function coreNames() {
  return caches.keys().then((names) =>
    names
      .filter((n) => n.startsWith(PREFIX + "core:"))
      .reverse()
      .sort((a, b) => (a === CORE ? -1 : b === CORE ? 1 : 0)),
  );
}
async function findCore(path, url) {
  // HTML is an immutable release shell until the user accepts an update.
  const revision = url.searchParams.get("v");
  if (!revision || ASSETS[path].rev.startsWith(revision))
    return (await caches.open(CORE)).match(key(path));
  // Another tab may still request the previous release's versioned scripts.
  for (const name of await coreNames()) {
    const cache = await caches.open(name),
      requests = await cache.keys();
    const request = requests.find((r) => {
      const u = new URL(r.url);
      return (
        pathOf(u) === path && u.searchParams.get("v")?.startsWith(revision)
      );
    });
    if (request) return cache.match(request);
  }
}
async function prepareCore() {
  const cache = await caches.open(CORE),
    entries = Object.keys(ASSETS).filter((p) => !ASSETS[p].media);
  let cursor = 0;
  const results = await Promise.allSettled(
    Array.from({ length: 6 }, async () => {
      while (cursor < entries.length) {
        const path = entries[cursor++];
        if (await cache.match(key(path))) continue;
        const response = await fetch(
          new Request(new URL(path, BASE), {
            cache: "reload",
            credentials: "same-origin",
          }),
        );
        if (
          !response.ok ||
          response.status !== 200 ||
          response.redirected ||
          !["basic", "default"].includes(response.type)
        )
          throw Error("Core file unavailable: " + path);
        const digest = await crypto.subtle.digest(
          "SHA-256",
          await response.clone().arrayBuffer(),
        );
        const hex = Array.from(new Uint8Array(digest), (b) =>
          b.toString(16).padStart(2, "0"),
        ).join("");
        if (!hex.startsWith(ASSETS[path].rev))
          throw Error("Release changed while preparing: " + path);
        await cache.put(key(path), response);
      }
    }),
  );
  if (results.some((r) => r.status === "rejected"))
    throw Error("Offline preparation incomplete");
}
self.addEventListener("install", (event) => {
  event.waitUntil(
    prepareCore().catch(async (error) => {
      await caches.delete(CORE);
      throw error;
    }),
  );
  // No automatic skipWaiting: a new release must not interrupt an exercise.
});
self.addEventListener("activate", (event) =>
  event.waitUntil(
    (async () => {
      const names = (await caches.keys()).filter((n) =>
        n.startsWith(PREFIX + "core:"),
      );
      // Keep the immediately previous release for tabs that have not reloaded.
      const old = names.filter((n) => n !== CORE);
      for (const name of old.slice(0, -1)) await caches.delete(name);
      await self.clients.claim();
    })(),
  ),
);
async function stats() {
  const cache = await caches.open(MEDIA),
    requests = await cache.keys();
  let bytes = 0;
  for (const r of requests) {
    const response = await cache.match(r);
    bytes += Number(response.headers.get("Content-Length") || 0);
  }
  const core = await caches.open(CORE);
  const complete =
    (await core.keys()).length ===
    Object.values(ASSETS).filter((a) => !a.media).length;
  return {
    release: RELEASE,
    ready: complete,
    mediaCount: requests.length,
    mediaBytes: bytes,
    maxMediaBytes: MAX_MEDIA_BYTES,
  };
}
async function saveMedia(path, response) {
  // Range responses are never stored: one complete recording supports later seeking.
  if (response.status !== 200 || response.redirected) return;
  const bytes = await response.clone().arrayBuffer();
  if (bytes.byteLength > MAX_MEDIA_BYTES) return;
  const headers = new Headers(response.headers);
  headers.set("Content-Length", String(bytes.byteLength));
  const stored = new Response(bytes, { status: 200, headers });
  mediaQueue = mediaQueue
    .catch(() => {})
    .then(async () => {
      const cache = await caches.open(MEDIA),
        address = key(path);
      await cache.delete(address);
      await cache.put(address, stored);
      const requests = await cache.keys();
      let size = 0;
      const sizes = [];
      for (const r of requests) {
        const hit = await cache.match(r),
          n = Number(hit.headers.get("Content-Length") || 0);
        sizes.push(n);
        size += n;
      }
      let i = 0;
      while (
        requests.length - i > MAX_MEDIA_ENTRIES ||
        size > MAX_MEDIA_BYTES
      ) {
        await cache.delete(requests[i]);
        size -= sizes[i++];
      }
    });
  await mediaQueue;
}
async function partial(response, range) {
  if (!range) return response;
  const match = /^bytes=(\d*)-(\d*)$/.exec(range);
  if (!match || (!match[1] && !match[2]))
    return new Response(null, { status: 416 });
  const bytes = await response.arrayBuffer(),
    length = bytes.byteLength;
  const start = match[1]
    ? Number(match[1])
    : Math.max(0, length - Number(match[2]));
  const end = match[1]
    ? match[2]
      ? Math.min(Number(match[2]), length - 1)
      : length - 1
    : length - 1;
  const headers = new Headers(response.headers);
  headers.set("Accept-Ranges", "bytes");
  if (start >= length || start > end) {
    headers.set("Content-Range", "bytes */" + length);
    headers.set("Content-Length", "0");
    return new Response(null, { status: 416, headers });
  }
  headers.set("Content-Range", `bytes ${start}-${end}/${length}`);
  headers.set("Content-Length", String(end - start + 1));
  return new Response(bytes.slice(start, end + 1), {
    status: 206,
    statusText: "Partial Content",
    headers,
  });
}
async function mediaResponse(request, path, event) {
  const cached = await (await caches.open(MEDIA)).match(key(path));
  if (cached) return partial(cached, request.headers.get("Range"));
  const headers = new Headers(request.headers);
  headers.delete("Range");
  const response = await fetch(
    new Request(request, { headers, cache: "no-cache" }),
  );
  if (response.ok && response.status === 200)
    event.waitUntil(saveMedia(path, response.clone()).catch(() => {}));
  return response.status === 200
    ? partial(response, request.headers.get("Range"))
    : response;
}
self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  let path = pathOf(url);
  if (path === "") path = "index.html";
  if (!path || !ASSETS[path]) {
    if (
      request.mode === "navigate" &&
      url.origin === BASE.origin &&
      url.pathname.startsWith(BASE.pathname)
    )
      event.respondWith(
        fetch(request).catch(async () => {
          const response = await (
            await caches.open(CORE)
          ).match(key("offline.html"));
          return response || Response.error();
        }),
      );
    return;
  }
  if (ASSETS[path].media) {
    event.respondWith(
      mediaResponse(request, path, event).catch(() => Response.error()),
    );
    return;
  }
  event.respondWith(
    (async () => {
      const cached = await findCore(path, url);
      if (cached) return cached;
      try {
        return await fetch(request);
      } catch (_) {
        if (request.mode === "navigate")
          return (
            (await (await caches.open(CORE)).match(key("offline.html"))) ||
            Response.error()
          );
        return Response.error();
      }
    })(),
  );
});
self.addEventListener("message", (event) => {
  if (event.data?.type === "APPLY_UPDATE") {
    event.waitUntil(self.skipWaiting());
    return;
  }
  if (event.data?.type === "PWA_STATUS")
    event.waitUntil(
      stats().then((value) => event.ports[0]?.postMessage(value)),
    );
  if (event.data?.type === "PREPARE_CORE")
    event.waitUntil(
      prepareCore()
        .then(stats)
        .then((value) => event.ports[0]?.postMessage(value))
        .catch(() => event.ports[0]?.postMessage({ error: true })),
    );
  if (event.data?.type === "CLEAR_MEDIA")
    event.waitUntil(
      mediaQueue
        .catch(() => {})
        .then(() => caches.delete(MEDIA))
        .then(() => event.ports[0]?.postMessage({ cleared: true })),
    );
});
