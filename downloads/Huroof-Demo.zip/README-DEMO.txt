HUROOF DEMO · حروف من الزيتون

Diese eigenständige Demo benötigt weder Firebase noch Anmeldung, Datenbank,
Node.js, Python oder einen Build-Schritt. Es gibt keine Verbindung zu deinem
Firebase-Projekt. Die vollständige App wird nicht verändert.

INHALT
- 6 Wortschatzlisten: 3 auf A1 und 3 auf A2, insgesamt 120 vokalisierte Einträge.
- Lernkarten, sechs Vokabeltestarten, Fehlerwiederholung und lokale Statistik.
- Die ersten 6 Buchstaben (Alif bis Ḥā), vier Testarten, Schreibfläche und
  buchstabenspezifische Aufgaben.
- 3 Grammatiklektionen mit insgesamt 24 Fragen.
- 6 Verben: Perfekt, Präsens und Imperativ mit Übungen.
- 2 Lautpaare mit 12 Hörfragen, 6 Satzbauaufgaben und 1 Kurzgeschichte
  mit 4 Verständnisfragen.
- Deutsche und arabische Oberfläche, Olivenzweige und auswählbarer Hintergrund.
- Eine kleine Lernrunde mit drei selbst abhakbaren Zielen und Ermutigung.
- Bücher und Buchwortschatz sind nicht enthalten.

KOSTENLOS HOSTEN: NETLIFY DROP
1. Huroof-Demo.zip vollständig in einen neuen Ordner entpacken.
2. https://app.netlify.com/drop im Browser öffnen. Bei Bedarf ein kostenloses
   Netlify-Konto erstellen und den Free-Tarif verwenden.
3. Den entpackten Ordner auf die Upload-Fläche ziehen. Direkt in diesem Ordner
   müssen index.html, styles.css sowie css, js, data, images, fonts und audio liegen.
4. Nach dem Upload die angezeigte HTTPS-Adresse öffnen und weitergeben.
   Kostenlos innerhalb der jeweiligen Anbieterlimits.

ALTERNATIVE: CLOUDFLARE PAGES
1. Im Cloudflare-Dashboard unter Workers & Pages eine Pages-Seite erstellen.
2. Direct Upload / Upload assets wählen (die Oberfläche kann abweichen).
3. Diese ZIP hochladen oder den entpackten Ordner auswählen und veröffentlichen.
   index.html liegt bereits im Stammverzeichnis der ZIP. Kein Build-Befehl nötig.

AUF DEM COMPUTER AUSPROBIEREN
ZIP vollständig entpacken und index.html im Browser öffnen.
Für Android Chrome und zum Weitergeben empfiehlt sich die gehostete HTTPS-Seite.

DATEN UND AUDIO
Fortschritte werden nur im Browser dieses Geräts gespeichert. Es gibt keine
Konten und keine Synchronisierung zwischen Geräten. Ein anderer Browser oder
das Löschen der Websitedaten setzt den lokalen Fortschritt zurück.
Die Demo hat einen eigenen Namensraum für Lernstände. Sprache und Hintergrund
können mit einer am gleichen Ursprung geöffneten Vollversion geteilt werden.
Alle Wörter der sechs Demo-Wortlisten haben mitgelieferte Tonaufnahmen.
Keine Analytics- oder Werbeskripte werden eingebunden.

Erstellt für Mahmoud Barakat · حروف من الزيتون
