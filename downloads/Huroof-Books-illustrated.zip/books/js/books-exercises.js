/* Books exercises: one saved answer model for pointer, touch and keyboard input. */
(() => {
  const P=window.Practice,{el,button,arabic}=P;
  const normalize=v=>String(v??'').normalize('NFC').replace(/[\u064B-\u065F\u0670\u0640]/g,'').replace(/إثنين/g,'اثنين').trim();
  const supported=q=>['week','classify','matching'].includes(q.kind);
  function correct(q,v){
    if(!Array.isArray(v))return false;
    if(q.kind==='week')return v.length===7&&v.every((x,i)=>normalize(x)===normalize(q.days[i]));
    if(q.kind==='classify')return v.length===q.items.length&&v.every((x,i)=>x===q.items[i].category);
    if(q.kind==='matching')return v.length===q.pairs.length&&v.every((x,i)=>x===i);
    return false;
  }
  function create(q,{value,onChange=()=>{},onReady=()=>{}}={}){
    let vals=Array.isArray(value)?value.slice():[],locked=false,selected=null;
    const root=arabic(el('div',undefined,'books-exercise books-'+q.kind));
    root.setAttribute('role','group');root.setAttribute('aria-label',q.prompt);
    const status=el('p','','books-interaction-status');status.setAttribute('aria-live','polite');
    const all=[];let redraw=()=>{};
    const ready=()=>q.kind==='week'?vals.length===7&&vals.every(x=>String(x||'').trim()):vals.length===(q.items||q.pairs).length&&vals.every(x=>x!==null&&x!==undefined);
    const changed=()=>{onChange(vals.slice());onReady(ready());};
    if(q.kind==='week'){
      const fields=el('div',undefined,'books-week-fields');
      for(let i=0;i<7;i++){
        const label=el('label',String(i+1)),input=el('input');input.type='text';input.autocomplete='off';input.maxLength=30;input.dataset.day=i;input.value=vals[i]||'';input.setAttribute('aria-label','اليوم '+(i+1));
        vals[i]=input.value;input.oninput=()=>{vals[i]=input.value;changed();};label.append(input);fields.append(label);all.push(input);
      }
      root.append(fields);
      redraw=()=>{if(locked)all.forEach((input,i)=>input.classList.add(normalize(vals[i])===normalize(q.days[i])?'is-correct':'is-wrong'));};
    }else if(q.kind==='classify'){
      const categories=['اسم','فعل','حرف'];
      vals=q.items.map((_,i)=>categories.includes(vals[i])?vals[i]:null);
      const bankCard=el('section',undefined,'books-bank-card'),bank=el('div',undefined,'books-word-bank');
      const progress=el('span','','books-distribution-count'),bankHeading=el('div',undefined,'books-bank-heading');
      bankHeading.append(el('strong','بنك الكلمات'),progress);bankCard.append(bankHeading,bank);
      bank.setAttribute('aria-label','الكلمات المتاحة للسحب');
      const zones=el('div',undefined,'books-dropzones'),table=el('table',undefined,'books-classification-table');
      const resultHeading=el('h4','جدول اختياراتك','books-result-heading');
      const completion=el('p','اكتمل توزيع الكلمات. هذا الجدول يعرض اختياراتك؛ اضغط «تحقق» لتصحيحها.','books-classification-complete');
      table.append(el('caption','الكلمات تحت النوع الذي اخترته أنت'));
      const header=el('tr'),body=el('tbody'),row=el('tr'),cells={},piles={},counters={},zoneNodes={};
      const wordOrder=P.shuffle(q.items.map((_,i)=>i));
      const selectWord=i=>{selected=i;status.textContent='الكلمة المختارة: '+q.items[i].word+'؛ اختر مستطيل اسم أو فعل أو حرف.';redraw();};
      function assign(i,category){
        if(locked||i===null||!Number.isInteger(i))return;
        vals[i]=category;selected=null;changed();redraw();
        status.textContent=category?'وُضعت '+q.items[i].word+' تحت '+category:'أُعيدت '+q.items[i].word+' إلى بنك الكلمات';
        if(ready())status.textContent+='؛ اكتمل التوزيع وظهر جدول اختياراتك.';
      }
      for(const category of categories){
        const zone=el('section',undefined,'books-dropzone');zone.dataset.category=category;zone.tabIndex=0;
        zone.setAttribute('role','group');zone.setAttribute('aria-label','ضع الكلمة في قسم '+category);
        const title=el('h4',category),count=el('span','0','books-category-count'),pile=el('div',undefined,'books-category-words');
        title.append(count);zone.append(title,pile);zones.append(zone);zoneNodes[category]=zone;piles[category]=pile;counters[category]=count;
        zone.onclick=e=>{if(!e.target.closest('.books-word'))assign(selected,category);};
        zone.onkeydown=e=>{if((e.key==='Enter'||e.key===' ')&&e.target===zone){e.preventDefault();assign(selected,category);}};
        const th=el('th',category);th.scope='col';header.append(th);const cell=el('td');cells[category]=cell;row.append(cell);
      }
      const head=el('thead');head.append(header);body.append(row);table.append(head,body);
      function chip(i,placed=false,tableCopy=false){
        const word=q.items[i].word;
        const b=button(word,e=>{e.stopPropagation();if(locked)return;if(placed){if(selected!==null&&selected!==i)assign(selected,vals[i]);else assign(i,null);}else selectWord(i);},'practice-button books-word');
        b.dataset.wordIndex=i;b.setAttribute('aria-pressed',String(selected===i));b.disabled=locked;
        b.setAttribute('aria-label',word+(placed?' · اضغط لإعادتها إلى البنك':''));
        if(!tableCopy)drag(b,'.books-dropzone, .books-word-bank',target=>assign(i,target.classList.contains('books-word-bank')?null:target.dataset.category));
        if(locked)b.classList.add(vals[i]===q.items[i].category?'is-correct':'is-wrong');
        return b;
      }
      redraw=()=>{
        bank.replaceChildren();for(const category of categories){piles[category].replaceChildren();cells[category].replaceChildren();}
        for(const i of wordOrder){
          if(vals[i]){piles[vals[i]].append(chip(i,true));cells[vals[i]].append(chip(i,true,true));}
          else bank.append(chip(i));
        }
        const assigned=vals.filter(Boolean).length;progress.textContent=assigned+' من '+q.items.length+' كلمة موزّعة';
        if(!bank.children.length)bank.append(el('span','وزّعت جميع الكلمات ✓','books-bank-empty'));
        for(const category of categories){
          counters[category].textContent=vals.filter(v=>v===category).length;
          if(!piles[category].children.length)piles[category].append(el('span','اسحب هنا','books-drop-placeholder'));
          zoneNodes[category].setAttribute('aria-disabled',String(locked));
        }
        const show=ready();table.hidden=!show;resultHeading.hidden=!show;completion.hidden=!show;completion.classList.toggle('is-checked',locked);
        if(locked)completion.textContent='هذا توزيعك كما اخترته؛ تظهر نتيجة التصحيح أسفل السؤال.';
      };
      root.append(el('p','اسحب الكلمات من البنك إلى المستطيل المناسب. لإعادة كلمة اضغطها، ولتغيير نوعها اسحبها إلى مستطيل آخر. يمكنك أيضًا اختيار الكلمة ثم الضغط على المستطيل.','books-help'),bankCard,zones,resultHeading,completion,table);
    }else{
      vals=q.pairs.map((_,i)=>Number.isInteger(vals[i])&&vals[i]>=0&&vals[i]<q.pairs.length?vals[i]:null);
      // Old or damaged duplicates do not create two lines ending at the same word.
      vals=vals.map((v,i)=>v!==null&&vals.indexOf(v)!==i?null:v);
      const board=el('div',undefined,'books-match-board'),startsColumn=el('div',undefined,'books-match-column'),endsColumn=el('div',undefined,'books-match-column');
      const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.classList.add('books-match-lines');svg.setAttribute('aria-hidden','true');
      const counter=el('p','','books-matching-count'),starts=[],ends=[];let selectedEnd=null,live=null;
      const palette=['#497b68','#bd7650','#6b79a8','#a16586','#8a954a','#3a8c99','#ba8b32','#7c6f9f'];
      const path=(x1,y1,x2,y2,color,dashed=false)=>{
        const p=document.createElementNS(svg.namespaceURI,'path'),bend=Math.max(25,Math.abs(x2-x1)*.44),sign=x2>x1?1:-1;
        for(const [key,v]of Object.entries({d:`M ${x1} ${y1} C ${x1+sign*bend} ${y1}, ${x2-sign*bend} ${y2}, ${x2} ${y2}`,fill:'none',stroke:color,'stroke-width':dashed?3:3.5,'stroke-linecap':'round'}))p.setAttribute(key,v);
        if(dashed){p.setAttribute('stroke-dasharray','7 6');p.classList.add('books-live-line');}
        return p;
      };
      function connect(i,j){
        if(locked||i===null||j===null)return;
        vals=vals.map((v,k)=>k!==i&&v===j?null:v);vals[i]=j;selected=null;selectedEnd=null;changed();redraw();
        status.textContent='وصلت '+q.pairs[i][0]+' بـ '+q.pairs[j][1]+'. يمكنك تغيير الوصلة قبل التحقق.';
      }
      function drawLines(){
        svg.replaceChildren();const base=board.getBoundingClientRect();if(!base.width)return;
        svg.setAttribute('viewBox',`0 0 ${base.width} ${base.height}`);
        vals.forEach((j,i)=>{
          if(j===null)return;const a=starts[i].getBoundingClientRect(),b=ends[j].getBoundingClientRect();
          svg.append(path(a.left-base.left,a.top+a.height/2-base.top,b.right-base.left,b.top+b.height/2-base.top,locked?(i===j?'#287348':'#aa3e32'):palette[i%palette.length]));
        });
        if(live){
          const a=live.node.getBoundingClientRect(),x=live.side==='start'?a.left:a.right;
          svg.append(path(x-base.left,a.top+a.height/2-base.top,live.x-base.left,live.y-base.top,'#b27735',true));
        }
      }
      const hooks=(node,side)=>({
        move:e=>{live={node,side,x:e.clientX,y:e.clientY};drawLines();},
        end:()=>{live=null;drawLines();}
      });
      q.pairs.forEach((pair,i)=>{
        const b=button(pair[0],()=>{if(locked)return;if(selectedEnd!==null)connect(i,selectedEnd);else{selected=i;redraw();status.textContent='اختر ضد '+pair[0]+' من العمود المقابل.';}},'practice-button books-match-start');
        b.dataset.matchStart=i;starts[i]=b;startsColumn.append(b);all.push(b);
        drag(b,'.books-match-end',target=>connect(i,Number(target.dataset.matchEnd)),hooks(b,'start'));
      });
      P.shuffle(q.pairs.map((_,i)=>i)).forEach(i=>{
        const b=button(q.pairs[i][1],()=>{if(locked)return;if(selected!==null)connect(selected,i);else{selectedEnd=i;redraw();status.textContent='اختر الكلمة المقابلة لـ '+q.pairs[i][1];}},'practice-button books-match-end');
        b.dataset.matchEnd=i;ends[i]=b;endsColumn.append(b);all.push(b);
        drag(b,'.books-match-start',target=>connect(Number(target.dataset.matchStart),i),hooks(b,'end'));
      });
      redraw=()=>{
        starts.forEach((b,i)=>{b.setAttribute('aria-pressed',String(selected===i));b.dataset.connected=vals[i]!==null;b.style.setProperty('--pair-color',palette[i%palette.length]);});
        ends.forEach((b,j)=>{b.setAttribute('aria-pressed',String(selectedEnd===j));b.dataset.connected=vals.includes(j);const i=vals.indexOf(j);b.style.setProperty('--pair-color',i<0?'#8da391':palette[i%palette.length]);});
        counter.textContent=vals.filter(v=>v!==null).length+' من '+q.pairs.length+' وصلات';requestAnimationFrame(drawLines);
      };
      new ResizeObserver(drawLines).observe(board);
      board.append(svg,startsColumn,endsColumn);
      root.append(el('p','اسحب من أي كلمة إلى ضدها في العمود الآخر؛ يظهر الخط أثناء السحب. يمكنك أيضًا الضغط على الكلمتين. لإصلاح اختيارك أعد توصيل الكلمة.','books-help'),counter,board);
    }
    function drag(node,targetSelector,drop,hooks={}){
      let start=null,moved=false,ghost=null,over=null,skipNativeClick=false;
      node.addEventListener('click',e=>{
        if(skipNativeClick && e.isTrusted && e.detail>0){e.preventDefault();e.stopImmediatePropagation();skipNativeClick=false;}
      },true);
      function clear(){
        node.classList.remove('books-dragging');root.classList.remove('books-is-dragging');ghost?.remove();ghost=null;over?.classList.remove('books-drop-over');over=null;hooks.end?.();
      }
      node.addEventListener('pointerdown',e=>{if(locked)return;skipNativeClick=false;start={x:e.clientX,y:e.clientY,id:e.pointerId};moved=false;node.setPointerCapture(e.pointerId);});
      node.addEventListener('pointermove',e=>{
        if(!start)return;
        if(Math.hypot(e.clientX-start.x,e.clientY-start.y)>8)moved=true;
        if(!moved)return;
        node.classList.add('books-dragging');root.classList.add('books-is-dragging');
        if(q.kind==='classify'){
          if(!ghost){ghost=el('div',node.textContent,'books-drag-ghost');ghost.setAttribute('aria-hidden','true');root.append(ghost);}
          ghost.style.left=(e.clientX+10)+'px';ghost.style.top=(e.clientY-32)+'px';
        }
        const target=document.elementFromPoint(e.clientX,e.clientY)?.closest(targetSelector);
        if(target!==over){over?.classList.remove('books-drop-over');over=target&&root.contains(target)?target:null;over?.classList.add('books-drop-over');}
        hooks.move?.(e);status.textContent=q.kind==='classify'?'أفلت الكلمة داخل المستطيل المناسب.':'أفلت عند الكلمة المقابلة لإكمال الوصلة.';
      });
      node.addEventListener('pointerup',e=>{
        if(!start)return;const target=document.elementFromPoint(e.clientX,e.clientY)?.closest(targetSelector);
        if(node.hasPointerCapture(e.pointerId))node.releasePointerCapture(e.pointerId);start=null;clear();skipNativeClick=true;
        if(moved&&target&&root.contains(target)){e.preventDefault();drop(target);}else if(!moved){e.preventDefault();node.click();}
      });
      node.addEventListener('pointercancel',()=>{start=null;clear();});
      node.addEventListener('lostpointercapture',()=>{if(start){start=null;clear();}});
    }
    root.append(status);redraw();queueMicrotask(()=>onReady(ready()));
    return {node:root,getValue:()=>vals.slice(),lock(){locked=true;all.forEach(n=>n.disabled=true);redraw();},ready};
  }
  window.BooksExercises={supported,correct,create};
})();
