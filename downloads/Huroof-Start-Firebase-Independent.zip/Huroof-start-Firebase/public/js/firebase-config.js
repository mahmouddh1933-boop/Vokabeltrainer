/* HUROOF_INDEPENDENT_FIREBASE_BEGIN */
window.OliveFirebaseConfig=Object.freeze({enabled:true,emulator:false,accessControl:true,accessMode:"spark",firebase:Object.freeze({})});
/* HUROOF_INDEPENDENT_FIREBASE_END */