البداية والحروف — Firebase مستقل
انظر README-AR.md بجانب firebase.json.
