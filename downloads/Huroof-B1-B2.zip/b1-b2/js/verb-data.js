(() => {
  "use strict";
  // Stems are explicit. Exceptional verbs use complete, separately reviewed paradigms.
  const verbs = [{"id":"teach","pastStem":"عَلَّم","presentStem":"عَلِّم","imperativeStem":"عَلِّم","presentVowel":"ُ","meaning":{"ar":"التعليم","de":"unterrichten"},"kind":"sound","formLength":4,"pattern":"فَعَّلَ","root":"ع ل م","structure":"ثلاثي مزيد","example":{"past":["عَلَّمَ طِفْلًا.","Er unterrichtete ein Kind."],"present":["يُعَلِّمُ طِفْلًا.","Er unterrichtet ein Kind."],"imperative":["عَلِّمْ طِفْلًا.","Unterrichte ein Kind."]},"family":"sound"},{"id":"help","pastStem":"سَاعَد","presentStem":"سَاعِد","imperativeStem":"سَاعِد","presentVowel":"ُ","meaning":{"ar":"المساعدة","de":"helfen"},"kind":"sound","formLength":4,"pattern":"فَاعَلَ","root":"س ع د","structure":"ثلاثي مزيد","example":{"past":["سَاعَدَ صَدِيقًا.","Er half einem Freund."],"present":["يُسَاعِدُ صَدِيقًا.","Er hilft einem Freund."],"imperative":["سَاعِدْ صَدِيقًا.","Hilf einem Freund."]},"family":"sound"},{"id":"honor","pastStem":"أَكْرَم","presentStem":"كْرِم","imperativeStem":"أَكْرِم","presentVowel":"ُ","meaning":{"ar":"الإكرام","de":"ehren"},"kind":"sound","formLength":4,"pattern":"أَفْعَلَ","root":"ك ر م","structure":"ثلاثي مزيد","example":{"past":["أَكْرَمَ ضَيْفًا.","Er ehrte einen Gast."],"present":["يُكْرِمُ ضَيْفًا.","Er ehrt einen Gast."],"imperative":["أَكْرِمْ ضَيْفًا.","Ehre einen Gast."]},"family":"sound"},{"id":"send","pastStem":"أَرْسَل","presentStem":"رْسِل","imperativeStem":"أَرْسِل","presentVowel":"ُ","meaning":{"ar":"الإرسال","de":"senden"},"kind":"sound","formLength":4,"pattern":"أَفْعَلَ","root":"ر س ل","structure":"ثلاثي مزيد","example":{"past":["أَرْسَلَ رِسَالَةً.","Er sandte einen Brief."],"present":["يُرْسِلُ رِسَالَةً.","Er sendet einen Brief."],"imperative":["أَرْسِلْ رِسَالَةً.","Sende einen Brief."]},"family":"sound"},{"id":"travel","pastStem":"سَافَر","presentStem":"سَافِر","imperativeStem":"سَافِر","presentVowel":"ُ","meaning":{"ar":"السفر","de":"reisen"},"kind":"sound","formLength":4,"pattern":"فَاعَلَ","root":"س ف ر","structure":"ثلاثي مزيد","example":{"past":["سَافَرَ إِلَى مَدِينَةٍ.","Er reiste in eine Stadt."],"present":["يُسَافِرُ إِلَى مَدِينَةٍ.","Er reist in eine Stadt."],"imperative":["سَافِرْ إِلَى مَدِينَةٍ.","Reise in eine Stadt."]},"family":"sound"},{"id":"roll","pastStem":"دَحْرَج","presentStem":"دَحْرِج","imperativeStem":"دَحْرِج","presentVowel":"ُ","meaning":{"ar":"الدحرجة","de":"rollen"},"kind":"sound","formLength":4,"pattern":"فَعْلَلَ","root":"د ح ر ج","structure":"رباعي مجرد","example":{"past":["دَحْرَجَ كُرَةً.","Er rollte einen Ball."],"present":["يُدَحْرِجُ كُرَةً.","Er rollt einen Ball."],"imperative":["دَحْرِجْ كُرَةً.","Rolle einen Ball."]},"family":"sound"},{"id":"learn","pastStem":"تَعَلَّم","presentStem":"تَعَلَّم","imperativeStem":"تَعَلَّم","presentVowel":"َ","meaning":{"ar":"التعلّم","de":"lernen"},"kind":"sound","formLength":5,"pattern":"تَفَعَّلَ","root":"ع ل م","structure":"ثلاثي مزيد","example":{"past":["تَعَلَّمَ لُغَةً.","Er lernte eine Sprache."],"present":["يَتَعَلَّمُ لُغَةً.","Er lernt eine Sprache."],"imperative":["تَعَلَّمْ لُغَةً.","Lerne eine Sprache."]},"family":"sound"},{"id":"share","pastStem":"تَشَارَك","presentStem":"تَشَارَك","imperativeStem":"تَشَارَك","presentVowel":"َ","meaning":{"ar":"التشارك","de":"teilen / gemeinsam nutzen"},"kind":"sound","formLength":5,"pattern":"تَفَاعَلَ","root":"ش ر ك","structure":"ثلاثي مزيد","example":{"past":["تَشَارَكَ مَعَ صَدِيقٍ.","Er teilte mit einem Freund."],"present":["يَتَشَارَكُ مَعَ صَدِيقٍ.","Er teilt mit einem Freund."],"imperative":["تَشَارَكْ مَعَ صَدِيقٍ.","Teile mit einem Freund."]},"family":"sound"},{"id":"depart","pastStem":"اِنْطَلَق","presentStem":"نْطَلِق","imperativeStem":"اِنْطَلِق","presentVowel":"َ","meaning":{"ar":"الانطلاق","de":"aufbrechen"},"kind":"sound","formLength":5,"pattern":"اِنْفَعَلَ","root":"ط ل ق","structure":"ثلاثي مزيد","example":{"past":["اِنْطَلَقَ بِسُرْعَةٍ.","Er brach schnell auf."],"present":["يَنْطَلِقُ بِسُرْعَةٍ.","Er bricht schnell auf."],"imperative":["اِنْطَلِقْ بِسُرْعَةٍ.","Brich schnell auf."]},"family":"sound"},{"id":"meet","pastStem":"اِجْتَمَع","presentStem":"جْتَمِع","imperativeStem":"اِجْتَمِع","presentVowel":"َ","meaning":{"ar":"الاجتماع","de":"sich treffen"},"kind":"sound","formLength":5,"pattern":"اِفْتَعَلَ","root":"ج م ع","structure":"ثلاثي مزيد","example":{"past":["اِجْتَمَعَ مَعَ صَدِيقٍ.","Er traf sich mit einem Freund."],"present":["يَجْتَمِعُ مَعَ صَدِيقٍ.","Er trifft sich mit einem Freund."],"imperative":["اِجْتَمِعْ مَعَ صَدِيقٍ.","Triff dich mit einem Freund."]},"family":"sound"},{"id":"approach","pastStem":"اِقْتَرَب","presentStem":"قْتَرِب","imperativeStem":"اِقْتَرِب","presentVowel":"َ","meaning":{"ar":"الاقتراب","de":"sich nähern"},"kind":"sound","formLength":5,"pattern":"اِفْتَعَلَ","root":"ق ر ب","structure":"ثلاثي مزيد","example":{"past":["اِقْتَرَبَ مِنَ الْبَابِ.","Er näherte sich der Tür."],"present":["يَقْتَرِبُ مِنَ الْبَابِ.","Er nähert sich der Tür."],"imperative":["اِقْتَرِبْ مِنَ الْبَابِ.","Nähere dich der Tür."]},"family":"sound"},{"id":"roll-self","pastStem":"تَدَحْرَج","presentStem":"تَدَحْرَج","imperativeStem":"تَدَحْرَج","presentVowel":"َ","meaning":{"ar":"التدحرج","de":"sich rollen"},"kind":"sound","formLength":5,"pattern":"تَفَعْلَلَ","root":"د ح ر ج","structure":"رباعي مزيد","example":{"past":["تَدَحْرَجَ بِبُطْءٍ.","Er rollte sich langsam."],"present":["يَتَدَحْرَجُ بِبُطْءٍ.","Er rollt sich langsam."],"imperative":["تَدَحْرَجْ بِبُطْءٍ.","Rolle dich langsam."]},"family":"sound"},{"id":"use","pastStem":"اِسْتَخْدَم","presentStem":"سْتَخْدِم","imperativeStem":"اِسْتَخْدِم","presentVowel":"َ","meaning":{"ar":"الاستخدام","de":"benutzen"},"kind":"sound","formLength":6,"pattern":"اِسْتَفْعَلَ","root":"خ د م","structure":"ثلاثي مزيد","example":{"past":["اِسْتَخْدَمَ قَلَمًا.","Er benutzte einen Stift."],"present":["يَسْتَخْدِمُ قَلَمًا.","Er benutzt einen Stift."],"imperative":["اِسْتَخْدِمْ قَلَمًا.","Benutze einen Stift."]},"family":"sound"},{"id":"receive","pastStem":"اِسْتَقْبَل","presentStem":"سْتَقْبِل","imperativeStem":"اِسْتَقْبِل","presentVowel":"َ","meaning":{"ar":"الاستقبال","de":"empfangen"},"kind":"sound","formLength":6,"pattern":"اِسْتَفْعَلَ","root":"ق ب ل","structure":"ثلاثي مزيد","example":{"past":["اِسْتَقْبَلَ ضَيْفًا.","Er empfing einen Gast."],"present":["يَسْتَقْبِلُ ضَيْفًا.","Er empfängt einen Gast."],"imperative":["اِسْتَقْبِلْ ضَيْفًا.","Empfange einen Gast."]},"family":"sound"},{"id":"extract","pastStem":"اِسْتَخْرَج","presentStem":"سْتَخْرِج","imperativeStem":"اِسْتَخْرِج","presentVowel":"َ","meaning":{"ar":"الاستخراج","de":"entnehmen / extrahieren"},"kind":"sound","formLength":6,"pattern":"اِسْتَفْعَلَ","root":"خ ر ج","structure":"ثلاثي مزيد","example":{"past":["اِسْتَخْرَجَ مَعْلُومَةً.","Er entnahm eine Information."],"present":["يَسْتَخْرِجُ مَعْلُومَةً.","Er entnimmt eine Information."],"imperative":["اِسْتَخْرِجْ مَعْلُومَةً.","Entnimm eine Information."]},"family":"sound"},{"id":"seek-forgiveness","pastStem":"اِسْتَغْفَر","presentStem":"سْتَغْفِر","imperativeStem":"اِسْتَغْفِر","presentVowel":"َ","meaning":{"ar":"الاستغفار","de":"um Vergebung bitten"},"kind":"sound","formLength":6,"pattern":"اِسْتَفْعَلَ","root":"غ ف ر","structure":"ثلاثي مزيد","example":{"past":["اِسْتَغْفَرَ رَبَّهُ.","Er bat seinen Herrn um Vergebung."],"present":["يَسْتَغْفِرُ رَبَّهُ.","Er bittet seinen Herrn um Vergebung."],"imperative":["اِسْتَغْفِرْ رَبَّكَ.","Bitte deinen Herrn um Vergebung."]},"family":"sound"},{"id":"enjoy","pastStem":"اِسْتَمْتَع","presentStem":"سْتَمْتِع","imperativeStem":"اِسْتَمْتِع","presentVowel":"َ","meaning":{"ar":"الاستمتاع","de":"genießen"},"kind":"sound","formLength":6,"pattern":"اِسْتَفْعَلَ","root":"م ت ع","structure":"ثلاثي مزيد","example":{"past":["اِسْتَمْتَعَ بِالْوَقْتِ.","Er genoss die Zeit."],"present":["يَسْتَمْتِعُ بِالْوَقْتِ.","Er genießt die Zeit."],"imperative":["اِسْتَمْتِعْ بِالْوَقْتِ.","Genieße die Zeit."]},"family":"sound"},{"id":"utilize","pastStem":"اِسْتَعْمَل","presentStem":"سْتَعْمِل","imperativeStem":"اِسْتَعْمِل","presentVowel":"َ","meaning":{"ar":"الاستعمال","de":"verwenden"},"kind":"sound","formLength":6,"pattern":"اِسْتَفْعَلَ","root":"ع م ل","structure":"ثلاثي مزيد","example":{"past":["اِسْتَعْمَلَ مِفْتَاحًا.","Er verwendete einen Schlüssel."],"present":["يَسْتَعْمِلُ مِفْتَاحًا.","Er verwendet einen Schlüssel."],"imperative":["اِسْتَعْمِلْ مِفْتَاحًا.","Verwende einen Schlüssel."]},"family":"sound"},{"id":"walk","meaning":{"ar":"المشي","de":"zu Fuß gehen"},"kind":"weak","forms":{"past":["مَشَيْتُ","مَشَيْنَا","مَشَيْتَ","مَشَيْتِ","مَشَيْتُمَا","مَشَيْتُمَا","مَشَيْتُمْ","مَشَيْتُنَّ","مَشَى","مَشَتْ","مَشَيَا","مَشَتَا","مَشَوْا","مَشَيْنَ"],"present":["أَمْشِي","نَمْشِي","تَمْشِي","تَمْشِينَ","تَمْشِيَانِ","تَمْشِيَانِ","تَمْشُونَ","تَمْشِينَ","يَمْشِي","تَمْشِي","يَمْشِيَانِ","تَمْشِيَانِ","يَمْشُونَ","يَمْشِينَ"],"imperative":["اِمْشِ","اِمْشِي","اِمْشِيَا","اِمْشُوا","اِمْشِينَ"]},"example":{"past":["مَشَى إِلَى الْمَدْرَسَةِ.","Er ging zu Fuß zur Schule."],"present":["يَمْشِي إِلَى الْمَدْرَسَةِ.","Er geht zu Fuß zur Schule."],"imperative":["اِمْشِ بِهُدُوءٍ.","Geh ruhig."]},"note":{"ar":"فعل ناقص يائي: تُحذف الياء في اِمْشِ ولَمْ يَمْشِ. ومع واو الجماعة نقول: مَشَوْا، يَمْشُونَ.","de":"Beachte die Stammänderungen in der Tabelle; die Formen sind vollständig ausgeschrieben."},"formLength":3,"family":"defective"},{"id":"call","meaning":{"ar":"الدعاء","de":"rufen / bitten"},"kind":"weak","forms":{"past":["دَعَوْتُ","دَعَوْنَا","دَعَوْتَ","دَعَوْتِ","دَعَوْتُمَا","دَعَوْتُمَا","دَعَوْتُمْ","دَعَوْتُنَّ","دَعَا","دَعَتْ","دَعَوَا","دَعَتَا","دَعَوْا","دَعَوْنَ"],"present":["أَدْعُو","نَدْعُو","تَدْعُو","تَدْعِينَ","تَدْعُوَانِ","تَدْعُوَانِ","تَدْعُونَ","تَدْعُونَ","يَدْعُو","تَدْعُو","يَدْعُوَانِ","تَدْعُوَانِ","يَدْعُونَ","يَدْعُونَ"],"imperative":["اُدْعُ","اُدْعِي","اُدْعُوَا","اُدْعُوا","اُدْعُونَ"]},"example":{"past":["دَعَا صَدِيقَهُ.","Er rief seinen Freund."],"present":["يَدْعُو صَدِيقَهُ.","Er ruft seinen Freund."],"imperative":["اُدْعُ صَدِيقَكَ.","Ruf deinen Freund."]},"note":{"ar":"فعل ناقص واوي: دَعَا، دَعَوْتُ؛ تُحذف الواو في اُدْعُ ولَمْ يَدْعُ. نون النسوة ثابتة في لَمْ يَدْعُونَ.","de":"Beachte die Stammänderungen in der Tabelle; die Formen sind vollständig ausgeschrieben."},"formLength":3,"family":"defective"},{"id":"extend","meaning":{"ar":"المدّ","de":"ausstrecken"},"kind":"doubled","forms":{"past":["مَدَدْتُ","مَدَدْنَا","مَدَدْتَ","مَدَدْتِ","مَدَدْتُمَا","مَدَدْتُمَا","مَدَدْتُمْ","مَدَدْتُنَّ","مَدَّ","مَدَّتْ","مَدَّا","مَدَّتَا","مَدُّوا","مَدَدْنَ"],"present":["أَمُدُّ","نَمُدُّ","تَمُدُّ","تَمُدِّينَ","تَمُدَّانِ","تَمُدَّانِ","تَمُدُّونَ","تَمْدُدْنَ","يَمُدُّ","تَمُدُّ","يَمُدَّانِ","تَمُدَّانِ","يَمُدُّونَ","يَمْدُدْنَ"],"imperative":["مُدَّ","مُدِّي","مُدَّا","مُدُّوا","اُمْدُدْنَ"]},"example":{"past":["مَدَّ يَدَهُ.","Er streckte seine Hand aus."],"present":["يَمُدُّ يَدَهُ.","Er streckt seine Hand aus."],"imperative":["مُدَّ يَدَكَ.","Streck deine Hand aus."]},"note":{"ar":"صحيح مضاعف: نفكّ الإدغام مع تاء الفاعل ونون النسوة: مَدَدْتُ، يَمْدُدْنَ. في الأمر مُدَّ، ويجوز اُمْدُدْ. نعرض في الجزم للمفرد الوجه المدغم بالفتح: لَمْ يَمُدَّ.","de":"Beachte die Stammänderungen in der Tabelle; die Formen sind vollständig ausgeschrieben."},"formLength":3,"family":"doubled"}];
  const pronouns = [
    {
      ar: "أَنَا",
      de: "ich",
      description: "المتكلّم المفرد",
      past: "ْتُ",
      present: ["أَ", "ُ"],
    },
    {
      ar: "نَحْنُ",
      de: "wir",
      description: "المتكلّم الجمع أو المثنّى",
      past: "ْنَا",
      present: ["نَ", "ُ"],
    },
    {
      ar: "أَنْتَ",
      de: "du · männlich",
      description: "المخاطب المفرد المذكّر",
      past: "ْتَ",
      present: ["تَ", "ُ"],
    },
    {
      ar: "أَنْتِ",
      de: "du · weiblich",
      description: "المخاطب المفرد المؤنّث",
      past: "ْتِ",
      present: ["تَ", "ِينَ"],
    },
    {
      ar: "أَنْتُمَا",
      de: "ihr zwei · männlich / gemischt",
      description: "المخاطب المثنّى المذكّر",
      past: "ْتُمَا",
      present: ["تَ", "َانِ"],
    },
    {
      ar: "أَنْتُمَا",
      de: "ihr zwei · weiblich",
      description: "المخاطب المثنّى المؤنّث",
      past: "ْتُمَا",
      present: ["تَ", "َانِ"],
    },
    {
      ar: "أَنْتُمْ",
      de: "ihr · männlich / gemischt",
      description: "المخاطب الجمع المذكّر",
      past: "ْتُمْ",
      present: ["تَ", "ُونَ"],
    },
    {
      ar: "أَنْتُنَّ",
      de: "ihr · weiblich",
      description: "المخاطب الجمع المؤنّث",
      past: "ْتُنَّ",
      present: ["تَ", "ْنَ"],
    },
    {
      ar: "هُوَ",
      de: "er",
      description: "الغائب المفرد المذكّر",
      past: "َ",
      present: ["يَ", "ُ"],
    },
    {
      ar: "هِيَ",
      de: "sie · Einzahl",
      description: "الغائب المفرد المؤنّث",
      past: "َتْ",
      present: ["تَ", "ُ"],
    },
    {
      ar: "هُمَا",
      de: "sie zwei · männlich / gemischt",
      description: "الغائب المثنّى المذكّر",
      past: "َا",
      present: ["يَ", "َانِ"],
    },
    {
      ar: "هُمَا",
      de: "sie zwei · weiblich",
      description: "الغائب المثنّى المؤنّث",
      past: "َتَا",
      present: ["تَ", "َانِ"],
    },
    {
      ar: "هُمْ",
      de: "sie · männlich / gemischt",
      description: "الغائب الجمع المذكّر",
      past: "ُوا",
      present: ["يَ", "ُونَ"],
    },
    {
      ar: "هُنَّ",
      de: "sie · weiblich",
      description: "الغائب الجمع المؤنّث",
      past: "ْنَ",
      present: ["يَ", "ْنَ"],
    },
  ];

  pronouns.forEach((person, index) => {
    person.index = index;
  });
  const commandIndices = { 2: 0, 3: 1, 4: 2, 5: 2, 6: 3, 7: 4 };
  const imperativePronouns = [
    pronouns[2],
    pronouns[3],
    {
      ...pronouns[4],
      description: "المخاطب المثنّى المذكّر والمؤنّث",
      de: "ihr zwei · beide Geschlechter",
    },
    pronouns[6],
    pronouns[7],
  ];
  const commandEndings = ["ْ", "ِي", "َا", "ُوا", "ْنَ"];
  function pronounsFor(tense) {
    return tense === "imperative" ? imperativePronouns : pronouns;
  }
  function parts(verb, tense, person) {
    if (!["past", "present", "imperative"].includes(tense)) return null;
    const commandIndex = commandIndices[person.index];
    if (tense === "imperative" && commandIndex === undefined) return null;
    if (verb.forms) {
      const form =
        verb.forms[tense][tense === "imperative" ? commandIndex : person.index];
      let prefix =
        tense === "present" && form.startsWith(person.present[0])
          ? person.present[0]
          : "";
      let suffix =
        tense === "past"
          ? person.past
          : tense === "present"
            ? person.present[1]
            : commandEndings[commandIndex];
      // Contracted hamza spellings (e.g. قَرَآ) cannot be split at a suffix boundary.
      if (!form.endsWith(suffix)) suffix = "";
      return [
        prefix,
        form.slice(prefix.length, suffix ? -suffix.length : undefined),
        suffix,
      ];
    }
    const combine = (prefix, stem, suffix) =>
      stem.endsWith("ن") && suffix === "ْنَ"
        ? [prefix, stem.slice(0, -1) + "نَّ", ""]
        : [prefix, stem, suffix];
    if (tense === "past") return combine("", verb.pastStem, person.past);
    if (tense === "present")
      return combine(
        person.present[0][0] + (verb.presentVowel || "َ"),
        verb.presentStem,
        person.present[1],
      );
    const prefix = /^[اأإ]/u.test(verb.imperativeStem)
      ? verb.imperativeStem.slice(0, 2)
      : "";
    return combine(
      prefix,
      verb.imperativeStem.slice(prefix.length),
      commandEndings[commandIndex],
    );
  }
  function conjugate(verb, tense, person) {
    const segments = parts(verb, tense, person);
    return segments ? segments.join("") : null;
  }
  // Person-sensitive mood changes: the feminine-plural Nūn is never removed.
  function inflectedPresent(verb, person, mood) {
    let form = conjugate(verb, 'present', person);
    if ([7,13].includes(person.index)) return form;
    if ([3,4,5,6,10,11,12].includes(person.index))
      return form.replace(/ُونَ$/u, 'ُوا').replace(/ِينَ$/u, 'ِي').replace(/َانِ$/u, 'َا').replace(/آنِ$/u,'آ');
    if (mood === 'subjunctive') {
      if (['walk','call'].includes(verb.id)) return form + 'َ';
      return form.replace(/ُ$/u, 'َ');
    }
    if (verb.id === 'say') return form.replace(/قُولُ$/u,'قُلْ');
    if (verb.id === 'sleep') return form.replace(/نَامُ$/u,'نَمْ');
    if (['walk','call'].includes(verb.id)) return form.slice(0,-1);
    if (verb.id === 'extend') return form.replace(/ُ$/u,'َ');
    return form.replace(/ُ$/u,'ْ');
  }
  function negativeForm(verb, mode, person) {
    if (mode === 'past') return 'مَا ' + conjugate(verb,'past',person);
    if (mode === 'present') return 'لَا ' + conjugate(verb,'present',person);
    if (mode === 'past-lam') return 'لَمْ ' + inflectedPresent(verb,person,'jussive');
    if (mode === 'future') return 'لَنْ ' + inflectedPresent(verb,person,'subjunctive');
    if (mode === 'prohibition') return commandIndices[person.index] === undefined ? null : 'لَا ' + inflectedPresent(verb,person,'jussive');
    return null;
  }
  const data = {
    negativeForm,
    inflectedPresent,
    verbs,
    pronouns,
    imperativePronouns,
    pronounsFor,
    parts,
    conjugate,
  };
  if (typeof module !== "undefined" && module.exports) module.exports = data;
  else window.VerbLessonData = data;
})();
