/* Retire only the former monolithic root worker; never remove learner storage. */
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 const base=new URL(self.registration.scope),prefix='huroof-pwa:'+base.pathname+':';
 for(const name of await caches.keys())if(name.startsWith(prefix))await caches.delete(name);
 await self.registration.unregister();
 for(const client of await self.clients.matchAll({type:'window'})){
  const url=new URL(client.url);if(url.origin===base.origin&&[base.pathname,base.pathname+'index.html'].includes(url.pathname))await client.navigate(base.href);
 }
})()));
