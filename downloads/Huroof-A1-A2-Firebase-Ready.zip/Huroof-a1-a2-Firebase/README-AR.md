# العربية A1 وA2 — مشروع مستقل جاهز

هذه الحزمة مضبوطة لمشروع huroof-a1-a2. لا تحتاج إلى تعديل إعدادات Web أو تشغيل firebase init.

داخل المشروع من Firebase Console: فعّل Authentication → Email/Password، وأنشئ Cloud Firestore Standard بمعرّف (default) في وضع Production.

افتح PowerShell داخل هذا المجلد بجانب firebase.json ونفّذ:

```powershell
node deploy-firebase.cjs
```

إذا طُلب تسجيل الدخول: `npx.cmd firebase-tools login`. ينشر السكربت إلى مشروع huroof-a1-a2 فقط، والقواعد أولًا ثم الاستضافة.

بعد النشر: https://huroof-a1-a2.web.app/

لمنح نفسك الإدارة، أنشئ حسابك في التطبيق وأكّد البريد. انسخ UID من Authentication → Users. أنشئ مستند Firestore بالمسار oliveFreeAdmins/UID، بحقل enabled من نوع boolean بقيمة true. أعد تسجيل الدخول. حسابات الطلاب والتقدّم والإدارة منفصلة عن المشاريع الأخرى.
