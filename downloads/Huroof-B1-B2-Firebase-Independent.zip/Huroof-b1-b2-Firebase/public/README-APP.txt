العربية B1 وB2 — Firebase مستقل
انظر README-AR.md بجانب firebase.json.
