# مشروع Firebase مستقل — الكتب والاختبارات

هذا المجلد يخص هذا التطبيق فقط، ويحتوي firebase.json وfirestore.rules وpublic.
لا تضعه داخل حزمة التطبيقات الأربعة، ولا تستخدم إعدادات المشروع القديم بالخطأ.

1. أنشئ مشروعًا مستقلاً من https://console.firebase.google.com/؛ اختر اسمًا ومعرّفًا يخص هذا التطبيق. يمكنك اختيار خطة Spark دون إضافة وسيلة دفع.
2. داخل المشروع: Authentication → Sign-in method → فعّل Email/Password.
3. Firestore Database → أنشئ قاعدة Standard بمعرّف (default) في وضع Production. لا تستخدم Realtime Database لهذا التطبيق.
4. Project settings → Your apps → أضف تطبيق Web بالزر </>. انسخ إعدادات firebaseConfig العامة إلى ملف firebase-web-config.json داخل هذا المجلد. يقبل المُعدّ JSON أو نص const firebaseConfig من Console، ولا يقبل مفاتيح Service Account الخاصة.
5. افتح PowerShell داخل هذا المجلد الذي يحتوي firebase.json ونفّذ:

```powershell
node configure-firebase.cjs
npx.cmd firebase-tools login
node deploy-firebase.cjs
```

ملاحظة: استخدم npx.cmd لتجنب منع npx.ps1 في PowerShell. لا حاجة إلى firebase init.
أمر النشر يحدد مشروع هذا التطبيق صراحةً وينشر قواعد Firestore أولاً ثم Hosting.
لا يمكن نشر الحزمة قبل ضبط إعدادات المشروع؛ يمنع فحص predeploy استعمال مشروع مخالف.

6. أضف نطاق PROJECT_ID.web.app إلى Authorized domains في Authentication إذا لم يكن موجودًا.
7. افتح موقع التطبيق وأنشئ حساب المدير، ثم أكّد البريد. داخل Authentication → Users انسخ UID حسابك. من Firestore أنشئ مجموعة oliveFreeAdmins ومستندًا بمعرّف UID نفسه وحقل enabled من نوع boolean بقيمة true. أعد تسجيل الدخول لفتح لوحة الإدارة وإضافة الطلاب.

كرر هذه الخطوات لكل مشروع على حدة. الحسابات والطلاب والتقدّم ولوحة الإدارة منفصلة بين المشاريع. لا يُنقل سجل المشروع السابق تلقائيًا، ولا يُحذف. يُحفظ تقدّم هذا التطبيق في users/UID/apps/books/learning داخل مشروعه الخاص.

لا ترفع firebase-web-config.json أو ملفات الإعداد يدوياً إلى Hosting؛ المجلد المنشور هو public فقط. إعدادات Web عامة بطبيعتها، وحماية بيانات الطلاب تعتمد على Authentication وقواعد Firestore الخاصة بالمستخدم والإيميل المسموح.
