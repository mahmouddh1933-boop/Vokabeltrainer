الكتب والاختبارات — Firebase مستقل
انظر README-AR.md بجانب firebase.json.
