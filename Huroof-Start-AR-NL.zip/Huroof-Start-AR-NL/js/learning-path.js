(() => {
  "use strict";
  const stages = [{"id":"letters","href":"letters.html","ar":"الحروف وتدريباتها","nl":"Alfabet en oefeningen","description":"افتح الدروس والتدريبات وتابع من حيث توقفت.","descriptionDe":"Open de lessen en oefeningen en leer verder."},{"id":"reading","href":"reading.html","ar":"القراءة والهجاء","nl":"Lezen en spellen","description":"افتح الدروس والتدريبات وتابع من حيث توقفت.","descriptionDe":"Open de lessen en oefeningen en leer verder."},{"id":"reading-trainer","href":"reading-trainer.html","ar":"مدرّب القراءة","nl":"Leestrainer","description":"افتح الدروس والتدريبات وتابع من حيث توقفت.","descriptionDe":"Open de lessen en oefeningen en leer verder."},{"id":"reading-exercises","href":"reading-exercises.html","ar":"تدريبات على القراءة","nl":"Leesatelier","description":"افتح الدروس والتدريبات وتابع من حيث توقفت.","descriptionDe":"Open de lessen en oefeningen en leer verder."},{"id":"progress","href":"progress.html","ar":"تقدّمي","nl":"Mijn voortgang","description":"افتح الدروس والتدريبات وتابع من حيث توقفت.","descriptionDe":"Open de lessen en oefeningen en leer verder."}];
  const groups = {
    "reading-exercises.html": "reading",
    "reading-trainer.html": "reading",
    "huruf.html": "letters",
    "letter-tests.html": "letters",
    "sounds.html": "letters",
    "lernseite.html": "vocabulary",
    "review.html": "vocabulary",
    "stats.html": "vocabulary",
    "test.html": "vocabulary",
    "verbs.html": "grammar",
    "book-level-two.html": "books",
    "arabic-youth.html": "books",
    "youth-training-two.html": "books",
    "youth-book-two-part-one.html": "books",
  };
  const page = location.pathname.split("/").pop() || "index.html";
  const stage =
    stages.find((s) => s.href === page) ||
    stages.find(
      (s) => s.id === (page.startsWith("test") ? "vocabulary" : groups[page]),
    );
  const state = () => window.VocabApp.getStats().learningRouteV1 || {};
  const update = (patch) => {
    const stats = window.VocabApp.getStats();
    window.VocabApp.setJSON("learningStats", {
      ...stats,
      learningRouteV1: { ...state(), ...patch },
    });
  };
  window.LearningRoute = { stages, stage, state, update };
  function redirectLegacyVocabularyLink() {
    if (page === "index.html" && ["#ready-lists-panel", "#excel-panel"].includes(location.hash)) {
      location.replace("vocabulary.html" + location.hash);
      return true;
    }
    return false;
  }
  window.addEventListener("hashchange", redirectLegacyVocabularyLink);
  window.JisrStorage.ready(() => {
    if (redirectLegacyVocabularyLink()) return;
    if (stage) {
      update({ lastStage: stage.id });
      const bar = document.createElement("nav");
      bar.className = "route-stage-nav";
      bar.setAttribute("aria-label", "مسار التعلم / Leerroute");
      const i = stages.indexOf(stage);
      for (const [href, ar, nl] of [
        [
          i ? stages[i - 1].href : "index.html",
          i ? "الخطوة السابقة" : "مسار التعلم",
          i ? "Vorige stap" : "Leerroute",
        ],
        ["index.html", "المسار الكامل", "Volledige leerroute"],
        [
          i < stages.length - 1 ? stages[i + 1].href : "index.html",
          i < stages.length - 1 ? "الخطوة التالية" : "العودة للمسار",
          i < stages.length - 1 ? "Volgende stap" : "Naar de leerroute",
        ],
      ]) {
        const a = document.createElement("a");
        a.href = href;
        a.dataset.ar = ar;
        a.dataset.nl = nl;
        a.textContent = ar;
        bar.append(a);
      }
      document.querySelector("main")?.append(bar);
    }
  });
})();
