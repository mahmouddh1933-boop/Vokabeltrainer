(() => {
  "use strict";
  const bi = (ar, nl) => ({ ar, nl });
  const card = (glyph, target, word, nl, arNote, deNote, number, audio = `audio/letter-related/${String(number).padStart(2,"0")}.mp3`) => ({ glyph, target, word, meaning: nl, note: bi(arNote, deNote), audio });
  const groups = {
    "أ": {
      title: bi("الهمزة والألف: صور نقرأها مع الألف", "Hamza en alif: verwante schrijfwijzen"),
      intro: bi("أ وإ وآ ليست مثل ا المدّية. ؤ همزة على واو، وئ همزة على نبرة؛ ليستا شكلين متصلين للألف ولا حرفين جديدين. ء همزة مفردة، وى ألف مقصورة بلا نقطتين، تنطق ألفًا لا ياءً.", "Onderscheid أ, إ en آ van de lange ا. Bij ؤ staat hamza op wāw en bij ئ op een yā-drager. Dit zijn geen verbindingsvormen van alif of losse letters van het alfabet. ء is hamza zonder drager. ى is een alif maqṣūra zonder punten en klinkt als ā."),
      cards: [
        card("أ", "أ", "أَسَدٌ", "leeuw", "همزة فوق الألف؛ هنا معها فتحة.", "Hamza boven alif, hier met fatḥa.", 1),
        card("إ", "إ", "إِبْرَةٌ", "naald", "همزة القطع تحت الألف عند الكسر.", "Qaṭʿ-hamza onder alif met kasra.", 2),
        card("آ", "آ", "آدَمُ", "Adam", "همزة يتلوها مدّ بالألف، وتكتب بعلامة المدّ.", "Hamza plus lange ā met een madda-teken.", 3),
        card("ا", "ا", "بَابٌ", "deur", "ألف المدّ، لا رأس همزة عليها.", "Alif als lange klinker zonder hamza.", 4),
        card("ؤ", "ؤ", "مُؤْمِنٌ", "gelovig", "همزة على كرسي الواو؛ لا ننطق الكرسي واوًا مستقلة.", "Hamza op wāw. De drager voegt geen w-klank toe.", 5),
        card("ئ", "ئ", "بِئْرٌ", "put", "همزة على نبرة، وتسمى همزة على ياء أيضًا.", "Hamza op een yā-drager, ook nabra genoemd.", 6),
        card("ء", "ء", "مَاءٌ", "water", "همزة مفردة على السطر.", "Hamza zonder drager op de regel.", 7),
        card("ى", "ى", "فَتَى", "jongeman", "ألف مقصورة في آخر الكلمة؛ لا نقطتين تحتها. نقرأ المثال هنا عند الوقف: فَتَى، بلا تنوين مسموع.", "Alif maqṣūra aan het woordeinde, zonder twee punten. Bij een pauze spreek je dit uit als fatā, zonder hoorbare tanwīn.", 8, "audio/letter-related/08-waqf.mp3"),
      ],
    },
    "ت": {
      title: bi("مع التاء: ت وة وـة", "Bij tā: ت, ة en ـة"),
      intro: bi("التاء المبسوطة ت تبقى تاءً عند الوقف والوصل. التاء المربوطة ة أو ـة تأتي آخر الكلمة، وتنطق هاءً عند الوقف وتاءً عند الوصل. ة وـة صورتان لحرف واحد بحسب الاتصال بما قبله.", "Open tā ت klinkt als t, met of zonder pauze. Tā marbūṭa ة of ـة staat aan het woordeinde. Hij klinkt als h bij een pauze en als t in een doorlopende zin. ة en ـة zijn vormen van hetzelfde teken."),
      cards: [
        card("ت", "ت", "بَيْتٌ", "huis", "تاء مبسوطة؛ نقف عليها بصوت تاء.", "Open tā. Bij een pauze blijft de t hoorbaar.", 9),
        card("ـة", "ة", "مَدْرَسَةٌ", "school", "تاء مربوطة متصلة بالسين قبلها.", "Tā marbūṭa, verbonden met de voorafgaande sīn.", 10),
        card("ة", "ة", "كُرَةٌ", "bal", "تاء مربوطة منفصلة لأن الراء لا تتصل بما بعدها.", "Losse tā marbūṭa na rā, die niet met het volgende teken verbindt.", 11),
      ],
    },
  };
  const audio = {};
  for (const group of Object.values(groups)) for (const item of group.cards) audio[item.word.normalize("NFC")] = item.audio;
  const api = { groups, audio };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else { window.ArabicLetterRelated = api; Object.assign(window.ArabicLetterData.audio, audio); }
})();
