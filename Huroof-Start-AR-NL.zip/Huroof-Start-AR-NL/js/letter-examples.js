(() => {
  "use strict";
  // Each row: letter, initial, medial, separated final, connected final.
  // The separated final is always preceded by ا د ذ ر ز و (including أ).
  const rows = [
    [
      "أ",
      ["أسد", "leeuw"],
      ["سأل", "fragte"],
      ["قرأ", "las"],
      ["ملأ", "füllte"],
    ],
    ["ب", ["بطة", "eend"], ["جبل", "Berg"], ["باب", "deur"], ["كلب", "hond"]],
    [
      "ت",
      ["تفاح", "appels"],
      ["كتاب", "boek"],
      ["نبات", "Pflanze"],
      ["بيت", "huis"],
    ],
    [
      "ث",
      ["ثعلب", "vos"],
      ["مثلث", "Dreieck"],
      ["إرث", "Erbe"],
      ["بحث", "Suche"],
    ],
    [
      "ج",
      ["جمل", "kameel"],
      ["نجم", "ster"],
      ["تاج", "kroon"],
      ["ثلج", "sneeuw"],
    ],
    [
      "ح",
      ["حصان", "paard"],
      ["بحر", "zee"],
      ["تفاح", "appels"],
      ["ملح", "Salz"],
    ],
    [
      "خ",
      ["خبز", "brood"],
      ["نخلة", "dadelpalm"],
      ["صاروخ", "Rakete"],
      ["مطبخ", "Küche"],
    ],
    ["د", ["دب", "beer"], ["مدرسة", "school"], ["ورد", "Rosen"], ["يد", "hand"]],
    [
      "ذ",
      ["ذرة", "maïs"],
      ["بذرة", "Samen"],
      ["رذاذ", "Sprühregen"],
      ["فخذ", "Oberschenkel"],
    ],
    [
      "ر",
      ["رمان", "granaatappel"],
      ["برتقال", "Orangen"],
      ["دار", "huis"],
      ["قمر", "maan"],
    ],
    [
      "ز",
      ["زهرة", "bloem"],
      ["مزرعة", "Bauernhof"],
      ["أرز", "Reis"],
      ["خبز", "brood"],
    ],
    [
      "س",
      ["سمكة", "vis"],
      ["مسرح", "Theater"],
      ["كأس", "glas"],
      ["شمس", "zon"],
    ],
    [
      "ش",
      ["شمس", "zon"],
      ["بشرة", "Haut"],
      ["فراش", "Bettzeug"],
      ["جيش", "Armee"],
    ],
    [
      "ص",
      ["صقر", "valk"],
      ["بصل", "Zwiebeln"],
      ["غواص", "Taucher"],
      ["قفص", "Käfig"],
    ],
    [
      "ض",
      ["ضفدع", "kikker"],
      ["خضار", "Gemüse"],
      ["حوض", "Becken"],
      ["بيض", "Eier"],
    ],
    [
      "ط",
      ["طائرة", "vliegtuig"],
      ["بطيخ", "watermeloen"],
      ["بساط", "Teppich"],
      ["قط", "kat"],
    ],
    [
      "ظ",
      ["ظرف", "envelop"],
      ["نظيف", "sauber"],
      ["ألفاظ", "Ausdrücke"],
      ["حظ", "Glück"],
    ],
    [
      "ع",
      ["عنب", "druiven"],
      ["معلم", "Lehrer"],
      ["ذراع", "arm"],
      ["إصبع", "Finger"],
    ],
    [
      "غ",
      ["غزال", "gazelle"],
      ["مغرب", "Westen"],
      ["فراغ", "Freiraum"],
      ["صمغ", "Klebstoff"],
    ],
    [
      "ف",
      ["فيل", "olifant"],
      ["مفتاح", "sleutel"],
      ["خروف", "schaap"],
      ["كتف", "Schulter"],
    ],
    [
      "ق",
      ["قمر", "maan"],
      ["مقعد", "Sitzplatz"],
      ["أوراق", "Blätter"],
      ["طبق", "bord"],
    ],
    [
      "ك",
      ["كتاب", "boek"],
      ["مكتب", "Schreibtisch"],
      ["شباك", "raam"],
      ["سمك", "vis"],
    ],
    [
      "ل",
      ["ليمون", "citroen"],
      ["قلم", "pen"],
      ["هلال", "maansikkel"],
      ["جبل", "Berg"],
    ],
    [
      "م",
      ["موز", "banaan"],
      ["جمل", "kameel"],
      ["طعام", "eten"],
      ["قلم", "pen"],
    ],
    [
      "ن",
      ["نجم", "ster"],
      ["منزل", "Wohnung"],
      ["حصان", "paard"],
      ["عين", "oog"],
    ],
    [
      "ه",
      ["هلال", "maansikkel"],
      ["نهر", "Fluss"],
      ["مياه", "water"],
      ["وجه", "gezicht"],
    ],
    [
      "و",
      ["وردة", "roos"],
      ["فول", "Bohnen"],
      ["جرو", "Welpe"],
      ["دلو", "emmer"],
    ],
    ["ي", ["يد", "hand"], ["بيت", "huis"], ["شاي", "Tee"], ["كرسي", "stoel"]],
  ];
  const examples = Object.fromEntries(
    rows.map(([letter, ...words]) => [
      letter,
      words.map(([word, nl], position) => ({
        word,
        nl,
        index:
          position === 0 ? 0 : position === 1 ? 1 : Array.from(word).length - 1,
      })),
    ]),
  );
  const nonJoining = new Set(Array.from("اأإآدذرزو"));
  function graphemes(word) {
    const result = [];
    for (const char of word) {
      if (/\p{M}/u.test(char) && result.length)
        result[result.length - 1] += char;
      else result.push(char);
    }
    return result;
  }
  function highlight(container, word, index) {
    const clusters = graphemes(word);
    const target = document.createElement("mark");
    target.className = "letter-target";
    target.textContent = clusters[index];
    container.replaceChildren(
      document.createTextNode(clusters.slice(0, index).join("")),
      target,
      document.createTextNode(clusters.slice(index + 1).join("")),
    );
  }
  const api = { examples, nonJoining, graphemes, highlight };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else window.ArabicLetterExamples = api;
})();
