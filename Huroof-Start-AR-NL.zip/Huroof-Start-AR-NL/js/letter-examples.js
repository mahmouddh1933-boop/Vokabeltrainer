(() => {
  "use strict";
  // Each row: letter, initial, medial, separated final, connected final.
  // The separated final is always preceded by ا د ذ ر ز و (including أ).
  const rows = [
    [
      "أ",
      ["أسد", "leeuw"],
      ["سأل", "vroeg"],
      ["قرأ", "las"],
      ["ملأ", "vulde"],
    ],
    ["ب", ["بطة", "eend"], ["جبل", "berg"], ["باب", "deur"], ["كلب", "hond"]],
    [
      "ت",
      ["تفاح", "appels"],
      ["كتاب", "boek"],
      ["نبات", "plant"],
      ["بيت", "huis"],
    ],
    [
      "ث",
      ["ثعلب", "vos"],
      ["مثلث", "driehoek"],
      ["إرث", "erfenis"],
      ["بحث", "zoektocht"],
    ],
    [
      "ج",
      ["جمل", "kameel"],
      ["نجم", "ster"],
      ["تاج", "kroon"],
      ["ثلج", "sneeuw"],
    ],
    [
      "ح",
      ["حصان", "paard"],
      ["بحر", "zee"],
      ["تفاح", "appels"],
      ["ملح", "zout"],
    ],
    [
      "خ",
      ["خبز", "brood"],
      ["نخلة", "dadelpalm"],
      ["صاروخ", "raket"],
      ["مطبخ", "keuken"],
    ],
    ["د", ["دب", "beer"], ["مدرسة", "school"], ["ورد", "rozen"], ["يد", "hand"]],
    [
      "ذ",
      ["ذرة", "maïs"],
      ["بذرة", "zaad"],
      ["رذاذ", "motregen"],
      ["فخذ", "bovenbeen"],
    ],
    [
      "ر",
      ["رمان", "granaatappel"],
      ["برتقال", "sinaasappels"],
      ["دار", "huis"],
      ["قمر", "maan"],
    ],
    [
      "ز",
      ["زهرة", "bloem"],
      ["مزرعة", "boerderij"],
      ["أرز", "rijst"],
      ["خبز", "brood"],
    ],
    [
      "س",
      ["سمكة", "vis"],
      ["مسرح", "theater"],
      ["كأس", "glas"],
      ["شمس", "zon"],
    ],
    [
      "ش",
      ["شمس", "zon"],
      ["بشرة", "huid"],
      ["فراش", "beddengoed"],
      ["جيش", "leger"],
    ],
    [
      "ص",
      ["صقر", "valk"],
      ["بصل", "uien"],
      ["غواص", "duiker"],
      ["قفص", "kooi"],
    ],
    [
      "ض",
      ["ضفدع", "kikker"],
      ["خضار", "groente"],
      ["حوض", "bak"],
      ["بيض", "eieren"],
    ],
    [
      "ط",
      ["طائرة", "vliegtuig"],
      ["بطيخ", "watermeloen"],
      ["بساط", "tapijt"],
      ["قط", "kat"],
    ],
    [
      "ظ",
      ["ظرف", "envelop"],
      ["نظيف", "schoon"],
      ["ألفاظ", "uitdrukkingen"],
      ["حظ", "geluk"],
    ],
    [
      "ع",
      ["عنب", "druiven"],
      ["معلم", "leraar"],
      ["ذراع", "arm"],
      ["إصبع", "vinger"],
    ],
    [
      "غ",
      ["غزال", "gazelle"],
      ["مغرب", "westen"],
      ["فراغ", "vrije ruimte"],
      ["صمغ", "lijm"],
    ],
    [
      "ف",
      ["فيل", "olifant"],
      ["مفتاح", "sleutel"],
      ["خروف", "schaap"],
      ["كتف", "schouder"],
    ],
    [
      "ق",
      ["قمر", "maan"],
      ["مقعد", "zitplaats"],
      ["أوراق", "bladeren"],
      ["طبق", "bord"],
    ],
    [
      "ك",
      ["كتاب", "boek"],
      ["مكتب", "bureau"],
      ["شباك", "raam"],
      ["سمك", "vis"],
    ],
    [
      "ل",
      ["ليمون", "citroen"],
      ["قلم", "pen"],
      ["هلال", "maansikkel"],
      ["جبل", "berg"],
    ],
    [
      "م",
      ["موز", "banaan"],
      ["جمل", "kameel"],
      ["طعام", "eten"],
      ["قلم", "pen"],
    ],
    [
      "ن",
      ["نجم", "ster"],
      ["منزل", "woning"],
      ["حصان", "paard"],
      ["عين", "oog"],
    ],
    [
      "ه",
      ["هلال", "maansikkel"],
      ["نهر", "rivier"],
      ["مياه", "water"],
      ["وجه", "gezicht"],
    ],
    [
      "و",
      ["وردة", "roos"],
      ["فول", "bonen"],
      ["جرو", "pup"],
      ["دلو", "emmer"],
    ],
    ["ي", ["يد", "hand"], ["بيت", "huis"], ["شاي", "thee"], ["كرسي", "stoel"]],
  ];
  const examples = Object.fromEntries(
    rows.map(([letter, ...words]) => [
      letter,
      words.map(([word, nl], position) => ({
        word,
        nl,
        index:
          position === 0 ? 0 : position === 1 ? 1 : Array.from(word).length - 1,
      })),
    ]),
  );
  const nonJoining = new Set(Array.from("اأإآدذرزو"));
  function graphemes(word) {
    const result = [];
    for (const char of word) {
      if (/\p{M}/u.test(char) && result.length)
        result[result.length - 1] += char;
      else result.push(char);
    }
    return result;
  }
  function highlight(container, word, index) {
    const clusters = graphemes(word);
    const target = document.createElement("mark");
    target.className = "letter-target";
    target.textContent = clusters[index];
    container.replaceChildren(
      document.createTextNode(clusters.slice(0, index).join("")),
      target,
      document.createTextNode(clusters.slice(index + 1).join("")),
    );
  }
  const api = { examples, nonJoining, graphemes, highlight };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else window.ArabicLetterExamples = api;
})();
