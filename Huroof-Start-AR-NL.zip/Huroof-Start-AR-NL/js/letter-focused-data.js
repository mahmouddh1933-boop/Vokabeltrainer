(() => {
  "use strict";
  const data =
    typeof module !== "undefined" && module.exports
      ? require("./letter-data.js")
      : window.ArabicLetterData;
  const examples =
    typeof module !== "undefined" && module.exports
      ? require("./letter-examples.js")
      : window.ArabicLetterExamples;
  const extras = {
    أ: [
      {
        word: "أرنب",
        nl: "konijn",
      },
      {
        word: "أمل",
        nl: "hoop",
      },
      {
        word: "أذن",
        nl: "oor",
      },
      {
        word: "أم",
        nl: "moeder",
      },
      {
        word: "رأس",
        nl: "hoofd",
      },
      {
        word: "كأس",
        nl: "glas",
      },
      {
        word: "بدأ",
        nl: "begon",
      },
      {
        word: "نبأ",
        nl: "bericht",
      },
    ],
    ب: [
      {
        word: "بنت",
        nl: "meisje",
      },
      {
        word: "بحر",
        nl: "zee",
      },
      {
        word: "بستان",
        nl: "tuin",
      },
      {
        word: "برج",
        nl: "toren",
      },
      {
        word: "خبز",
        nl: "brood",
      },
      {
        word: "سبح",
        nl: "zwom",
      },
      {
        word: "ثوب",
        nl: "jurk",
      },
      {
        word: "حبل",
        nl: "touw",
      },
    ],
    ت: [
      {
        word: "تفاحة",
        nl: "appel",
      },
      {
        word: "تاج",
        nl: "kroon",
      },
      {
        word: "تمساح",
        nl: "krokodil",
      },
      {
        word: "توت",
        nl: "moerbeien",
      },
      {
        word: "مفتاح",
        nl: "sleutel",
      },
      {
        word: "دفتر",
        nl: "schrift",
      },
      {
        word: "حوت",
        nl: "walvis",
      },
      {
        word: "صوت",
        nl: "stem",
      },
    ],
    ث: [
      {
        word: "ثور",
        nl: "stier",
      },
      {
        word: "ثلج",
        nl: "sneeuw",
      },
      {
        word: "ثوب",
        nl: "jurk",
      },
      {
        word: "ثوم",
        nl: "knoflook",
      },
      {
        word: "كثير",
        nl: "veel",
      },
      {
        word: "مثال",
        nl: "voorbeeld",
      },
      {
        word: "أثاث",
        nl: "meubels",
      },
      {
        word: "حديث",
        nl: "gesprek",
      },
    ],
    ج: [
      {
        word: "جبن",
        nl: "kaas",
      },
      {
        word: "جرس",
        nl: "klok",
      },
      {
        word: "جسر",
        nl: "brug",
      },
      {
        word: "جزر",
        nl: "wortels",
      },
      {
        word: "عجلة",
        nl: "wiel",
      },
      {
        word: "حجر",
        nl: "steen",
      },
      {
        word: "برج",
        nl: "toren",
      },
      {
        word: "موج",
        nl: "golven",
      },
    ],
    ح: [
      {
        word: "حبل",
        nl: "touw",
      },
      {
        word: "حوت",
        nl: "walvis",
      },
      {
        word: "حديقة",
        nl: "tuin",
      },
      {
        word: "حقيبة",
        nl: "tas",
      },
      {
        word: "سحابة",
        nl: "wolk",
      },
      {
        word: "نحلة",
        nl: "bij",
      },
      {
        word: "صباح",
        nl: "ochtend",
      },
      {
        word: "مفتاح",
        nl: "sleutel",
      },
    ],
    خ: [
      {
        word: "خروف",
        nl: "schaap",
      },
      {
        word: "خيمة",
        nl: "tent",
      },
      {
        word: "خيار",
        nl: "komkommer",
      },
      {
        word: "خاتم",
        nl: "ring",
      },
      {
        word: "بخار",
        nl: "stoom",
      },
      {
        word: "صخرة",
        nl: "rots",
      },
      {
        word: "بطيخ",
        nl: "watermeloen",
      },
      {
        word: "شيخ",
        nl: "sjeik",
      },
    ],
    د: [
      {
        word: "دفتر",
        nl: "schrift",
      },
      {
        word: "دلو",
        nl: "emmer",
      },
      {
        word: "درج",
        nl: "trap",
      },
      {
        word: "دجاج",
        nl: "kippen",
      },
      {
        word: "هدية",
        nl: "cadeau",
      },
      {
        word: "حديقة",
        nl: "tuin",
      },
      {
        word: "أسد",
        nl: "leeuw",
      },
      {
        word: "جليد",
        nl: "ijs",
      },
    ],
    ذ: [
      {
        word: "ذهب",
        nl: "goud",
      },
      {
        word: "ذيل",
        nl: "staart",
      },
      {
        word: "ذئب",
        nl: "wolf",
      },
      {
        word: "ذراع",
        nl: "arm",
      },
      {
        word: "نافذة",
        nl: "raam",
      },
      {
        word: "غذاء",
        nl: "voedsel",
      },
      {
        word: "تلميذ",
        nl: "leerling",
      },
      {
        word: "لذيذ",
        nl: "lekker",
      },
    ],
    ر: [
      {
        word: "ريشة",
        nl: "veer",
      },
      {
        word: "رجل",
        nl: "man",
      },
      {
        word: "رأس",
        nl: "hoofd",
      },
      {
        word: "رغيف",
        nl: "brood",
      },
      {
        word: "كرسي",
        nl: "stoel",
      },
      {
        word: "شجرة",
        nl: "boom",
      },
      {
        word: "بحر",
        nl: "zee",
      },
      {
        word: "سرير",
        nl: "bed",
      },
    ],
    ز: [
      {
        word: "زرافة",
        nl: "giraf",
      },
      {
        word: "زيت",
        nl: "olie",
      },
      {
        word: "زجاج",
        nl: "glas",
      },
      {
        word: "زيتون",
        nl: "olijven",
      },
      {
        word: "حزام",
        nl: "riem",
      },
      {
        word: "ميزان",
        nl: "weegschaal",
      },
      {
        word: "كنز",
        nl: "schat",
      },
      {
        word: "موز",
        nl: "banaan",
      },
    ],
    س: [
      {
        word: "سيارة",
        nl: "auto",
      },
      {
        word: "ساعة",
        nl: "klok",
      },
      {
        word: "سفينة",
        nl: "schip",
      },
      {
        word: "سلة",
        nl: "mand",
      },
      {
        word: "أسد",
        nl: "leeuw",
      },
      {
        word: "جسر",
        nl: "brug",
      },
      {
        word: "جرس",
        nl: "klok",
      },
      {
        word: "عدس",
        nl: "linzen",
      },
    ],
    ش: [
      {
        word: "شجرة",
        nl: "boom",
      },
      {
        word: "شارع",
        nl: "straat",
      },
      {
        word: "شراع",
        nl: "zeil",
      },
      {
        word: "شوكة",
        nl: "vork",
      },
      {
        word: "عشب",
        nl: "gras",
      },
      {
        word: "مشمش",
        nl: "abrikozen",
      },
      {
        word: "فراشة",
        nl: "vlinder",
      },
      {
        word: "ريش",
        nl: "veren",
      },
    ],
    ص: [
      {
        word: "صندوق",
        nl: "kist",
      },
      {
        word: "صابون",
        nl: "zeep",
      },
      {
        word: "صورة",
        nl: "afbeelding",
      },
      {
        word: "صحن",
        nl: "bord",
      },
      {
        word: "حصان",
        nl: "paard",
      },
      {
        word: "عصير",
        nl: "sap",
      },
      {
        word: "قميص",
        nl: "overhemd",
      },
      {
        word: "مقص",
        nl: "schaar",
      },
    ],
    ض: [
      {
        word: "ضرس",
        nl: "kies",
      },
      {
        word: "ضوء",
        nl: "licht",
      },
      {
        word: "ضحك",
        nl: "lachte",
      },
      {
        word: "ضيف",
        nl: "gast",
      },
      {
        word: "مضرب",
        nl: "racket",
      },
      {
        word: "خضرة",
        nl: "groen",
      },
      {
        word: "أرض",
        nl: "aarde",
      },
      {
        word: "عرض",
        nl: "voorstelling",
      },
    ],
    ط: [
      {
        word: "طبل",
        nl: "trommel",
      },
      {
        word: "طفل",
        nl: "kind",
      },
      {
        word: "طريق",
        nl: "weg",
      },
      {
        word: "طعام",
        nl: "eten",
      },
      {
        word: "مطر",
        nl: "regen",
      },
      {
        word: "قطار",
        nl: "trein",
      },
      {
        word: "شاطئ",
        nl: "strand",
      },
      {
        word: "خيط",
        nl: "draad",
      },
    ],
    ظ: [
      {
        word: "ظل",
        nl: "schaduw",
      },
      {
        word: "ظهر",
        nl: "rug",
      },
      {
        word: "ظلام",
        nl: "duisternis",
      },
      {
        word: "ظبي",
        nl: "gazelle",
      },
      {
        word: "عظيم",
        nl: "geweldig",
      },
      {
        word: "نظارة",
        nl: "bril",
      },
      {
        word: "حفظ",
        nl: "leerde uit het hoofd",
      },
      {
        word: "محظوظ",
        nl: "blij",
      },
    ],
    ع: [
      {
        word: "علم",
        nl: "vlag",
      },
      {
        word: "عين",
        nl: "oog",
      },
      {
        word: "عسل",
        nl: "honing",
      },
      {
        word: "عصفور",
        nl: "vogel",
      },
      {
        word: "ملعب",
        nl: "speeltuin",
      },
      {
        word: "سعيد",
        nl: "blij",
      },
      {
        word: "شارع",
        nl: "straat",
      },
      {
        word: "شمع",
        nl: "was",
      },
    ],
    غ: [
      {
        word: "غيمة",
        nl: "wolk",
      },
      {
        word: "غرفة",
        nl: "kamer",
      },
      {
        word: "غراب",
        nl: "raaf",
      },
      {
        word: "غابة",
        nl: "bos",
      },
      {
        word: "رغيف",
        nl: "brood",
      },
      {
        word: "بغل",
        nl: "muildier",
      },
      {
        word: "دماغ",
        nl: "hersenen",
      },
      {
        word: "بلوغ",
        nl: "bereiken",
      },
    ],
    ف: [
      {
        word: "فراشة",
        nl: "vlinder",
      },
      {
        word: "فراولة",
        nl: "aardbei",
      },
      {
        word: "فنجان",
        nl: "kopje",
      },
      {
        word: "فستان",
        nl: "jurk",
      },
      {
        word: "عصفور",
        nl: "vogel",
      },
      {
        word: "سفينة",
        nl: "schip",
      },
      {
        word: "أنف",
        nl: "neus",
      },
      {
        word: "صف",
        nl: "rij",
      },
    ],
    ق: [
      {
        word: "قلم",
        nl: "pen",
      },
      {
        word: "قطار",
        nl: "trein",
      },
      {
        word: "قلب",
        nl: "hart",
      },
      {
        word: "قارب",
        nl: "boot",
      },
      {
        word: "بقرة",
        nl: "koe",
      },
      {
        word: "حقيبة",
        nl: "tas",
      },
      {
        word: "سوق",
        nl: "markt",
      },
      {
        word: "صندوق",
        nl: "kist",
      },
    ],
    ك: [
      {
        word: "كرة",
        nl: "bal",
      },
      {
        word: "كلب",
        nl: "hond",
      },
      {
        word: "كوب",
        nl: "beker",
      },
      {
        word: "كرسي",
        nl: "stoel",
      },
      {
        word: "بكرة",
        nl: "spoel",
      },
      {
        word: "فكرة",
        nl: "idee",
      },
      {
        word: "ديك",
        nl: "haan",
      },
      {
        word: "شوك",
        nl: "doornen",
      },
    ],
    ل: [
      {
        word: "لحم",
        nl: "vlees",
      },
      {
        word: "لوز",
        nl: "amandelen",
      },
      {
        word: "لبن",
        nl: "melk",
      },
      {
        word: "لعبة",
        nl: "speelgoed",
      },
      {
        word: "ملعقة",
        nl: "lepel",
      },
      {
        word: "ثلج",
        nl: "sneeuw",
      },
      {
        word: "فيل",
        nl: "olifant",
      },
      {
        word: "حبل",
        nl: "touw",
      },
    ],
    م: [
      {
        word: "ماء",
        nl: "water",
      },
      {
        word: "مدرسة",
        nl: "school",
      },
      {
        word: "مسجد",
        nl: "moskee",
      },
      {
        word: "مفتاح",
        nl: "sleutel",
      },
      {
        word: "سمكة",
        nl: "vis",
      },
      {
        word: "نمر",
        nl: "tijger",
      },
      {
        word: "نجم",
        nl: "ster",
      },
      {
        word: "علم",
        nl: "vlag",
      },
    ],
    ن: [
      {
        word: "نحلة",
        nl: "bij",
      },
      {
        word: "نار",
        nl: "vuur",
      },
      {
        word: "نمر",
        nl: "tijger",
      },
      {
        word: "نخلة",
        nl: "dadelpalm",
      },
      {
        word: "عنب",
        nl: "druiven",
      },
      {
        word: "صندوق",
        nl: "kist",
      },
      {
        word: "لبن",
        nl: "melk",
      },
      {
        word: "سفينة",
        nl: "schip",
      },
    ],
    ه: [
      {
        word: "هاتف",
        nl: "telefoon",
      },
      {
        word: "هدية",
        nl: "cadeau",
      },
      {
        word: "هواء",
        nl: "lucht",
      },
      {
        word: "هرم",
        nl: "piramide",
      },
      {
        word: "قهوة",
        nl: "koffie",
      },
      {
        word: "مهندس",
        nl: "ingenieur",
      },
      {
        word: "فهد",
        nl: "luipaard",
      },
      {
        word: "ذهب",
        nl: "goud",
      },
    ],
    و: [
      {
        word: "ولد",
        nl: "jongen",
      },
      {
        word: "وسادة",
        nl: "kussen",
      },
      {
        word: "وجه",
        nl: "gezicht",
      },
      {
        word: "ورق",
        nl: "papier",
      },
      {
        word: "سوق",
        nl: "markt",
      },
      {
        word: "صوت",
        nl: "stem",
      },
      {
        word: "حلو",
        nl: "zoet",
      },
      {
        word: "نحو",
        nl: "richting",
      },
    ],
    ي: [
      {
        word: "ياسمين",
        nl: "jasmijn",
      },
      {
        word: "يمين",
        nl: "rechts",
      },
      {
        word: "يوم",
        nl: "dag",
      },
      {
        word: "يتيم",
        nl: "wees",
      },
      {
        word: "سيارة",
        nl: "auto",
      },
      {
        word: "خيار",
        nl: "komkommer",
      },
      {
        word: "وادي",
        nl: "dal",
      },
      {
        word: "جدي",
        nl: "bok",
      },
    ],
  };
  const modes = ["forms", "missing", "circle"];
  const shuffle = (items, random) => {
    const a = [...items];
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  };
  const banks = Object.fromEntries(
    data.letters.map((letter) => [
      letter.char,
      [
        ...examples.examples[letter.char].map((e) => ({ ...e })),
        ...extras[letter.char].map((e) => ({
          ...e,
          index: examples.graphemes(e.word).indexOf(letter.char),
        })),
      ],
    ]),
  );
  function wordInfo(char, example) {
    const letter = data.letters.find((l) => l.char === char);
    const units = examples.graphemes(example.word),
      index = example.index;
    const before = index > 0 && !examples.nonJoining.has(units[index - 1]);
    const after =
      index < units.length - 1 &&
      !letter.nonjoining &&
      units[index + 1] !== "ء";
    const shape = before
      ? after
        ? "medial"
        : "final"
      : after
        ? "initial"
        : "isolated";
    const position =
      index === 0 ? "start" : index === units.length - 1 ? "end" : "middle";
    return {
      shape,
      position,
      before,
      after,
      masked: units.map((u, i) => (i === index ? "□" : u)).join(""),
    };
  }
  function createLetterQuestions(char, mode, random = Math.random) {
    const letter = data.letters.find((l) => l.char === char);
    if (!letter || !modes.includes(mode))
      throw new Error("Unknown letter or focused mode");
    const words = banks[char];
    if (mode === "circle")
      return Array.from({ length: 12 }, (_, i) => {
        const count = 4 + (i % 3);
        const targets = Array.from({ length: count }, (_, j) => ({
          glyph: letter.forms[(i + j) % 4],
          letter: char,
        }));
        const otherLetters = shuffle(
          data.letters.filter((l) => l.char !== char),
          random,
        );
        const others = otherLetters
          .slice(0, 16 - count)
          .map((l, j) => ({ glyph: l.forms[(i + j) % 4], letter: l.char }));
        const cells = shuffle([...targets, ...others], random);
        return {
          id: `circle-${i}`,
          kind: "circle",
          letter: char,
          cells,
          correct: cells.flatMap((cell, index) =>
            cell.letter === char ? [index] : [],
          ),
        };
      });
    if (mode === "missing")
      return shuffle(words, random).map((example, i) => ({
        id: `missing-${i}`,
        kind: "missing",
        letter: char,
        example,
        ...wordInfo(char, example),
        options: shuffle(
          [
            char,
            ...shuffle(
              data.letters.filter((l) => l.char !== char),
              random,
            )
              .slice(0, 3)
              .map((l) => l.char),
          ],
          random,
        ),
        correct: char,
      }));
    return shuffle(
      words.flatMap((example, i) => {
        const info = wordInfo(char, example);
        return [
          {
            id: `shape-${i}`,
            kind: "shape",
            letter: char,
            example,
            ...info,
            options: shuffle(
              letter.nonjoining
                ? ["isolated", "final"]
                : ["initial", "medial", "isolated", "final"],
              random,
            ),
            correct: info.shape,
          },
          {
            id: `position-${i}`,
            kind: "position",
            letter: char,
            example,
            ...info,
            options: shuffle(["start", "middle", "end"], random),
            correct: info.position,
          },
        ];
      }),
      random,
    );
  }
  function isCorrectAnswer(q, answer) {
    if (q.kind !== "circle") return answer === q.correct;
    return (
      Array.isArray(answer) &&
      answer.length === q.correct.length &&
      new Set(answer).size === answer.length &&
      answer.every((index) => q.correct.includes(index))
    );
  }
  const api = {
    banks,
    modes,
    wordInfo,
    createLetterQuestions,
    isCorrectAnswer,
  };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else window.ArabicLetterFocused = api;
})();
