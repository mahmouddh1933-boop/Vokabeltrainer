(() => {
  "use strict";
  window.JisrStorage.ready(() => {
    const D = window.ArabicReadingTrainer;
    const app = window.VocabApp;
    const $ = (id) => document.getElementById(id);
    let lang = window.JisrStorage.local.getItem("huroofStartNlLanguageV1") === "nl" ? "nl" : "ar";
    const t = (ar, nl) => lang === "nl" ? nl : ar;
    const number = (n) => n.toLocaleString(lang === "ar" ? "ar" : "nl");
    const el = (tag, text, className) => {
      const n = document.createElement(tag);
      if (text !== undefined) n.textContent = text;
      if (className) n.className = className;
      return n;
    };
    const button = (text, action) => {
      const b = el("button", text, "practice-button");
      b.type = "button";
      b.addEventListener("click", action);
      return b;
    };
    const starterLevel = {
      id: "0",
      ar: "تمهيدي · مقاطع من حرفين",
      nl: "Opstapniveau · Lettergrepen van twee letters",
      description: {
        ar: "اقرأ مقاطع من حرفين فقط، مثل بَا وبَحْ. اضغط «مساعدة» لترى الحرفين منفصلين مع حركاتهما.",
        nl: "Lees lettergrepen van twee letters, zoals بَا en بَحْ. Met Hulp zie je de twee letters los van elkaar, met hun klinkertekens.",
      },
    };
    // Reuse the recordings of the first two letters from the existing tracks.
    const starterSources = [
      "rt-2-01", "rt-2-02", "rt-2-03", "rt-2-04", "rt-2-14", "rt-2-08", "rt-2-06", "rt-2-07",
      "rt-1-31", "rt-1-32", "rt-1-33", "rt-1-34", "rt-1-42", "rt-1-44", "rt-1-45", "rt-1-50",
    ];
    const syllables = starterSources.map((id) => {
      const source = D.words.find((w) => w.id === id);
      const joined = source.events.find((event) => event.stage === "prefixes");
      return {
        id: `syllable-${id}`,
        level: starterLevel.id,
        word: source.prefixes[0].text,
        path: source.path,
        letters: source.letters.slice(0, 2),
        sounds: source.sounds.slice(0, 2),
        prefixes: [],
        sentences: [],
        events: [...source.events.filter((event) => event.stage === "letters" && event.index < 2),
          { ...joined, stage: "word", index: 0 }],
      };
    });
    const levels = [starterLevel, ...D.levels];
    const entries = [...syllables, ...D.words];
    const validIds = new Set(entries.map((w) => w.id));
    const saved = app.getStats().readingTrainerV1 || {};
    const ids = (v) => Array.isArray(v) ? [...new Set(v.filter((id) => validIds.has(id)))] : [];
    const state = {
      level: levels.some((l) => l.id === saved.level) ? saved.level : "1",
      positions: saved.positions && typeof saved.positions === "object" ? { ...saved.positions } : {},
      heard: ids(saved.heard),
      read: ids(saved.read),
      speed: saved.speed === 0.8 ? 0.8 : 1,
    };
    const isStarter = () => state.level === starterLevel.id;
    const bank = () => entries.filter((w) => w.level === state.level);
    const index = () => {
      const n = state.positions[state.level];
      return Number.isInteger(n) && n >= 0 && n < bank().length ? n : 0;
    };
    const current = () => bank()[index()];
    const prefixLabel = (count) => t(count === 2 ? "أول حرفين" : `أول ${number(count)} حروف`, `eerste ${count} letters`);
    const save = () => app.setJSON("learningStats", { ...app.getStats(), readingTrainerV1: state });
    const stageNames = () => ({
      letters: t("الحروف مع حركاتها", "Letterklanken met klinkers"),
      prefixes: t("الدمج التراكمي", "Stap voor stap verbinden"),
      word: isStarter() ? t("المقطع كاملًا", "Hele lettergreep") : t("الكلمة كاملة", "Hele woord"),
    });

    // One reusable local track per word: no chained play() calls, remote TTS,
    // timer-based fake highlights or reliance on speechSynthesis boundary events.
    const audio = new Audio();
    audio.preload = "metadata";
    audio.preservesPitch = true;
    let request = 0;
    let frame = 0;
    let loadingTimer = 0;
    let session = null;
    let activeKey = "";
    let wordSpans = [];
    let letterButtons = [];
    let prefixButtons = [];
    let sentenceAudios = [];
    let audioReady = false;
    let audioLoading = false;
    let preparation = 0;
    let preparationTimer = 0;
    let controller = null;
    let objectURL = null;

    function status(message, error = false) {
      $("rt-status").textContent = message;
      $("rt-status").classList.toggle("is-error", error);
    }
    function transport() {
      $("rt-listen").disabled = audioLoading;
      document.querySelectorAll("[data-play]").forEach((b) => { b.disabled = !audioReady; });
      $("rt-compare-word").disabled = !audioReady;
      [...letterButtons, ...prefixButtons].forEach((b) => { b.disabled = !audioReady; });
      $("rt-pause").disabled = !session || !session.started;
      $("rt-pause").textContent = audio.paused && session?.started
        ? t("استئناف", "Hervatten") : t("إيقاف مؤقت", "Pauze");
      $("rt-stop").disabled = !session && !sentenceAudios.some((a) => !a.paused);
      $("rt-listen").setAttribute("aria-pressed", String(!!session?.full));
    }
    function prepareAudio(w) {
      const token = ++preparation;
      clearTimeout(preparationTimer);
      controller?.abort();
      controller = new AbortController();
      audioReady = false;
      audioLoading = true;
      audio.removeAttribute("src");
      audio.load();
      if (objectURL) URL.revokeObjectURL(objectURL);
      objectURL = null;
      audio.dataset.readingWord = w.id;
      audio.dataset.readingSource = w.path;
      status(t("جارٍ تحميل صوت الكلمة…", "Woordopname wordt geladen…"));
      transport();
      const live = () => token === preparation;
      const fail = () => {
        if (!live()) return;
        clearTimeout(preparationTimer);
        audioLoading = false;
        audioReady = false;
        transport();
        status(t("تعذّر تحميل صوت الكلمة. اضغط الاستماع لإعادة المحاولة، وتحقق من الاتصال أو مجلد audio في نسخة ZIP.",
          "De opname kon niet worden geladen. Tik op luisteren om opnieuw te proberen en controleer de verbinding of de audiomap in de ZIP-versie."), true);
      };
      const load = (url) => {
        if (!live()) return;
        audio.onloadedmetadata = () => {
          if (!live()) return;
          clearTimeout(preparationTimer);
          audioLoading = false;
          audioReady = true;
          transport();
          status(isStarter() ? t("استمع إلى المقطع ثم اقرأه بصوتك.", "Luister naar de lettergreep en lees hem daarna hardop.")
            : t("اضغط الاستماع، ثم اقرأ الكلمة بصوتك.", "Tik op luisteren en lees het woord daarna hardop."));
        };
        audio.onerror = fail;
        audio.preload = "auto";
        audio.src = url;
        audio.load();
      };
      preparationTimer = setTimeout(() => {
        if (!live()) return;
        controller.abort();
        fail();
      }, 15000);
      // Memory-backed media is seekable even on simple static hosts that do
      // not implement HTTP Range. This prevents a selected prefix/letter from
      // accidentally playing the entire earlier part of the track.
      if (location.protocol === "file:") load(w.path);
      else fetch(w.path, { signal: controller.signal })
        .then((r) => {
          if (!r.ok) throw new Error("audio-http");
          return r.arrayBuffer();
        })
        .then((bytes) => {
          if (!live()) return;
          objectURL = URL.createObjectURL(new Blob([bytes], { type: "audio/mpeg" }));
          load(objectURL);
        })
        .catch((error) => { if (error.name !== "AbortError") fail(); });
    }
    function highlight(event) {
      const key = event ? `${event.stage}:${event.index}` : "";
      if (key === activeKey) return;
      activeKey = key;
      const w = current();
      const indices = event?.stage === "letters" ? w.sounds[event.index].letters
        : event?.stage === "prefixes" ? w.prefixes[event.index].letters
          : event?.stage === "word" ? wordSpans.map((_, i) => i) : [];
      wordSpans.forEach((s, i) => s.classList.toggle("rt-active", indices.includes(i)));
      letterButtons.forEach((b, i) => b.classList.toggle("rt-active", event?.stage === "letters" && i === event.index));
      prefixButtons.forEach((b, i) => b.classList.toggle("rt-active", event?.stage === "prefixes" && i === event.index));
      document.querySelectorAll("#rt-stages li").forEach((li) => {
        if (li.dataset.stage === event?.stage) li.setAttribute("aria-current", "step");
        else li.removeAttribute("aria-current");
      });
      if (event) {
        const text = event.stage === "letters" ? w.sounds[event.index].spokenText
          : event.stage === "prefixes" ? w.prefixes[event.index].text : w.word;
        const step = event.stage === "prefixes" ? ` · ${prefixLabel(w.prefixes[event.index].count)}` : "";
        $("rt-current").textContent = `${stageNames()[event.stage]}${step}: ${text}`;
      } else $("rt-current").textContent = "";
    }
    function stop(clearStatus = true, includeSentences = true) {
      request++;
      cancelAnimationFrame(frame);
      clearTimeout(loadingTimer);
      audio.onplaying = audio.onended = audio.ontimeupdate = audio.onwaiting = null;
      // Stoping a sentence must not detach a word's still-pending preparation.
      if (!audioLoading) audio.onerror = audio.onloadedmetadata = null;
      audio.pause();
      if (includeSentences) sentenceAudios.forEach((a) => a.pause());
      session = null;
      activeKey = "reset";
      highlight(null);
      if (clearStatus) status("");
      transport();
    }
    function finish(full) {
      const id = session?.id;
      stop(false);
      if (full && id && !state.heard.includes(id)) {
        state.heard.push(id);
        save();
        progress();
      }
      status(full && isStarter() ? t("أحسنت! اقرأ المقطع الآن بنفسك.", "Goed gedaan! Lees de lettergreep nu zelf.")
        : full ? t("أحسنت! استمعتَ للمراحل الثلاث. الآن اقرأ الكلمة بنفسك.",
        "Goed gedaan! Je hebt alle drie stappen gehoord. Lees het woord nu zelf.")
        : t("أحسنت، أعد النطق بصوتك أو استمع مرة أخرى.", "Zeg het zelf na of luister nog een keer."));
    }
    function tick() {
      if (!session || audio.paused) return;
      const time = audio.currentTime;
      if (session.end !== null && time >= session.end) {
        finish(session.full);
        return;
      }
      const event = current().events.find((e) => time >= e.start && time < e.end);
      highlight(event || null);
    }
    function animate(token) {
      if (token !== request || !session || audio.paused) return;
      tick();
      if (session) frame = requestAnimationFrame(() => animate(token));
    }
    function play(stage = "all", onlyIndex = null) {
      if (!audioReady) {
        if (!audioLoading) prepareAudio(current());
        return;
      }
      stop();
      app.stopSpeech();
      const w = current();
      const full = stage === "all";
      const excerpt = !full || isStarter();
      const selectedStage = full && isStarter() ? "word" : stage;
      const events = excerpt ? w.events.filter((e) =>
        e.stage === selectedStage && (onlyIndex === null || e.index === onlyIndex)) : w.events;
      if (!events.length) return;
      const token = request;
      const start = excerpt ? Math.max(0, events[0].start - 0.035) : 0;
      session = { id: w.id, full, end: excerpt ? events.at(-1).end : null, started: false };
      const live = () => token === request && session?.id === w.id;
      const fail = (error) => {
        if (!live()) return;
        stop(false);
        status(error?.name === "NotAllowedError"
          ? t("اضغط الاستماع مجددًا للسماح بالصوت وتحقق من مستوى الصوت.", "Tik opnieuw op luisteren en controleer het volume.")
          : t("تعذّر تشغيل صوت الكلمة. أعد المحاولة وتحقّق من الاتصال، أو من وجود مجلد audio عند فتح نسخة ZIP.",
            "De opname kon niet worden afgespeeld. Probeer het opnieuw. Controleer de verbinding of de map audio in de ZIP-versie."), true);
      };
      audio.playbackRate = state.speed;
      audio.onplaying = () => {
        if (!live()) return;
        session.started = true;
        clearTimeout(loadingTimer);
        status(t("استمع وتابع الحرف أو بداية الكلمة الملوَّنة.", "Luister en volg de gemarkeerde klank of het woordbegin."));
        transport();
        cancelAnimationFrame(frame);
        animate(token);
      };
      audio.onwaiting = () => {
        if (live()) {
          status(t("جارٍ تحميل الصوت…", "Audio wordt geladen…"));
          clearTimeout(loadingTimer);
          loadingTimer = setTimeout(() => fail(), 15000);
        }
      };
      audio.onerror = fail;
      audio.ontimeupdate = () => { if (live()) tick(); };
      audio.onended = () => { if (live()) finish(session.full); };
      status(t("جارٍ تشغيل الصوت…", "Audio start…"));
      transport();
      loadingTimer = setTimeout(() => fail(), 15000);
      try {
        audio.currentTime = start;
        // Media is already loaded and seekable. Keep play() inside the tap.
        const result = audio.play();
        result?.catch(fail);
      } catch (error) { fail(error); }
    }
    function progress() {
      const words = bank();
      const read = words.filter((w) => state.read.includes(w.id)).length;
      const heard = words.filter((w) => state.heard.includes(w.id)).length;
      $("rt-progress-text").textContent = t(
        `${isStarter() ? "استمعتُ إلى المقاطع" : "استمعتُ للمراحل كاملة"}: ${number(heard)} / ${number(words.length)} · قرأتُ بنفسي: ${number(read)} / ${number(words.length)}`,
        `${isStarter() ? "Lettergrepen beluisterd" : "Alle stappen beluisterd"}: ${heard} / ${words.length} · Zelf gelezen: ${read} / ${words.length}`);
      $("rt-progress").value = read;
      $("rt-progress").max = words.length;
      const isRead = state.read.includes(current().id);
      $("rt-self-read").textContent = isRead ? t("✓ قرأتُها بنفسي · اضغط لإلغاء العلامة", "✓ Zelf gelezen · Markering verwijderen")
        : t("قرأتُها بنفسي · ضع علامة", "Zelf gelezen · Markeren");
      $("rt-self-read").setAttribute("aria-pressed", String(isRead));
      $("rt-word-grid").querySelectorAll("button").forEach((b, i) => { b.dataset.read = String(state.read.includes(words[i].id)); });
    }
    function selectWord(i, fromLibrary = false) {
      stop();
      state.positions[state.level] = Math.max(0, Math.min(i, bank().length-1));
      save();
      render();
      $("rt-word").focus({ preventScroll: true });
      if (fromLibrary) $("rt-word").scrollIntoView({ block: "center", behavior: "instant" });
    }
    function renderSentences(w) {
      sentenceAudios.forEach((a) => {
        a.onplay = a.onplaying = a.onpause = a.onended = a.onerror = null;
        a.pause();
        a.removeAttribute("src");
        a.load();
      });
      sentenceAudios = [];
      $("rt-sentences").replaceChildren(...w.sentences.map((sentence, i) => {
        const card = el("article", undefined, "rt-sentence-card");
        card.dataset.sentence = String(i);
        const heading = el("h3", i === 0 ? t("٤ · جملة قصيرة", "4 · Een korte zin")
          : t("٥ · جملة أطول قليلًا", "5 · De zin uitbreiden"));
        const text = el("p", undefined, "rt-sentence-text");
        text.lang = "ar";
        text.dir = "rtl";
        const at = sentence.ar.indexOf(sentence.focus);
        text.append(document.createTextNode(sentence.ar.slice(0, at)), el("mark", sentence.focus),
          document.createTextNode(sentence.ar.slice(at + sentence.focus.length)));
        const details = el("details");
        details.append(el("summary", t("عرض المعنى بالألمانية", "Nederlandse betekenis tonen")));
        const meaning = el("p", sentence.nl, "rt-sentence-translation");
        meaning.lang = "nl";
        meaning.dir = "ltr";
        details.append(meaning);
        const label = el("p", t("اقرأ بنفسك، ثم شغّل التسجيل للمقارنة.", "Lees eerst zelf. Speel daarna de opname af om te vergelijken."), "rt-note");
        const media = el("audio");
        media.controls = true;
        media.preload = "metadata";
        media.src = sentence.path;
        media.playbackRate = state.speed;
        media.preservesPitch = true;
        media.setAttribute("aria-label", t(`استمع إلى الجملة: ${sentence.ar}`, `Zin beluisteren: ${sentence.ar}`));
        media.dataset.readingSentence = `${w.id}-${i}`;
        const error = el("p", "", "rt-sentence-error");
        error.setAttribute("role", "status");
        media.onplay = () => {
          if (session) stop(false, false);
          else audio.pause();
          app.stopSpeech();
          sentenceAudios.forEach((other) => { if (other !== media) other.pause(); });
          transport();
        };
        media.onplaying = () => {
          card.classList.add("is-playing");
          error.textContent = "";
          transport();
        };
        media.onpause = media.onended = () => { card.classList.remove("is-playing"); transport(); };
        media.onerror = () => {
          card.classList.remove("is-playing");
          error.textContent = t("تعذّر تحميل تسجيل الجملة. أعد المحاولة وتحقّق من الاتصال أو مجلد audio.",
            "De opname van de zin kon niet worden geladen. Probeer het opnieuw en controleer de verbinding of de audiomap.");
          transport();
        };
        sentenceAudios.push(media);
        card.append(heading, text, details, label, media, error);
        return card;
      }));
    }
    function render() {
      stop();
      const w = current();
      const starter = isStarter();
      $("rt-levels").replaceChildren(...levels.map((l) => {
        const b = button(l[lang === "nl" ? "nl" : "ar"], () => {
          state.level = l.id;
          save();
          render();
        });
        b.dataset.level = l.id;
        b.setAttribute("aria-pressed", String(l.id === state.level));
        return b;
      }));
      $("rt-level-description").textContent = levels.find((l) => l.id === state.level).description[lang];
      $("rt-counter").textContent = `${number(index()+1)} / ${number(bank().length)}`;
      $("rt-word-select").replaceChildren(...bank().map((word, i) => {
        const option = el("option", `${number(i+1)} · ${word.word}`);
        option.value = String(i);
        return option;
      }));
      $("rt-word-select").value = String(index());
      wordSpans = w.letters.map((l) => el("span", l.text));
      $("rt-word").replaceChildren(...wordSpans);
      $("rt-word").setAttribute("aria-label", w.word);
      $("rt-separated").textContent = w.letters.map((l) => l.text).join(" ");
      $("rt-separated").hidden = true;
      $("rt-help").setAttribute("aria-expanded", "false");
      $("rt-meaning").textContent = w.nl ?? "";
      document.querySelectorAll("[data-rt-word-only]").forEach((node) => { node.hidden = starter; });
      $("rt-item-label").textContent = starter ? t("اختر مقطعًا", "Lettergreep kiezen") : t("اختر كلمة من المستوى", "Woord van dit niveau kiezen");
      $("rt-prev").textContent = starter ? t("المقطع السابق", "Vorige lettergreep") : t("الكلمة السابقة", "Vorig woord");
      $("rt-next").textContent = starter ? t("المقطع التالي", "Volgende lettergreep") : t("الكلمة التالية", "Volgend woord");
      $("rt-listen").textContent = starter ? t("◖ استمع للمقطع", "◖ Lettergreep beluisteren") : t("◖ استمع للتدرّج كاملًا", "◖ Alle drie stappen beluisteren");
      $("rt-library-label").textContent = starter ? t("تصفّح المقاطع", "Alle lettergrepen bekijken") : t("تصفّح كلمات المستوى الخمسين", "Alle 50 woorden van dit niveau bekijken");
      letterButtons = w.sounds.map((sound, i) => {
        // Show exactly what will be heard, including necessary coda/shadda or
        // long-vowel context, instead of promising an isolated bare consonant.
        const b = button(sound.spokenText, () => play("letters", i));
        b.dataset.context = String(sound.context);
        b.setAttribute("aria-label", t(`استمع للصوت: ${sound.spokenText}`, `Klank beluisteren: ${sound.spokenText}`));
        b.title = sound.context ? t(`نقرأه في سياقه: ${sound.spokenText}`, `In het woord: ${sound.spokenText}`) : sound.text;
        return b;
      });
      prefixButtons = w.prefixes.map((prefix, i) => {
        const b = button(prefix.text, () => play("prefixes", i));
        b.setAttribute("aria-label", t(`دمج ${prefixLabel(prefix.count)}: ${prefix.text}`, `${prefixLabel(prefix.count)} verbinden: ${prefix.text}`));
        b.dataset.count = String(prefix.count);
        return b;
      });
      $("rt-letter-strip").replaceChildren(...letterButtons);
      $("rt-prefixes").replaceChildren(...prefixButtons);
      renderSentences(w);
      $("rt-word-grid").replaceChildren(...bank().map((word, i) => {
        const b = button(word.word, () => selectWord(i, true));
        if (i === index()) b.setAttribute("aria-current", "true");
        return b;
      }));
      $("rt-prev").disabled = index() === 0;
      $("rt-next").disabled = index() === bank().length-1;
      $("rt-speed").value = String(state.speed);
      progress();
      prepareAudio(w);
    }
    $("rt-help").onclick = () => {
      const show = $("rt-separated").hidden;
      $("rt-separated").hidden = !show;
      $("rt-help").setAttribute("aria-expanded", String(show));
    };
    $("rt-listen").onclick = () => play();
    $("rt-compare-word").onclick = () => play("word");
    document.querySelectorAll("[data-play]").forEach((b) => { b.onclick = () => play(b.dataset.play); });
    $("rt-stop").onclick = () => { stop(); status(t("تم إيقاف الصوت.", "Audio gestopt.")); };
    $("rt-pause").onclick = () => {
      if (!session) return;
      if (audio.paused) {
        const token = request;
        audio.play()?.catch(() => {
          if (token !== request) return;
          stop(false);
          status(t("اضغط زر الاستماع لإعادة تشغيل الصوت.", "Tik op luisteren om opnieuw te beginnen."), true);
        });
      } else {
        audio.pause();
        cancelAnimationFrame(frame);
        status(t("متوقف مؤقتًا. يمكنك الاستئناف من الموضع نفسه.", "Gepauzeerd. Je kunt op dezelfde plek verdergaan."));
      }
      transport();
    };
    $("rt-speed").onchange = (e) => {
      state.speed = e.target.value === "0.8" ? 0.8 : 1;
      audio.playbackRate = state.speed;
      sentenceAudios.forEach((a) => { a.playbackRate = state.speed; });
      save();
    };
    $("rt-word-select").onchange = (e) => selectWord(Number(e.target.value));
    $("rt-prev").onclick = () => selectWord(index()-1);
    $("rt-next").onclick = () => selectWord(index()+1);
    $("rt-self-read").onclick = () => {
      const id = current().id;
      state.read = state.read.includes(id) ? state.read.filter((v) => v !== id) : [...state.read, id];
      save();
      progress();
    };
    window.addEventListener("app-language-change", (event) => {
      lang = event.detail.lang === "nl" ? "nl" : "ar";
      render();
    });
    window.addEventListener("pagehide", () => { stop(); controller?.abort(); clearTimeout(preparationTimer); });
    window.addEventListener("pageshow", (e) => { if (e.persisted && !audioReady) prepareAudio(current()); });
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) stop();
      else if (!audioReady) prepareAudio(current());
    });
    render();
    $("lesson-loading")?.remove();
  });
})();
