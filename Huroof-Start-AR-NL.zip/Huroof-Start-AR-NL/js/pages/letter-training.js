(() => {
  "use strict";
  window.JisrStorage.ready(() => {
    const $ = (id) => document.getElementById(id);
    const { modes, createQuestions } = window.ArabicLetterTraining;
    const sessions = new Map();
    const titles = {
      names: ["الحرف واسمه", "Letter en naam"],
      forms: ["أشكال الحرف", "Schrijfvormen herkennen"],
      missing: ["الحرف الناقص", "Ontbrekende letter"],
      listening: ["اسمع واختر", "Luisteren en koppelen"],
    };
    const positions = [
      ["أول الكلمة", "woordbegin"],
      ["وسط الكلمة", "woordmidden"],
      ["آخر الكلمة منفصلًا", "woordeinde zonder verbinding"],
      ["آخر الكلمة متصلًا", "woordeinde met verbinding"],
    ];
    let mode = null;
    const nl = () => window.AppLanguage?.get() === "nl";
    const text = (ar, german) => (nl() ? german : ar);
    const pair = (value) => text(...value);
    function session() {
      if (!sessions.has(mode))
        sessions.set(mode, {
          questions: createQuestions(mode),
          index: 0,
          answers: [],
          finished: false,
        });
      return sessions.get(mode);
    }
    function render() {
      document
        .querySelectorAll("[data-training-mode]")
        .forEach((b) =>
          b.setAttribute(
            "aria-pressed",
            String(b.dataset.trainingMode === mode),
          ),
        );
      if (!mode) {
        $("training-run").hidden = true;
        $("training-result").hidden = true;
        return;
      }
      const s = session(),
        q = s.questions[s.index];
      const answered = s.answers[s.index] !== undefined;
      const count = s.answers.filter((a) => a !== undefined).length;
      const correct = s.answers.filter(
        (a, i) => a === s.questions[i].correct,
      ).length;
      $("training-run").hidden = s.finished;
      $("training-result").hidden = !s.finished;
      $("training-title").textContent = pair(titles[mode]);
      $("training-counter").textContent = text(
        `السؤال ${s.index + 1} من ${s.questions.length}`,
        `Vraag ${s.index + 1} van ${s.questions.length}`,
      );
      $("training-score").textContent = text(
        `${correct} من ${count} إجابات صحيحة`,
        `${correct} van ${count} goed`,
      );
      $("training-progress").max = s.questions.length;
      $("training-progress").value = count;
      $("training-progress-label").textContent = text(
        `أجبت عن ${count} من ${s.questions.length}`,
        `${count} van ${s.questions.length} beantwoord`,
      );
      const prompts = {
        names: [
          "أي حرف يحمل هذا الاسم؟",
          "Welke letter heeft deze naam?",
        ],
        forms: [
          "أي حرف يمثّله هذا الشكل؟",
          "Welke letter zie je in deze vorm?",
        ],
        missing: [
          "اختر الحرف الناقص لإكمال الكلمة.",
          "Vul de ontbrekende letter in.",
        ],
        listening: [
          "استمع إلى اسم الحرف، ثم اختر الحرف الصحيح.",
          "Luister naar de letternaam en kies het juiste teken.",
        ],
      };
      $("training-prompt").textContent = pair(prompts[mode]);
      const stimulus = $("training-stimulus");
      stimulus.replaceChildren();
      if (mode !== "listening") {
        const shown = document.createElement("p");
        shown.className =
          mode === "names" ? "training-letter-name" : "training-arabic";
        shown.textContent =
          mode === "names"
            ? text(q.letter.name, q.letter.nl)
            : mode === "forms"
              ? q.shape
              : q.masked;
        shown.lang = mode === "names" && nl() ? "nl" : "ar";
        stimulus.append(shown);
        if (mode === "missing") {
          const meaning = document.createElement("p");
          meaning.lang = "nl";
          meaning.className = "training-word-meaning";
          meaning.textContent = q.example.nl;
          stimulus.append(meaning);
        }
      }
      $("training-listen").hidden = mode !== "listening";
      $("training-options").replaceChildren(
        ...q.options.map((option) => {
          const b = document.createElement("button");
          b.type = "button";
          b.lang = "ar";
          b.className = "training-option";
          b.textContent = option;
          b.disabled = answered;
          if (answered && option === q.correct) b.classList.add("is-correct");
          if (answered && option === s.answers[s.index] && option !== q.correct)
            b.classList.add("is-wrong");
          b.addEventListener("click", () => {
            if (s.answers[s.index] !== undefined) return;
            s.answers[s.index] = option;
            render();
          });
          return b;
        }),
      );
      const feedback = $("training-feedback");
      feedback.replaceChildren();
      feedback.className = "training-feedback";
      if (answered) {
        feedback.classList.add(
          s.answers[s.index] === q.correct ? "is-correct" : "is-wrong",
        );
        const heading = document.createElement("strong");
        heading.textContent =
          s.answers[s.index] === q.correct
            ? text("أحسنت!", "Goed!")
            : text("لنتعلّم من الإجابة.", "Leer van het antwoord.");
        heading.textContent += " " + VocabApp.encouragement(s.answers[s.index] === q.correct);
        const explanation = document.createElement("p");
        explanation.textContent =
          mode === "names" || mode === "listening"
            ? text(
                `الحرف الصحيح «${q.correct}»، واسمه «${q.letter.name}».`,
                `Het teken ‘${q.correct}“ heet ${q.letter.nl}.`,
              )
            : text(
                `الحرف «${q.correct}» في ${pair(positions[q.position])}، كما في «${q.example.word}».`,
                `„${q.correct}’ staat hier op de positie: ${pair(positions[q.position])}, wie in „${q.example.word}“.`,
              );
        const example = document.createElement("p");
        example.className = "training-example";
        example.lang = "ar";
        window.ArabicLetterExamples.highlight(
          example,
          q.example.word,
          q.example.index,
        );
        const meaning = document.createElement("p");
        meaning.lang = "nl";
        meaning.textContent = q.example.nl;
        feedback.append(heading, explanation, example, meaning);
        if (q.letter.nonjoining && mode === "forms") {
          const note = document.createElement("p");
          note.textContent = text(
            "هذا الحرف لا يتصل بالحرف الذي يليه؛ قد يتكرر شكله في أكثر من موضع.",
            "Deze letter wordt niet met het volgende teken verbonden. De vorm kan op verschillende posities hetzelfde zijn.",
          );
          feedback.append(note);
        }
      }
      $("training-previous").disabled = s.index === 0;
      $("training-next").disabled = !answered;
      $("training-next").textContent =
        s.index === s.questions.length - 1
          ? text("عرض النتيجة", "Resultaat bekijken")
          : text("السؤال التالي", "Volgende vraag");
      $("training-result-score").textContent = text(
        `${correct} من ${s.questions.length} إجابة صحيحة · ${Math.round((correct / s.questions.length) * 100)}٪`,
        `${correct} van ${s.questions.length} goed · ${Math.round((correct / s.questions.length) * 100)} %`,
      );
      $("training-result-message").textContent =
        correct === s.questions.length
          ? text(
              "أحسنت! تعرّفت على جميع الحروف في هذه الجولة.",
              "Heel goed! Je hebt in deze ronde alle letters herkend.",
            )
          : text(
              "راجع إجاباتك والشرح، ثم جرّب جولة جديدة بترتيب مختلف.",
              "Bekijk je antwoorden en de uitleg. Begin daarna een nieuwe ronde met een andere volgorde.",
            );
    }
    function clearAudio() {
      window.VocabApp.stopSpeech();
      $("training-audio-status").textContent = "";
      $("training-audio-status").classList.remove("speech-error");
    }
    function focusQuestion() {
      $("training-run").scrollIntoView({ block: "start" });
      $("training-prompt").focus({ preventScroll: true });
    }
    function selectFromHash() {
      clearAudio();
      const slug = location.hash.slice(1);
      mode = modes.includes(slug) ? slug : null;
      render();
      if (mode)
        $(
          session().finished ? "training-result" : "training-run",
        ).scrollIntoView({ block: "start" });
    }
    document.querySelectorAll("[data-training-mode]").forEach((b) =>
      b.addEventListener("click", () => {
        if (location.hash === `#${b.dataset.trainingMode}`) selectFromHash();
        else location.hash = b.dataset.trainingMode;
      }),
    );
    $("training-listen").addEventListener("click", () => {
      const q = session().questions[session().index];
      window.VocabApp.speakArabic(q.letter.spokenName, (message, error) => {
        $("training-audio-status").textContent = message;
        $("training-audio-status").classList.toggle(
          "speech-error",
          Boolean(error),
        );
      });
    });
    $("training-previous").addEventListener("click", () => {
      const s = session();
      if (s.index === 0) return;
      clearAudio();
      s.index--;
      render();
      focusQuestion();
    });
    $("training-next").addEventListener("click", () => {
      const s = session();
      if (s.answers[s.index] === undefined) return;
      clearAudio();
      if (s.index === s.questions.length - 1) s.finished = true;
      else s.index++;
      render();
      if (s.finished) $("training-result").scrollIntoView({ block: "start" });
      else focusQuestion();
    });
    $("training-review").addEventListener("click", () => {
      const s = session();
      s.index = 0;
      s.finished = false;
      render();
      focusQuestion();
    });
    $("training-restart").addEventListener("click", () => {
      clearAudio();
      sessions.delete(mode);
      render();
      focusQuestion();
    });
    window.addEventListener("hashchange", selectFromHash);
    window.addEventListener("app-language-change", () => {
      clearAudio();
      render();
    });
    window.addEventListener("pagehide", () => window.VocabApp.stopSpeech());
    selectFromHash();
  });
})();
