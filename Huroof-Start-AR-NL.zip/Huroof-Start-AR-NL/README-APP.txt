Huroof Start · العربية / Nederlands

Pak alle bestanden uit. Open index.html en kies Nederlands of العربية.
De oefeningen en opnamen zijn Arabisch. Je voortgang wordt op dit apparaat opgeslagen.

فكّ ضغط جميع الملفات وافتح index.html، ثم اختر العربية أو Nederlands.
تبقى التمارين والتسجيلات بالعربية، ويُحفظ التقدّم على هذا الجهاز.
